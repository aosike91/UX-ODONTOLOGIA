"""
VR Game UX Analyzer - Detector de Puntos Clave
Detecta objetos interactuables y puntos de interés en videos de juegos VR
"""

import cv2
import numpy as np
from ultralytics import YOLO
import mediapipe as mp
from typing import List, Dict, Tuple, Optional
import logging

class KeyPointDetector:
    """
    Detector de puntos clave y objetos interactuables en videos VR
    """
    
    def __init__(self, confidence_threshold: float = 0.5):
        """
        Inicializa el detector
        
        Args:
            confidence_threshold: Umbral de confianza para detecciones
        """
        self.confidence_threshold = confidence_threshold
        self.yolo_model = None
        self.mp_hands = mp.solutions.hands
        self.mp_pose = mp.solutions.pose
        self.hands = None
        self.pose = None
        
        # Colores para visualización
        self.colors = {
            'interactable': (0, 255, 0),  # Verde
            'missed': (0, 0, 255),        # Rojo  
            'selected': (255, 0, 0),      # Azul
            'hand': (255, 255, 0),        # Cian
            'gaze': (255, 0, 255),        # Magenta
            'main_button': (0, 255, 255), # Amarillo - Botones principales
            'back_button': (255, 165, 0)  # Naranja - Botón de regreso
        }
        
        # Configuración específica para aplicación dental VR - basada en imagen real
        self.dental_ui_config = {
            'main_buttons_count': 3,      # 3 botones principales (Boton1, Boton2, Boton3)
            'back_button_count': 1,       # 1 botón de regreso (morado)
            'button_min_area': 10000,     # Área mínima aumentada para mejor detección
            'main_button_min_size': (150, 120),  # Tamaño mínimo botones principales (verdes)
            'back_button_min_size': (200, 60),   # Tamaño mínimo botón regreso (morado)
            
            # Configuración específica de colores
            'colors': {
                'main_buttons': {
                    'hsv_lower': [35, 80, 80],   # Verde - rango inferior
                    'hsv_upper': [85, 255, 255], # Verde - rango superior
                    'detection_method': 'color_and_position'
                },
                'back_button': {
                    'hsv_lower': [120, 50, 50],   # Morado - rango inferior 
                    'hsv_upper': [160, 255, 255], # Morado - rango superior
                    'detection_method': 'color_and_text'
                }
            },
            
            # Posiciones específicas basadas en la imagen - más centradas
            'button_positions': {
                'boton1': {'x_range': (0.125, 0.275), 'y_range': (0.275, 0.425), 'name': 'Boton1'},
                'boton2': {'x_range': (0.355, 0.505), 'y_range': (0.275, 0.425), 'name': 'Boton2'},
                'boton3': {'x_range': (0.585, 0.735), 'y_range': (0.275, 0.425), 'name': 'Boton3'},
                'back_button': {'x_range': (0.02, 0.40), 'y_range': (0.05, 0.18), 'name': 'Regresar'}
            },
            
            'interaction_priority': {
                'main_buttons': 1.0,      # Prioridad máxima
                'back_button': 0.8,       # Prioridad alta para navegación
                'other_elements': 0.3     # Prioridad baja
            },
            
            # Validación de interacciones
            'validation': {
                'check_button_labels': True,
                'require_color_match': True,
                'position_tolerance': 0.1
            }
        }
        
        self.setup_logging()
    
    def setup_logging(self):
        """Configura el sistema de logging"""
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def initialize_models(self):
        """Inicializa los modelos de detección"""
        try:
            # Cargar YOLO para detección de objetos
            self.yolo_model = YOLO('yolov8n.pt')  # Modelo base, se puede personalizar
            
            # Inicializar MediaPipe para detección de manos y pose
            self.hands = self.mp_hands.Hands(
                static_image_mode=False,
                max_num_hands=2,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            )
            
            self.pose = self.mp_pose.Pose(
                static_image_mode=False,
                model_complexity=1,
                smooth_landmarks=True,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            )
            
            self.logger.info("Modelos inicializados correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando modelos: {e}")
            raise
    
    def detect_objects(self, frame: np.ndarray) -> List[Dict]:
        """
        Detecta objetos en un frame usando YOLO
        
        Args:
            frame: Frame de video
            
        Returns:
            Lista de objetos detectados con sus coordenadas y confianza
        """
        if self.yolo_model is None:
            self.initialize_models()
        
        results = self.yolo_model(frame, conf=self.confidence_threshold)
        detections = []
        
        for result in results:
            boxes = result.boxes
            if boxes is not None:
                for box in boxes:
                    # Extraer información de la detección
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    confidence = box.conf[0].cpu().numpy()
                    class_id = int(box.cls[0].cpu().numpy())
                    class_name = result.names[class_id]
                    
                    detection = {
                        'bbox': [int(x1), int(y1), int(x2), int(y2)],
                        'confidence': float(confidence),
                        'class_id': class_id,
                        'class_name': class_name,
                        'center': (int((x1 + x2) / 2), int((y1 + y2) / 2)),
                        'area': (x2 - x1) * (y2 - y1)
                    }
                    detections.append(detection)
        
        return detections
    
    def detect_hands(self, frame: np.ndarray) -> List[Dict]:
        """
        Detecta manos y puntos clave usando MediaPipe
        
        Args:
            frame: Frame de video
            
        Returns:
            Lista de manos detectadas con landmarks
        """
        if self.hands is None:
            self.initialize_models()
        
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.hands.process(rgb_frame)
        
        hand_detections = []
        
        if results.multi_hand_landmarks:
            for i, hand_landmarks in enumerate(results.multi_hand_landmarks):
                # Extraer landmarks clave
                landmarks = []
                h, w, _ = frame.shape
                
                for landmark in hand_landmarks.landmark:
                    x = int(landmark.x * w)
                    y = int(landmark.y * h)
                    landmarks.append((x, y))
                
                # Punto de punta del índice (landmark 8)
                index_tip = landmarks[8] if len(landmarks) > 8 else None
                # Punto del pulgar (landmark 4)
                thumb_tip = landmarks[4] if len(landmarks) > 4 else None
                
                hand_info = {
                    'hand_index': i,
                    'landmarks': landmarks,
                    'index_tip': index_tip,
                    'thumb_tip': thumb_tip,
                    'handedness': results.multi_handedness[i].classification[0].label if results.multi_handedness else 'Unknown'
                }
                hand_detections.append(hand_info)
        
        return hand_detections
    
    def detect_pose(self, frame: np.ndarray) -> Optional[Dict]:
        """
        Detecta la pose del jugador
        
        Args:
            frame: Frame de video
            
        Returns:
            Información de la pose detectada
        """
        if self.pose is None:
            self.initialize_models()
        
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.pose.process(rgb_frame)
        
        if results.pose_landmarks:
            landmarks = []
            h, w, _ = frame.shape
            
            for landmark in results.pose_landmarks.landmark:
                x = int(landmark.x * w)
                y = int(landmark.y * h)
                landmarks.append((x, y))
            
            # Puntos clave de la cabeza para estimar dirección de la mirada
            nose = landmarks[0] if len(landmarks) > 0 else None
            left_eye = landmarks[2] if len(landmarks) > 2 else None  
            right_eye = landmarks[5] if len(landmarks) > 5 else None
            
            return {
                'landmarks': landmarks,
                'nose': nose,
                'left_eye': left_eye,
                'right_eye': right_eye,
                'head_center': nose
            }
        
        return None
    
    def classify_interactables(self, objects: List[Dict]) -> List[Dict]:
        """
        Clasifica objetos como interactuables basándose en su tipo
        Optimizado para aplicación dental VR con botones específicos
        
        Args:
            objects: Lista de objetos detectados
            
        Returns:
            Lista de objetos con clasificación de interactividad
        """
        # Detectar elementos UI dentales por posición y características
        dental_buttons = self._detect_dental_ui_elements(objects)
        
        # Clases que típicamente son interactuables en juegos VR (prioridad baja)
        standard_interactable_classes = {
            'bottle', 'cup', 'book', 'laptop', 'mouse', 'keyboard', 
            'cell phone', 'remote', 'scissors', 'teddy bear', 'toothbrush',
            'person', 'car', 'bicycle', 'door', 'chair', 'dining table'
        }
        
        for obj in objects:
            obj['is_interactable'] = False
            obj['interaction_type'] = 'unknown'
            obj['ui_priority'] = 0.1
            
            # Priorizar botones dentales específicos
            if self._is_main_dental_button(obj):
                obj['is_interactable'] = True
                obj['interaction_type'] = 'main_button'
                obj['ui_priority'] = 1.0
                obj['dental_element'] = True
            elif self._is_back_button(obj):
                obj['is_interactable'] = True
                obj['interaction_type'] = 'back_button'
                obj['ui_priority'] = 0.7
                obj['dental_element'] = True
            # Elementos estándar con prioridad baja
            elif obj['class_name'].lower() in standard_interactable_classes:
                obj['is_interactable'] = True
                obj['interaction_type'] = 'standard_object'
                obj['ui_priority'] = 0.3
                obj['dental_element'] = False
            
            obj['interaction_priority'] = self._calculate_interaction_priority(obj)
        
        return objects
    
    def _calculate_interaction_priority(self, obj: Dict) -> float:
        """
        Calcula la prioridad de interacción de un objeto
        Prioriza elementos UI dentales específicos
        
        Args:
            obj: Objeto detectado
            
        Returns:
            Puntuación de prioridad (0-1)
        """
        # Si ya tiene prioridad UI asignada, usarla como base
        if 'ui_priority' in obj:
            base_priority = obj['ui_priority']
        else:
            base_priority = 0.1
        
        # Bonificaciones adicionales
        bonus = 0.0
        
        # Basado en confianza de detección
        bonus += obj['confidence'] * 0.2
        
        # Basado en tamaño (objetos más grandes suelen ser más interactuables)
        frame_area = 1920 * 1080  # Asumiendo resolución estándar
        size_ratio = obj['area'] / frame_area
        bonus += min(size_ratio * 2, 0.2)  # Máximo 0.2 por tamaño
        
        # Prioridad extra para elementos dentales
        if obj.get('dental_element', False):
            if obj.get('interaction_type') == 'main_button':
                return min(base_priority + bonus + 0.3, 1.0)  # Máxima prioridad
            elif obj.get('interaction_type') == 'back_button':
                return min(base_priority + bonus + 0.2, 1.0)  # Alta prioridad
        
        # Objetos estándar con prioridad baja
        standard_priority_objects = {'bottle', 'cup', 'book', 'cell phone', 'remote'}
        if obj['class_name'].lower() in standard_priority_objects:
            bonus += 0.1
        
        return min(base_priority + bonus, 1.0)
    
    def _detect_dental_ui_elements(self, objects: List[Dict]) -> List[Dict]:
        """
        Detecta elementos de UI específicos para la aplicación dental
        Basado en la imagen real con botones verdes y botón morado
        
        Args:
            objects: Objetos detectados por YOLO
            
        Returns:
            Lista de elementos UI validados para aplicación dental
        """
        dental_ui_elements = []
        
        for obj in objects:
            x1, y1, x2, y2 = obj['bbox']
            w, h = x2 - x1, y2 - y1
            area = w * h
            
            # Pre-filtro básico por tamaño
            if area >= self.dental_ui_config['button_min_area']:
                aspect_ratio = w / h if h > 0 else 0
                
                # Filtro por proporción típica de botones UI
                if 0.3 <= aspect_ratio <= 4.0:
                    # Añadir información de área para validación
                    obj['area'] = area
                    obj['aspect_ratio'] = aspect_ratio
                    
                    # Clasificar como posible elemento dental
                    obj['potential_dental_element'] = True
                    dental_ui_elements.append(obj)
        
        self.logger.info(f"Pre-filtrados {len(dental_ui_elements)} elementos UI potenciales")
        return dental_ui_elements
    
    def _is_main_dental_button(self, obj: Dict) -> bool:
        """
        Determina si un objeto es uno de los 3 botones principales dentales
        
        Args:
            obj: Objeto detectado
            
        Returns:
            True si es un botón principal
        """
        x, y, w, h = obj['bbox']
        area = obj['area']
        
        # Verificar área mínima
        if area < self.dental_ui_config['button_min_area']:
            return False
        
        # Verificar tamaño mínimo
        min_w, min_h = self.dental_ui_config['main_button_min_size']
        if w < min_w or h < min_h:
            return False
        
        # Posición relativa (usar dimensiones reales del frame)
        # Asumir resolución típica si no está disponible
        frame_w, frame_h = 1152, 648  # Basado en el video actual
        center_x = (x + w/2) / frame_w
        center_y = (y + h/2) / frame_h
        
        # Verificar si está en alguna zona de botones principales
        button_positions = self.dental_ui_config['button_positions']
        for button_name in ['boton1', 'boton2', 'boton3']:
            pos = button_positions[button_name]
            if (pos['x_range'][0] <= center_x <= pos['x_range'][1] and
                pos['y_range'][0] <= center_y <= pos['y_range'][1]):
                obj['dental_button_name'] = button_name
                obj['dental_button_type'] = 'main'
                return True
        return False
    
    def _is_back_button(self, obj: Dict) -> bool:
        """
        Determina si un objeto es el botón de regreso
        
        Args:
            obj: Objeto detectado
            
        Returns:
            True si es el botón de regreso
        """
        x, y, w, h = obj['bbox']
        area = obj['area']
        
        # Verificar área mínima (menor que botones principales)
        if area < 4000:
            return False
        
        # Verificar tamaño mínimo
        min_w, min_h = self.dental_ui_config['back_button_min_size']
        if w < min_w or h < min_h:
            return False
        
        # Posición relativa (usar dimensiones reales del frame)
        frame_w, frame_h = 1152, 648  # Basado en el video actual
        center_x = (x + w/2) / frame_w
        center_y = (y + h/2) / frame_h
        
        # Verificar si está en la zona del botón de regreso
        back_pos = self.dental_ui_config['button_positions']['back_button']
        if (back_pos['x_range'][0] <= center_x <= back_pos['x_range'][1] and
            back_pos['y_range'][0] <= center_y <= back_pos['y_range'][1]):
            obj['dental_button_name'] = 'back_button'
            obj['dental_button_type'] = 'back'
            return True
        return False
    
    def draw_detections(self, frame: np.ndarray, objects: List[Dict], 
                       hands: List[Dict], pose: Optional[Dict] = None) -> np.ndarray:
        """
        Dibuja las detecciones en el frame
        
        Args:
            frame: Frame original
            objects: Objetos detectados
            hands: Manos detectadas
            pose: Pose detectada
            
        Returns:
            Frame con detecciones dibujadas
        """
        annotated_frame = frame.copy()
        
        # Dibujar objetos
        for obj in objects:
            x1, y1, x2, y2 = obj['bbox']
            color = self.colors['interactable'] if obj.get('is_interactable', False) else (128, 128, 128)
            
            # Dibujar bounding box
            cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), color, 2)
            
            # Etiqueta
            label = f"{obj['class_name']} ({obj['confidence']:.2f})"
            if obj.get('interaction_priority', 0) > 0.5:
                label += " ⭐"
            
            cv2.putText(annotated_frame, label, (x1, y1 - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        # Dibujar manos
        for hand in hands:
            if hand['index_tip']:
                cv2.circle(annotated_frame, hand['index_tip'], 8, self.colors['hand'], -1)
                cv2.putText(annotated_frame, f"Hand {hand['handedness']}", 
                           (hand['index_tip'][0] + 10, hand['index_tip'][1]), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, self.colors['hand'], 2)
        
        # Dibujar pose (centro de cabeza)
        if pose and pose['head_center']:
            cv2.circle(annotated_frame, pose['head_center'], 6, self.colors['gaze'], -1)
            cv2.putText(annotated_frame, "Head", 
                       (pose['head_center'][0] + 10, pose['head_center'][1]), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, self.colors['gaze'], 2)
        
        return annotated_frame
    
    def process_frame(self, frame: np.ndarray) -> Dict:
        """
        Procesa un frame completo detectando todos los elementos
        
        Args:
            frame: Frame de video
            
        Returns:
            Diccionario con todas las detecciones
        """
        # Detectar objetos
        objects = self.detect_objects(frame)
        objects = self.classify_interactables(objects)
        
        # Detectar manos
        hands = self.detect_hands(frame)
        
        # Detectar pose
        pose = self.detect_pose(frame)
        
        # Crear frame anotado
        annotated_frame = self.draw_detections(frame, objects, hands, pose)
        
        return {
            'objects': objects,
            'hands': hands,
            'pose': pose,
            'annotated_frame': annotated_frame,
            'timestamp': cv2.getTickCount() / cv2.getTickFrequency()
        }


if __name__ == "__main__":
    # Ejemplo de uso
    detector = KeyPointDetector()
    
    # Test con webcam (opcional)
    cap = cv2.VideoCapture(0)
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            results = detector.process_frame(frame)
            
            # Mostrar resultados
            cv2.imshow('VR UX Analysis', results['annotated_frame'])
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
    except KeyboardInterrupt:
        pass
    finally:
        cap.release()
        cv2.destroyAllWindows()