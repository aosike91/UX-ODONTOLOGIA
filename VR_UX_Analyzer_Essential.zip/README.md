# VR Game UX Analyzer

Un sistema completo de análisis de experiencia de usuario (UX) para juegos de realidad virtual basado en análisis de video. Detecta puntos clave, rastrea movimientos, analiza interacciones y genera métricas UX avanzadas aplicando principios de usabilidad y experiencia de usuario.

## 🚀 Características Principales

### 📊 Análisis Completo de UX
- **Detección de Puntos Clave**: Identifica objetos interactuables y elementos importantes
- **Tracking de Movimiento**: Rastrea manos, controladores y cabeza del jugador
- **Análisis de Interacciones**: Detecta interacciones exitosas, fallidas y patrones de confusión
- **Métricas UX Avanzadas**: Calcula usabilidad, eficiencia, efectividad, satisfacción y más
- **Mapas de Calor**: Genera heatmaps de movimiento, atención e interacciones
- **Reportes Completos**: Genera reportes en HTML, PDF y formatos interactivos

### 🎯 Métricas UX Implementadas
- **Usabilidad**: Eficiencia de navegación, consistencia de interacción, índice de frustración
- **Efectividad**: Tasa de completación de tareas, tasa de error
- **Eficiencia**: Tiempo en tarea, directness de movimiento, economía de movimiento
- **Satisfacción**: Análisis de carga cognitiva, complejidad percibida
- **Aprendizaje**: Curva de aprendizaje, retención de habilidades, transferibilidad
- **Engagement**: Estado de flow, índice de exploración, persistencia
- **Accesibilidad**: Facilidad de interacción, adaptabilidad del usuario

### 🔥 Características Técnicas
- **Detección con IA**: Utiliza YOLO y MediaPipe para detección robusta
- **Análisis en Tiempo Real**: Procesamiento desde webcam para pruebas inmediatas
- **Configuración Flexible**: Sistema de configuración JSON personalizable
- **Múltiples Formatos**: Soporte para diversos formatos de video
- **Visualizaciones Interactivas**: Dashboards con Plotly y matplotlib
- **Procesamiento Optimizado**: Skip frames y procesamiento paralelo

## 📋 Requisitos

### Dependencias Principales
```
opencv-python >= 4.8.0
numpy >= 1.24.0
matplotlib >= 3.7.0
seaborn >= 0.12.0
pandas >= 2.0.0
scikit-learn >= 1.3.0
ultralytics >= 8.0.0
mediapipe >= 0.10.0
scipy >= 1.10.0
plotly >= 5.15.0
pillow >= 10.0.0
tqdm >= 4.65.0
jinja2
```

### Requisitos del Sistema
- Python 3.8+
- 8GB RAM mínimo (16GB recomendado)
- GPU compatible con CUDA (opcional, pero recomendado)
- Espacio en disco: ~2GB para modelos y dependencias

## ⚡ Instalación Rápida

1. **Clonar el repositorio**:
```bash
git clone https://github.com/tu-usuario/UX-VR.git
cd UX-VR
```

2. **Crear entorno virtual** (recomendado):
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# Linux/Mac
source venv/bin/activate
```

3. **Instalar dependencias**:
```bash
pip install -r requirements.txt
```

## 🎮 Uso Básico

### Análisis de Video
```bash
# Análisis básico
python vr_ux_analyzer.py --video mi_sesion_vr.mp4

# Con nombre de sesión personalizado
python vr_ux_analyzer.py --video sesion.mp4 --session "Prueba Usuario 1"

# Personalizar directorio de salida
python vr_ux_analyzer.py --video sesion.mp4 --output resultados/
```

### Análisis en Tiempo Real
```bash
# Desde webcam (útil para pruebas)
python vr_ux_analyzer.py --realtime
```

### Configuración Avanzada
```bash
# Con archivo de configuración
python vr_ux_analyzer.py --video sesion.mp4 --config config.json

# Procesar cada 2 frames (más rápido)
python vr_ux_analyzer.py --video sesion.mp4 --skip-frames 2

# Modo verbose
python vr_ux_analyzer.py --video sesion.mp4 --verbose
```

## 📱 Demo Interactivo

Ejecuta las demostraciones incluidas para familiarizarte con el sistema:

```bash
python demo.py
```

Las demos incluyen:
1. **Análisis Básico**: Crea un video de demostración y lo analiza
2. **Tiempo Real**: Análisis usando webcam
3. **Configuración Personalizada**: Muestra opciones avanzadas

## 📊 Estructura de Resultados

El análisis genera múltiples tipos de archivos:

```
resultados/
├── html/
│   └── sesion_report_20241127_143022.html      # Reporte interactivo
├── pdf/
│   └── sesion_executive_report_20241127_143022.pdf  # Reporte ejecutivo
├── json/
│   └── sesion_data_20241127_143022.json        # Datos estructurados
├── heatmaps/
│   ├── movement_heatmap.png                    # Mapa de movimiento
│   ├── attention_heatmap.png                   # Mapa de atención
│   ├── interactions_heatmap.png                # Mapa de interacciones
│   └── dwell_time_heatmap.png                  # Tiempo de permanencia
├── interactive/
│   └── sesion_dashboard_20241127_143022.html   # Dashboard interactivo
└── annotated_sesion.mp4                        # Video anotado
```

## ⚙️ Configuración Personalizada

Crea un archivo `config.json` para personalizar el análisis:

```json
{
  "detection_confidence": 0.6,
  "interaction_distance": 75,
  "tracking_history": 500,
  "skip_frames": 1,
  "save_annotated_video": true,
  "save_heatmaps": true,
  "generate_reports": true,
  "output_dir": "mis_resultados",
  "log_level": "INFO"
}
```

### Parámetros de Configuración

| Parámetro | Descripción | Valor por Defecto |
|-----------|-------------|------------------|
| `detection_confidence` | Umbral de confianza para detecciones (0-1) | 0.5 |
| `interaction_distance` | Distancia máxima para interacción (pixels) | 50 |
| `tracking_history` | Frames de historial para tracking | 300 |
| `skip_frames` | Procesar cada N frames | 1 |
| `save_annotated_video` | Guardar video con anotaciones | true |
| `save_heatmaps` | Generar mapas de calor | true |
| `generate_reports` | Crear reportes automáticamente | true |
| `output_dir` | Directorio de salida | "results" |
| `log_level` | Nivel de logging (DEBUG/INFO/WARNING) | "INFO" |

## 📈 Interpretación de Métricas

### Puntuación UX General
- **90-100%**: Excelente experiencia de usuario
- **80-89%**: Buena experiencia, mejoras menores
- **70-79%**: Experiencia aceptable, algunas mejoras necesarias
- **60-69%**: Por debajo del promedio, mejoras importantes
- **<60%**: Experiencia deficiente, requiere rediseño

### Métricas Específicas

#### Eficiencia de Navegación
- **>80%**: Navegación muy intuitiva
- **60-80%**: Navegación aceptable
- **<60%**: Problemas de wayfinding

#### Tasa de Completación de Tareas
- **>90%**: Excelente usabilidad
- **80-90%**: Buena usabilidad
- **<80%**: Revisar diseño de tareas

#### Carga Cognitiva
- **<30%**: Posible subutilización
- **30-60%**: Carga óptima
- **>60%**: Sobrecarga cognitiva

## 🛠️ Desarrollo y Extensión

### Arquitectura del Sistema

```
VR UX Analyzer
├── keypoint_detector.py      # Detección de objetos y puntos clave
├── movement_tracker.py       # Tracking de movimiento
├── interaction_detector.py   # Detección de interacciones
├── behavior_analyzer.py      # Análisis de patrones de comportamiento
├── heatmap_generator.py      # Generación de mapas de calor
├── ux_metrics_calculator.py  # Cálculo de métricas UX
├── report_generator.py       # Generación de reportes
└── vr_ux_analyzer.py        # Módulo principal e integración
```

### Agregar Nuevas Métricas

1. Extender `UXMetricsCalculator` con nuevos métodos
2. Definir interpretación y recomendaciones
3. Integrar en el pipeline principal

### Personalizar Detección

1. Modificar `KeyPointDetector` para objetos específicos
2. Ajustar clasificación de interactuables
3. Implementar detección personalizada con YOLO

## 🤝 Casos de Uso

### Para Desarrolladores de Juegos VR
- **Testeo de Usabilidad**: Identifica problemas de UX antes del lanzamiento
- **Optimización de UI**: Mejora colocación y diseño de elementos
- **Análisis de Jugabilidad**: Entiende cómo los jugadores interactúan

### Para Investigadores UX
- **Estudios de Usuario**: Datos objetivos sobre comportamiento
- **Métricas Cuantitativas**: Mediciones precisas de eficiencia y efectividad
- **Análisis Longitudinal**: Seguimiento de mejoras en el tiempo

### Para QA y Testing
- **Pruebas Automatizadas**: Detecta problemas de interacción automáticamente
- **Regresión de UX**: Monitorea que cambios no empeoren la experiencia
- **Benchmarking**: Compara diferentes versiones o diseños

## 🚨 Solución de Problemas

### Problemas Comunes

**Error: "No module named 'cv2'"**
```bash
pip install opencv-python
```

**Error: "YOLO model not found"**
```bash
# El modelo se descarga automáticamente en el primer uso
# Asegúrate de tener conexión a internet
```

**Rendimiento lento**
```bash
# Usa skip_frames para procesar menos frames
python vr_ux_analyzer.py --video sesion.mp4 --skip-frames 3
```

**Webcam no detectada para tiempo real**
```bash
# Verifica que la webcam esté conectada y no en uso
# Prueba con diferentes índices: --realtime 1, --realtime 2, etc.
```

### Optimización de Rendimiento

1. **GPU**: Instala CUDA y PyTorch con soporte GPU
2. **Memoria**: Reduce `tracking_history` si hay problemas de RAM
3. **Procesamiento**: Aumenta `skip_frames` para análisis más rápido
4. **Resolución**: Redimensiona videos muy grandes antes del análisis

## 📄 Licencia

MIT License - ver archivo `LICENSE` para detalles.

## 🙏 Créditos

- **YOLO**: Ultralytics YOLOv8 para detección de objetos
- **MediaPipe**: Google MediaPipe para detección de pose y manos
- **OpenCV**: Procesamiento de video e imagen
- **Plotly**: Visualizaciones interactivas
- **Matplotlib/Seaborn**: Gráficos estáticos

## 📞 Soporte

Para reportar bugs o solicitar características:
1. Abre un issue en GitHub
2. Incluye información del sistema y logs de error
3. Proporciona video de ejemplo si es posible

## 🔄 Roadmap

### Próximas Características
- [ ] Soporte para múltiples jugadores
- [ ] Integración con eye tracking
- [ ] Análisis de audio/voz
- [ ] Plugin para Unity/Unreal
- [ ] Dashboard web en tiempo real
- [ ] Análisis comparativo entre sesiones
- [ ] Machine learning para detección de patrones avanzados

---

**VR UX Analyzer** - Mejorando la experiencia de usuario en realidad virtual mediante análisis objetivo y métricas científicas. 🥽📊