"""
VR Game UX Analyzer - Calculador de Métricas UX
Calcula métricas avanzadas de experiencia de usuario aplicando principios de UX
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
import logging
from scipy import stats
from sklearn.metrics import silhouette_score
from collections import defaultdict
import math

class UXMetricCategory(Enum):
    """Categorías de métricas UX"""
    USABILITY = "usability"
    EFFICIENCY = "efficiency" 
    EFFECTIVENESS = "effectiveness"
    SATISFACTION = "satisfaction"
    LEARNABILITY = "learnability"
    ACCESSIBILITY = "accessibility"
    ENGAGEMENT = "engagement"

@dataclass
class UXMetric:
    """Estructura para una métrica UX"""
    name: str
    value: float
    category: UXMetricCategory
    description: str
    interpretation: str
    recommendations: List[str]
    confidence: float = 1.0
    benchmark: Optional[float] = None

class UXMetricsCalculator:
    """
    Calcula métricas UX avanzadas basadas en datos de interacción del jugador
    """
    
    def __init__(self):
        """Inicializa el calculador de métricas UX"""
        
        # Configuración específica para aplicación dental VR
        self.dental_config = {
            'main_buttons_weight': 1.0,     # Peso máximo para botones principales
            'back_button_weight': 0.7,      # Peso medio para botón de regreso
            'other_elements_weight': 0.3,   # Peso bajo para otros elementos
            'target_interactions': {
                'main_buttons': 3,           # 3 botones principales a evaluar
                'back_button': 1,            # 1 botón de regreso
                'expected_main_interactions': 5,  # Interacciones esperadas con botones principales
                'expected_back_interactions': 2   # Interacciones esperadas con botón regreso
            }
        }
        
        # Benchmarks y umbrales de la industria
        self.benchmarks = {
            'task_completion_rate': 0.85,  # 85% es el estándar de la industria
            'error_rate': 0.05,  # 5% o menos es aceptable
            'time_on_task_efficiency': 0.75,  # 75% de eficiencia temporal
            'learnability_improvement': 0.20,  # 20% de mejora mínima
            'user_satisfaction_score': 0.70,  # 70% satisfacción mínima
            'cognitive_load_index': 0.60,  # Máximo 60% de carga cognitiva
            'accessibility_score': 0.80,  # 80% accesibilidad mínima
            'engagement_retention': 0.75   # 75% retención de engagement
        }
        
        # Pesos para métricas compuestas
        self.metric_weights = {
            'efficiency': {'speed': 0.4, 'accuracy': 0.35, 'economy': 0.25},
            'usability': {'completion': 0.3, 'error_rate': 0.25, 'satisfaction': 0.25, 'learnability': 0.2},
            'engagement': {'interaction_frequency': 0.3, 'session_length': 0.25, 'exploration': 0.25, 'flow_state': 0.2}
        }
        
        self.setup_logging()
    
    def setup_logging(self):
        """Configura el sistema de logging"""
        self.logger = logging.getLogger(__name__)
    
    def calculate_task_completion_metrics(self, interaction_data: List[Dict]) -> Dict[str, UXMetric]:
        """
        Calcula métricas de completación de tareas
        
        Args:
            interaction_data: Lista de interacciones del usuario
            
        Returns:
            Diccionario de métricas de completación
        """
        if not interaction_data:
            return {}
        
        df = pd.DataFrame(interaction_data)
        
        metrics = {}
        
        # 1. Tasa de Completación de Tareas (Task Completion Rate)
        if 'success' in df.columns:
            completion_rate = df['success'].mean()
        else:
            # Si no hay columna success, calcular basado en interacciones exitosas
            total_interactions = len(df)
            successful_interactions = len(df[df['type'] == 'main_button']) if 'type' in df.columns else total_interactions
            completion_rate = successful_interactions / total_interactions if total_interactions > 0 else 0.0
            
        metrics['task_completion_rate'] = UXMetric(
            name="Tasa de Completación de Tareas",
            value=completion_rate,
            category=UXMetricCategory.EFFECTIVENESS,
            description="Porcentaje de tareas completadas exitosamente",
            interpretation=self._interpret_completion_rate(completion_rate),
            recommendations=self._get_completion_recommendations(completion_rate),
            benchmark=self.benchmarks['task_completion_rate']
        )
        
        # 2. Tiempo Promedio en Tarea (Time on Task)
        if 'response_time' in df.columns and not df['response_time'].isna().all():
            avg_time = df['response_time'].mean()
            time_efficiency = self._calculate_time_efficiency(df['response_time'].values)
        elif 'timestamp' in df.columns:
            # Calcular tiempo basado en timestamps de interacciones
            df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
            time_diffs = df['timestamp'].diff().dt.total_seconds()
            avg_time = time_diffs.mean() if not time_diffs.isna().all() else 0.0
            time_efficiency = 0.8  # Valor por defecto
        else:
            avg_time = 0.0
            time_efficiency = 0.0
            
        metrics['time_on_task'] = UXMetric(
            name="Tiempo Promedio en Tarea",
            value=avg_time,
            category=UXMetricCategory.EFFICIENCY,
            description="Tiempo promedio para completar tareas",
            interpretation=f"Tiempo promedio: {avg_time:.2f}s, Eficiencia: {time_efficiency:.1%}",
            recommendations=self._get_time_recommendations(avg_time, time_efficiency)
        )
        
        # 3. Tasa de Error (Error Rate)
        if 'success' in df.columns:
            error_rate = 1 - df['success'].mean()
        else:
            # Calcular tasa de error basada en tipos de interacción
            total_interactions = len(df)
            failed_interactions = len(df[df['type'] == 'failed']) if 'type' in df.columns else 0
            error_rate = failed_interactions / total_interactions if total_interactions > 0 else 0.0
            
        metrics['error_rate'] = UXMetric(
            name="Tasa de Error",
            value=error_rate,
            category=UXMetricCategory.EFFECTIVENESS,
            description="Proporción de interacciones fallidas",
            interpretation=self._interpret_error_rate(error_rate),
            recommendations=self._get_error_recommendations(error_rate),
                benchmark=self.benchmarks['error_rate']
            )
        
        return metrics
    
    def calculate_usability_metrics(self, interaction_data: List[Dict], 
                                  movement_data: List[Dict]) -> Dict[str, UXMetric]:
        """
        Calcula métricas de usabilidad
        
        Args:
            interaction_data: Datos de interacciones
            movement_data: Datos de movimiento
            
        Returns:
            Métricas de usabilidad
        """
        metrics = {}
        
        # 1. Eficiencia de Navegación
        if movement_data:
            nav_efficiency = self._calculate_navigation_efficiency(movement_data)
            
            metrics['navigation_efficiency'] = UXMetric(
                name="Eficiencia de Navegación",
                value=nav_efficiency,
                category=UXMetricCategory.EFFICIENCY,
                description="Qué tan directa y eficiente es la navegación del usuario",
                interpretation=self._interpret_navigation_efficiency(nav_efficiency),
                recommendations=self._get_navigation_recommendations(nav_efficiency)
            )
        
        # 2. Consistencia de Interacción
        if interaction_data:
            interaction_consistency = self._calculate_interaction_consistency(interaction_data)
            
            metrics['interaction_consistency'] = UXMetric(
                name="Consistencia de Interacción",
                value=interaction_consistency,
                category=UXMetricCategory.USABILITY,
                description="Consistencia en patrones de interacción del usuario",
                interpretation=self._interpret_consistency(interaction_consistency),
                recommendations=self._get_consistency_recommendations(interaction_consistency)
            )
        
        # 3. Índice de Frustración
        frustration_index = self._calculate_frustration_index(interaction_data, movement_data)
        
        metrics['frustration_index'] = UXMetric(
            name="Índice de Frustración",
            value=frustration_index,
            category=UXMetricCategory.SATISFACTION,
            description="Indicador de frustración basado en patrones de comportamiento",
            interpretation=self._interpret_frustration(frustration_index),
            recommendations=self._get_frustration_recommendations(frustration_index)
        )
        
        return metrics
    
    def calculate_dental_ui_metrics(self, interaction_data: List[Dict]) -> Dict[str, UXMetric]:
        """
        Calcula métricas específicas para la aplicación dental VR
        Enfocado en botones principales y botón de regreso
        
        Args:
            interaction_data: Lista de interacciones del usuario
            
        Returns:
            Diccionario de métricas específicas dentales
        """
        if not interaction_data:
            # Retornar métricas por defecto cuando no hay datos
            return {
                'main_buttons_effectiveness': UXMetric(
                    name="Efectividad Botones Principales",
                    value=0.0,
                    category=UXMetricCategory.EFFECTIVENESS,
                    description="Sin datos de interacciones con botones principales",
                    interpretation="No se detectaron interacciones",
                    recommendations=["Verificar detección de UI", "Revisar configuración dental"],
                    benchmark=0.90
                ),
                'interaction_focus': UXMetric(
                    name="Enfoque de Interacción", 
                    value=0.0,
                    category=UXMetricCategory.USABILITY,
                    description="Sin datos de enfoque de interacción",
                    interpretation="No se detectaron interacciones",
                    recommendations=["Verificar tracking de usuario"],
                    benchmark=0.75
                )
            }
        
        metrics = {}
        df = pd.DataFrame(interaction_data)
        
        # Crear columnas por defecto si no existen
        default_columns = {
            'interaction_type': 'unknown',
            'success': True,  # Asumir éxito por defecto
            'timestamp': 0,
            'duration': 1.0,
            'x': 0,
            'y': 0
        }
        
        for col, default_val in default_columns.items():
            if col not in df.columns:
                df[col] = default_val
        
        # Separar interacciones por tipo de elemento UI
        main_button_interactions = df[df['interaction_type'] == 'main_button']
        back_button_interactions = df[df['interaction_type'] == 'back_button']
        other_interactions = df[~df['interaction_type'].isin(['main_button', 'back_button'])]
        
        # 1. Efectividad de Botones Principales
        if not main_button_interactions.empty and 'success' in main_button_interactions.columns:
            main_button_success_rate = main_button_interactions['success'].mean()
        else:
            main_button_success_rate = len(main_button_interactions) / len(df) if len(df) > 0 else 0.0
            
        if not main_button_interactions.empty:
            
            metrics['main_buttons_effectiveness'] = UXMetric(
                name="Efectividad Botones Principales",
                value=main_button_success_rate,
                category=UXMetricCategory.EFFECTIVENESS,
                description="Tasa de éxito en interacciones con los 3 botones principales",
                interpretation=self._interpret_dental_effectiveness(main_button_success_rate, 'main'),
                recommendations=self._get_dental_recommendations(main_button_success_rate, 'main'),
                benchmark=0.90  # 90% esperado para botones principales
            )
        
        # 2. Efectividad del Botón de Regreso
        if not back_button_interactions.empty and 'success' in back_button_interactions.columns:
            back_button_success_rate = back_button_interactions['success'].mean()
        else:
            back_button_success_rate = len(back_button_interactions) / len(df) if len(df) > 0 else 0.0
            
        if not back_button_interactions.empty:
            
            metrics['back_button_effectiveness'] = UXMetric(
                name="Efectividad Botón Regreso",
                value=back_button_success_rate,
                category=UXMetricCategory.USABILITY,
                description="Tasa de éxito en interacciones con el botón de regreso",
                interpretation=self._interpret_dental_effectiveness(back_button_success_rate, 'back'),
                recommendations=self._get_dental_recommendations(back_button_success_rate, 'back'),
                benchmark=0.85  # 85% esperado para botón de regreso
            )
        
        # 3. Priorización de Interacciones (usuarios focalizan en elementos correctos)
        total_interactions = len(df)
        main_interactions_count = len(main_button_interactions)
        back_interactions_count = len(back_button_interactions)
        other_interactions_count = len(other_interactions)
        
        # Calcular distribución ideal vs real
        ideal_main_ratio = 0.60    # 60% de interacciones deberían ser con botones principales
        ideal_back_ratio = 0.25    # 25% con botón de regreso
        ideal_other_ratio = 0.15   # 15% con otros elementos
        
        actual_main_ratio = main_interactions_count / max(total_interactions, 1)
        actual_back_ratio = back_interactions_count / max(total_interactions, 1)
        actual_other_ratio = other_interactions_count / max(total_interactions, 1)
        
        # Calcular desviación de la distribución ideal
        distribution_score = 1 - (abs(actual_main_ratio - ideal_main_ratio) + 
                                 abs(actual_back_ratio - ideal_back_ratio) + 
                                 abs(actual_other_ratio - ideal_other_ratio)) / 2
        
        metrics['interaction_focus'] = UXMetric(
            name="Enfoque de Interacción",
            value=max(0, distribution_score),
            category=UXMetricCategory.USABILITY,
            description="Qué tan bien el usuario se enfoca en los elementos UI principales",
            interpretation=self._interpret_interaction_focus(distribution_score),
            recommendations=self._get_focus_recommendations(distribution_score),
            benchmark=0.75  # 75% de enfoque esperado
        )
        
        # 4. Eficiencia de Navegación Dental
        if total_interactions > 0:
            # Calcular tiempo promedio entre interacciones con botones principales
            if len(main_button_interactions) > 1 and 'timestamp' in main_button_interactions.columns:
                main_timestamps = main_button_interactions['timestamp'].sort_values()
                avg_main_interval = main_timestamps.diff().mean() if len(main_timestamps) > 1 else 0
                
                # Normalizar: menor tiempo = mayor eficiencia (inverso)
                navigation_efficiency = max(0, 1 - (avg_main_interval / 10))  # Normalizar a 10 segundos
            else:
                navigation_efficiency = 0
            
            metrics['dental_navigation_efficiency'] = UXMetric(
                name="Eficiencia Navegación Dental",
                value=navigation_efficiency,
                category=UXMetricCategory.EFFICIENCY,
                description="Eficiencia en la navegación entre elementos UI dentales",
                interpretation=self._interpret_navigation_efficiency(navigation_efficiency),
                recommendations=self._get_navigation_efficiency_recommendations(navigation_efficiency),
                benchmark=0.70  # 70% de eficiencia esperada
            )
        
        return metrics
    
    def _interpret_dental_effectiveness(self, rate: float, button_type: str) -> str:
        """Interpreta la efectividad de botones dentales"""
        if rate >= 0.90:
            return "Excelente: Los usuarios interactúan exitosamente con los botones"
        elif rate >= 0.75:
            return "Bueno: Efectividad aceptable, pequeñas mejoras posibles"
        elif rate >= 0.60:
            return "Regular: Se requieren mejoras en el diseño de botones"
        else:
            return "Crítico: Los botones necesitan rediseño urgente"
    
    def _get_dental_recommendations(self, rate: float, button_type: str) -> List[str]:
        """Obtiene recomendaciones específicas para botones dentales"""
        recommendations = []
        
        if rate < 0.75:
            if button_type == 'main':
                recommendations.extend([
                    "Aumentar el tamaño de los 3 botones principales",
                    "Mejorar el contraste visual de los botones",
                    "Considerar feedback háptico para confirmación",
                    "Revisar la posición de los botones en el espacio VR"
                ])
            elif button_type == 'back':
                recommendations.extend([
                    "Hacer más visible el botón de regreso",
                    "Usar iconografía más reconocible (flecha, 'Atrás')",
                    "Considerar posición alternativa más accesible",
                    "Añadir confirmación antes de regresar"
                ])
        
        if rate < 0.60:
            recommendations.extend([
                "Realizar pruebas de usuario para identificar problemas específicos",
                "Considerar tutorial o guía visual",
                "Evaluar si la interfaz es intuitiva para usuarios no técnicos"
            ])
        
        return recommendations
    
    def _interpret_interaction_focus(self, score: float) -> str:
        """Interpreta el enfoque de interacción"""
        if score >= 0.80:
            return "Excelente: Usuarios se enfocan correctamente en elementos principales"
        elif score >= 0.65:
            return "Bueno: Buen enfoque con algunas distracciones menores"
        elif score >= 0.50:
            return "Regular: Usuarios se distraen con elementos secundarios"
        else:
            return "Crítico: Usuarios no identifican elementos principales claramente"
    
    def _get_focus_recommendations(self, score: float) -> List[str]:
        """Obtiene recomendaciones para mejorar el enfoque"""
        recommendations = []
        
        if score < 0.65:
            recommendations.extend([
                "Aumentar prominencia visual de botones principales",
                "Reducir elementos distractores en la interfaz",
                "Usar jerarquía visual más clara",
                "Implementar animaciones sutiles en botones principales"
            ])
        
        if score < 0.50:
            recommendations.extend([
                "Rediseñar completamente la jerarquía visual",
                "Considerar usar colores más contrastantes",
                "Simplificar la interfaz eliminando elementos innecesarios",
                "Agregar indicadores direccionales o tutoriales"
            ])
        
        return recommendations
    
    def _interpret_navigation_efficiency(self, efficiency: float) -> str:
        """Interpreta la eficiencia de navegación"""
        if efficiency >= 0.80:
            return "Excelente: Navegación muy fluida y eficiente"
        elif efficiency >= 0.65:
            return "Bueno: Navegación eficiente con tiempo razonable"
        elif efficiency >= 0.50:
            return "Regular: Navegación lenta, posibles mejoras"
        else:
            return "Crítico: Navegación muy lenta o confusa"
    
    def _get_navigation_efficiency_recommendations(self, efficiency: float) -> List[str]:
        """Obtiene recomendaciones para mejorar eficiencia de navegación"""
        recommendations = []
        
        if efficiency < 0.65:
            recommendations.extend([
                "Optimizar la posición de botones para acceso más rápido",
                "Reducir tiempo de respuesta visual de los botones",
                "Implementar shortcuts o gestos rápidos",
                "Mejorar la predictibilidad de la navegación"
            ])
        
        if efficiency < 0.50:
            recommendations.extend([
                "Revisar completamente el flujo de navegación",
                "Considerar reorganizar elementos por frecuencia de uso",
                "Implementar navegación por voz como alternativa",
                "Simplificar el número de pasos requeridos"
            ])
        
        return recommendations
    
    def calculate_learnability_metrics(self, interaction_data: List[Dict],
                                     session_segments: Optional[List[Dict]] = None) -> Dict[str, UXMetric]:
        """
        Calcula métricas de aprendizaje y curva de aprendizaje
        
        Args:
            interaction_data: Datos de interacciones ordenados temporalmente
            session_segments: Segmentos de sesión opcionales
            
        Returns:
            Métricas de aprendizaje
        """
        metrics = {}
        
        if not interaction_data:
            return metrics
        
        df = pd.DataFrame(interaction_data)
        
        # 1. Tasa de Mejora (Learning Curve)
        improvement_rate = self._calculate_learning_curve(df)
        
        metrics['learning_rate'] = UXMetric(
            name="Tasa de Aprendizaje",
            value=improvement_rate,
            category=UXMetricCategory.LEARNABILITY,
            description="Velocidad de mejora del usuario a lo largo del tiempo",
            interpretation=self._interpret_learning_rate(improvement_rate),
            recommendations=self._get_learning_recommendations(improvement_rate),
            benchmark=self.benchmarks['learnability_improvement']
        )
        
        # 2. Retención de Habilidades
        skill_retention = self._calculate_skill_retention(df)
        
        metrics['skill_retention'] = UXMetric(
            name="Retención de Habilidades",
            value=skill_retention,
            category=UXMetricCategory.LEARNABILITY,
            description="Capacidad del usuario para mantener habilidades adquiridas",
            interpretation=self._interpret_skill_retention(skill_retention),
            recommendations=self._get_retention_recommendations(skill_retention)
        )
        
        # 3. Índice de Transferibilidad
        transferability = self._calculate_skill_transferability(df)
        
        metrics['skill_transferability'] = UXMetric(
            name="Transferibilidad de Habilidades",
            value=transferability,
            category=UXMetricCategory.LEARNABILITY,
            description="Capacidad de aplicar habilidades aprendidas en nuevos contextos",
            interpretation=self._interpret_transferability(transferability),
            recommendations=self._get_transferability_recommendations(transferability)
        )
        
        return metrics
    
    def calculate_cognitive_load_metrics(self, behavior_data: Dict) -> Dict[str, UXMetric]:
        """
        Calcula métricas de carga cognitiva
        
        Args:
            behavior_data: Datos de análisis de comportamiento
            
        Returns:
            Métricas de carga cognitiva
        """
        metrics = {}
        
        # 1. Índice de Carga Cognitiva Global
        cognitive_load = self._calculate_cognitive_load_index(behavior_data)
        
        metrics['cognitive_load_index'] = UXMetric(
            name="Índice de Carga Cognitiva",
            value=cognitive_load,
            category=UXMetricCategory.USABILITY,
            description="Medida de la carga mental impuesta al usuario",
            interpretation=self._interpret_cognitive_load(cognitive_load),
            recommendations=self._get_cognitive_load_recommendations(cognitive_load),
            benchmark=self.benchmarks['cognitive_load_index']
        )
        
        # 2. Complejidad de Tarea Percibida
        task_complexity = self._calculate_perceived_task_complexity(behavior_data)
        
        metrics['perceived_complexity'] = UXMetric(
            name="Complejidad Percibida",
            value=task_complexity,
            category=UXMetricCategory.SATISFACTION,
            description="Complejidad de las tareas según el comportamiento del usuario",
            interpretation=self._interpret_task_complexity(task_complexity),
            recommendations=self._get_complexity_recommendations(task_complexity)
        )
        
        return metrics
    
    def calculate_engagement_metrics(self, interaction_data: List[Dict],
                                   session_duration: float,
                                   movement_data: List[Dict]) -> Dict[str, UXMetric]:
        """
        Calcula métricas de engagement y flow
        
        Args:
            interaction_data: Datos de interacciones
            session_duration: Duración total de la sesión
            movement_data: Datos de movimiento
            
        Returns:
            Métricas de engagement
        """
        metrics = {}
        
        # 1. Índice de Engagement
        engagement_score = self._calculate_engagement_index(
            interaction_data, session_duration, movement_data
        )
        
        metrics['engagement_index'] = UXMetric(
            name="Índice de Engagement",
            value=engagement_score,
            category=UXMetricCategory.ENGAGEMENT,
            description="Nivel de compromiso y participación del usuario",
            interpretation=self._interpret_engagement(engagement_score),
            recommendations=self._get_engagement_recommendations(engagement_score),
            benchmark=self.benchmarks['engagement_retention']
        )
        
        # 2. Indicador de Estado de Flow
        flow_score = self._calculate_flow_state_indicator(interaction_data, movement_data)
        
        metrics['flow_state'] = UXMetric(
            name="Estado de Flow",
            value=flow_score,
            category=UXMetricCategory.ENGAGEMENT,
            description="Medida del estado de inmersión y concentración",
            interpretation=self._interpret_flow_state(flow_score),
            recommendations=self._get_flow_recommendations(flow_score)
        )
        
        # 3. Índice de Exploración
        exploration_index = self._calculate_exploration_index(movement_data, interaction_data)
        
        metrics['exploration_index'] = UXMetric(
            name="Índice de Exploración",
            value=exploration_index,
            category=UXMetricCategory.ENGAGEMENT,
            description="Medida de la tendencia exploratoria del usuario",
            interpretation=self._interpret_exploration(exploration_index),
            recommendations=self._get_exploration_recommendations(exploration_index)
        )
        
        return metrics
    
    def calculate_accessibility_metrics(self, interaction_data: List[Dict],
                                      movement_data: List[Dict]) -> Dict[str, UXMetric]:
        """
        Calcula métricas de accesibilidad
        
        Args:
            interaction_data: Datos de interacciones
            movement_data: Datos de movimiento
            
        Returns:
            Métricas de accesibilidad
        """
        metrics = {}
        
        # 1. Facilidad de Interacción
        interaction_ease = self._calculate_interaction_ease(interaction_data, movement_data)
        
        metrics['interaction_ease'] = UXMetric(
            name="Facilidad de Interacción",
            value=interaction_ease,
            category=UXMetricCategory.ACCESSIBILITY,
            description="Qué tan fácil es para el usuario realizar interacciones",
            interpretation=self._interpret_interaction_ease(interaction_ease),
            recommendations=self._get_interaction_ease_recommendations(interaction_ease)
        )
        
        # 2. Adaptabilidad del Usuario
        user_adaptability = self._calculate_user_adaptability(movement_data)
        
        metrics['user_adaptability'] = UXMetric(
            name="Adaptabilidad del Usuario",
            value=user_adaptability,
            category=UXMetricCategory.ACCESSIBILITY,
            description="Capacidad del usuario para adaptarse a la interfaz",
            interpretation=self._interpret_adaptability(user_adaptability),
            recommendations=self._get_adaptability_recommendations(user_adaptability)
        )
        
        return metrics
    
    def calculate_composite_ux_score(self, all_metrics: Dict[str, Dict[str, UXMetric]]) -> UXMetric:
        """
        Calcula puntuación UX compuesta basada en todas las métricas
        
        Args:
            all_metrics: Diccionario con todas las métricas calculadas
            
        Returns:
            Métrica UX compuesta
        """
        # Recopilar todas las métricas por categoría
        category_scores = defaultdict(list)
        
        for metric_group in all_metrics.values():
            for metric in metric_group.values():
                category_scores[metric.category].append(metric.value)
        
        # Calcular puntuaciones por categoría
        category_averages = {}
        for category, scores in category_scores.items():
            if scores:
                category_averages[category] = np.mean(scores)
        
        # Pesos para categorías (sumando 1.0)
        category_weights = {
            UXMetricCategory.USABILITY: 0.25,
            UXMetricCategory.EFFICIENCY: 0.20,
            UXMetricCategory.EFFECTIVENESS: 0.20,
            UXMetricCategory.SATISFACTION: 0.15,
            UXMetricCategory.LEARNABILITY: 0.10,
            UXMetricCategory.ENGAGEMENT: 0.10
        }
        
        # Calcular puntuación compuesta
        composite_score = 0.0
        total_weight = 0.0
        
        for category, weight in category_weights.items():
            if category in category_averages:
                composite_score += category_averages[category] * weight
                total_weight += weight
        
        if total_weight > 0:
            composite_score = composite_score / total_weight
        
        return UXMetric(
            name="Puntuación UX Compuesta",
            value=composite_score,
            category=UXMetricCategory.USABILITY,
            description="Puntuación general de experiencia de usuario",
            interpretation=self._interpret_composite_score(composite_score),
            recommendations=self._get_composite_recommendations(composite_score, category_averages)
        )
    
    # Métodos auxiliares para cálculos específicos
    
    def _calculate_time_efficiency(self, response_times: np.ndarray) -> float:
        """Calcula eficiencia temporal basada en distribución de tiempos"""
        if len(response_times) < 2:
            return 0.5
        
        # Usar percentil 25 como referencia de eficiencia
        efficient_time = np.percentile(response_times, 25)
        avg_time = np.mean(response_times)
        
        return min(efficient_time / avg_time, 1.0) if avg_time > 0 else 0.5
    
    def _calculate_navigation_efficiency(self, movement_data: List[Dict]) -> float:
        """Calcula eficiencia de navegación basada en directness y smoothness"""
        if len(movement_data) < 10:
            return 0.5
        
        # Agrupar por body_part y calcular métricas
        efficiency_scores = []
        
        df = pd.DataFrame(movement_data)
        for body_part in df['body_part'].unique():
            part_data = df[df['body_part'] == body_part]
            positions = [data['position'] for data in part_data.to_dict('records')]
            
            if len(positions) > 2:
                # Calcular directness
                total_distance = sum(
                    np.linalg.norm(np.array(positions[i]) - np.array(positions[i-1]))
                    for i in range(1, len(positions))
                )
                straight_distance = np.linalg.norm(
                    np.array(positions[-1]) - np.array(positions[0])
                )
                
                directness = straight_distance / max(total_distance, 1)
                efficiency_scores.append(directness)
        
        return np.mean(efficiency_scores) if efficiency_scores else 0.5
    
    def _calculate_interaction_consistency(self, interaction_data: List[Dict]) -> float:
        """Calcula consistencia en patrones de interacción"""
        if len(interaction_data) < 5:
            return 0.5
        
        df = pd.DataFrame(interaction_data)
        
        # Analizar consistencia en tiempos de respuesta por tipo
        consistency_scores = []
        
        for interaction_type in df['type'].unique():
            type_data = df[df['type'] == interaction_type]
            if len(type_data) > 2 and 'response_time' in type_data.columns:
                response_times = type_data['response_time'].dropna()
                if len(response_times) > 1:
                    cv = np.std(response_times) / np.mean(response_times)
                    consistency = 1.0 / (1.0 + cv)  # Menor CV = mayor consistencia
                    consistency_scores.append(consistency)
        
        return np.mean(consistency_scores) if consistency_scores else 0.5
    
    def _calculate_frustration_index(self, interaction_data: List[Dict], 
                                   movement_data: List[Dict]) -> float:
        """Calcula índice de frustración basado en múltiples indicadores"""
        frustration_indicators = []
        
        # Indicador 1: Tasa de errores consecutivos
        if interaction_data:
            df = pd.DataFrame(interaction_data)
            if 'success' in df.columns:
                consecutive_failures = 0
                max_consecutive = 0
                for success in df['success']:
                    if not success:
                        consecutive_failures += 1
                        max_consecutive = max(max_consecutive, consecutive_failures)
                    else:
                        consecutive_failures = 0
                
                frustration_indicators.append(min(max_consecutive / 5.0, 1.0))
        
        # Indicador 2: Variabilidad excesiva en movimiento
        if movement_data:
            velocities = [data['velocity'] for data in movement_data if 'velocity' in data]
            if velocities:
                velocity_cv = np.std(velocities) / max(np.mean(velocities), 1)
                frustration_indicators.append(min(velocity_cv / 2.0, 1.0))
        
        return np.mean(frustration_indicators) if frustration_indicators else 0.0
    
    def _calculate_learning_curve(self, df: pd.DataFrame) -> float:
        """Calcula tasa de mejora en el aprendizaje"""
        if len(df) < 10:
            return 0.0
        
        # Dividir en segmentos temporales y comparar rendimiento
        n_segments = 3
        segment_size = len(df) // n_segments
        
        segment_performances = []
        for i in range(n_segments):
            start_idx = i * segment_size
            end_idx = start_idx + segment_size if i < n_segments - 1 else len(df)
            segment = df.iloc[start_idx:end_idx]
            
            if 'success' in segment.columns:
                performance = segment['success'].mean()
                segment_performances.append(performance)
        
        if len(segment_performances) >= 2:
            # Calcular mejora entre primer y último segmento
            improvement = segment_performances[-1] - segment_performances[0]
            return max(improvement, 0.0)
        
        return 0.0
    
    def _calculate_skill_retention(self, df: pd.DataFrame) -> float:
        """Calcula retención de habilidades"""
        if len(df) < 20:
            return 0.5
        
        # Comparar rendimiento en diferentes ventanas temporales
        if 'success' not in df.columns:
            return 0.5
            
        mid_point = len(df) // 2
        first_half_performance = df.iloc[:mid_point]['success'].mean()
        second_half_performance = df.iloc[mid_point:]['success'].mean()
        
        # Retención es qué tan bien se mantiene el rendimiento
        if first_half_performance > 0:
            retention = second_half_performance / first_half_performance
            return min(retention, 1.0)
        
        return 0.5
    
    def _calculate_skill_transferability(self, df: pd.DataFrame) -> float:
        """Calcula transferibilidad de habilidades entre tipos de tareas"""
        if 'type' not in df.columns or 'success' not in df.columns:
            return 0.5
        
        # Analizar rendimiento por tipo de tarea
        type_performances = df.groupby('type')['success'].mean()
        
        if len(type_performances) > 1:
            # Baja variabilidad entre tipos indica buena transferibilidad
            cv = np.std(type_performances) / max(np.mean(type_performances), 0.1)
            transferability = 1.0 / (1.0 + cv)
            return transferability
        
        return 0.5
    
    def _calculate_cognitive_load_index(self, behavior_data: Dict) -> float:
        """Calcula índice de carga cognitiva global"""
        if not behavior_data or 'cognitive_load' not in behavior_data:
            return 0.5
        
        cognitive_info = behavior_data['cognitive_load']
        
        # Usar la evaluación general si está disponible
        if 'overall_assessment' in cognitive_info:
            assessment = cognitive_info['overall_assessment']
            if 'cognitive_load_score' in assessment:
                return assessment['cognitive_load_score']
        
        return 0.5
    
    def _calculate_perceived_task_complexity(self, behavior_data: Dict) -> float:
        """Calcula complejidad percibida de las tareas"""
        complexity_indicators = []
        
        # Usar diferentes fuentes de datos de comportamiento
        if 'task_performance' in behavior_data:
            perf_data = behavior_data['task_performance']
            
            # Mayor tiempo promedio indica mayor complejidad percibida
            if 'response_times_by_type' in perf_data:
                avg_times = []
                for task_type, times in perf_data['response_times_by_type'].items():
                    if 'mean' in times:
                        avg_times.append(times['mean'])
                
                if avg_times:
                    # Normalizar tiempos (asumiendo que 5s es complejo)
                    normalized_complexity = min(np.mean(avg_times) / 5.0, 1.0)
                    complexity_indicators.append(normalized_complexity)
        
        return np.mean(complexity_indicators) if complexity_indicators else 0.5
    
    def _calculate_engagement_index(self, interaction_data: List[Dict], 
                                  session_duration: float, movement_data: List[Dict]) -> float:
        """Calcula índice de engagement"""
        engagement_factors = []
        
        # Factor 1: Frecuencia de interacciones
        if interaction_data and session_duration > 0:
            interaction_rate = len(interaction_data) / session_duration
            # Normalizar (asumiendo 1 interacción/segundo como alta)
            normalized_rate = min(interaction_rate, 1.0)
            engagement_factors.append(normalized_rate)
        
        # Factor 2: Variedad en movimiento
        if movement_data:
            positions = [data['position'] for data in movement_data if 'position' in data]
            if len(positions) > 10:
                # Calcular diversidad espacial
                unique_positions = set(positions)
                spatial_diversity = len(unique_positions) / len(positions)
                engagement_factors.append(spatial_diversity)
        
        # Factor 3: Persistencia en la sesión
        if session_duration > 0:
            # Sesiones más largas indican mayor engagement
            persistence = min(session_duration / 600.0, 1.0)  # 10 minutos como referencia
            engagement_factors.append(persistence)
        
        return np.mean(engagement_factors) if engagement_factors else 0.5
    
    def _calculate_flow_state_indicator(self, interaction_data: List[Dict], 
                                      movement_data: List[Dict]) -> float:
        """Calcula indicador de estado de flow"""
        flow_indicators = []
        
        # Flow se caracteriza por consistencia y fluidez
        
        # Indicador 1: Regularidad en interacciones
        if interaction_data:
            df = pd.DataFrame(interaction_data)
            if len(df) > 5 and 'timestamp' in df.columns:
                intervals = np.diff(df['timestamp'].values)
                if len(intervals) > 1:
                    interval_consistency = 1.0 / (1.0 + np.std(intervals) / np.mean(intervals))
                    flow_indicators.append(interval_consistency)
        
        # Indicador 2: Suavidad de movimiento
        if movement_data:
            velocities = [data['velocity'] for data in movement_data if 'velocity' in data]
            if len(velocities) > 10:
                # Menor variabilidad en velocidad indica mayor flow
                velocity_smoothness = 1.0 / (1.0 + np.std(velocities) / max(np.mean(velocities), 1))
                flow_indicators.append(velocity_smoothness)
        
        return np.mean(flow_indicators) if flow_indicators else 0.5
    
    def _calculate_exploration_index(self, movement_data: List[Dict], 
                                   interaction_data: List[Dict]) -> float:
        """Calcula índice de exploración"""
        exploration_factors = []
        
        # Factor 1: Diversidad espacial de movimiento
        if movement_data:
            positions = [data['position'] for data in movement_data if 'position' in data]
            if len(positions) > 20:
                # Usar convex hull o dispersión espacial
                position_array = np.array(positions)
                spatial_range = (
                    np.ptp(position_array[:, 0]) * np.ptp(position_array[:, 1])
                )
                # Normalizar por área de pantalla estimada
                normalized_range = min(spatial_range / (1920 * 1080), 1.0)
                exploration_factors.append(normalized_range)
        
        # Factor 2: Variedad en tipos de interacción
        if interaction_data:
            df = pd.DataFrame(interaction_data)
            if 'type' in df.columns:
                unique_types = df['type'].nunique()
                total_interactions = len(df)
                variety_ratio = unique_types / max(total_interactions, 1)
                exploration_factors.append(min(variety_ratio * 5, 1.0))  # Amplificar
        
        return np.mean(exploration_factors) if exploration_factors else 0.5
    
    def _calculate_interaction_ease(self, interaction_data: List[Dict], 
                                  movement_data: List[Dict]) -> float:
        """Calcula facilidad de interacción"""
        ease_indicators = []
        
        # Indicador 1: Tasa de éxito general
        if interaction_data:
            df = pd.DataFrame(interaction_data)
            if 'success' in df.columns:
                success_rate = df['success'].mean()
                ease_indicators.append(success_rate)
        
        # Indicador 2: Eficiencia de movimiento para interacciones
        if movement_data:
            # Menor distancia recorrida indica mayor facilidad
            nav_efficiency = self._calculate_navigation_efficiency(movement_data)
            ease_indicators.append(nav_efficiency)
        
        return np.mean(ease_indicators) if ease_indicators else 0.5
    
    def _calculate_user_adaptability(self, movement_data: List[Dict]) -> float:
        """Calcula adaptabilidad del usuario"""
        if len(movement_data) < 50:
            return 0.5
        
        # Analizar mejora en eficiencia de movimiento a lo largo del tiempo
        df = pd.DataFrame(movement_data)
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
        
        # Dividir en ventanas temporales y comparar eficiencia
        n_windows = 5
        window_size = len(df) // n_windows
        
        efficiency_trend = []
        for i in range(n_windows):
            start_idx = i * window_size
            end_idx = start_idx + window_size if i < n_windows - 1 else len(df)
            window_data = df.iloc[start_idx:end_idx].to_dict('records')
            
            window_efficiency = self._calculate_navigation_efficiency(window_data)
            efficiency_trend.append(window_efficiency)
        
        if len(efficiency_trend) >= 2:
            # Calcular tendencia de mejora
            x = np.arange(len(efficiency_trend))
            slope, _, r_value, _, _ = stats.linregress(x, efficiency_trend)
            
            # Adaptabilidad es la capacidad de mejorar
            adaptability = max(0, slope) * abs(r_value)
            return min(adaptability * 5, 1.0)  # Amplificar y limitar
        
        return 0.5
    
    # Métodos de interpretación y recomendaciones
    
    def _interpret_completion_rate(self, rate: float) -> str:
        if rate >= 0.9:
            return "Excelente tasa de completación"
        elif rate >= 0.8:
            return "Buena tasa de completación"
        elif rate >= 0.6:
            return "Tasa de completación moderada"
        else:
            return "Tasa de completación baja, requiere atención"
    
    def _interpret_error_rate(self, rate: float) -> str:
        if rate <= 0.02:
            return "Tasa de error muy baja, excelente"
        elif rate <= 0.05:
            return "Tasa de error aceptable"
        elif rate <= 0.10:
            return "Tasa de error moderada"
        else:
            return "Tasa de error alta, necesita mejoras"
    
    def _interpret_cognitive_load(self, load: float) -> str:
        if load <= 0.3:
            return "Carga cognitiva baja, posible subutilización"
        elif load <= 0.6:
            return "Carga cognitiva óptima"
        elif load <= 0.8:
            return "Carga cognitiva moderadamente alta"
        else:
            return "Carga cognitiva excesiva"
    
    def _interpret_composite_score(self, score: float) -> str:
        if score >= 0.8:
            return "Excelente experiencia de usuario"
        elif score >= 0.7:
            return "Buena experiencia de usuario"
        elif score >= 0.6:
            return "Experiencia de usuario aceptable"
        elif score >= 0.5:
            return "Experiencia de usuario por debajo del promedio"
        else:
            return "Experiencia de usuario deficiente"
    
    # Métodos para generar recomendaciones (simplificados por espacio)
    
    def _get_completion_recommendations(self, rate: float) -> List[str]:
        if rate < 0.7:
            return [
                "Simplificar las tareas más complejas",
                "Proporcionar más retroalimentación guiada",
                "Revisar la curva de aprendizaje"
            ]
        return ["Mantener el nivel actual de dificultad"]
    
    def _get_cognitive_load_recommendations(self, load: float) -> List[str]:
        if load > 0.7:
            return [
                "Reducir elementos simultáneos en pantalla",
                "Implementar progresión gradual de complejidad",
                "Añadir opciones de asistencia"
            ]
        elif load < 0.3:
            return [
                "Incrementar desafíos cognitivos",
                "Añadir elementos de multitarea controlada"
            ]
        return ["Mantener balance cognitivo actual"]
    
    def _get_composite_recommendations(self, score: float, 
                                    category_scores: Dict) -> List[str]:
        recommendations = []
        
        if score < 0.6:
            # Identificar categorías más débiles
            sorted_categories = sorted(
                category_scores.items(), 
                key=lambda x: x[1]
            )
            
            weakest_category = sorted_categories[0][0]
            
            if weakest_category == UXMetricCategory.EFFICIENCY:
                recommendations.append("Enfocar en mejoras de eficiencia")
            elif weakest_category == UXMetricCategory.USABILITY:
                recommendations.append("Priorizar mejoras de usabilidad")
            elif weakest_category == UXMetricCategory.ENGAGEMENT:
                recommendations.append("Incrementar elementos de engagement")
        
        return recommendations
    
    # Más métodos de interpretación y recomendaciones...
    # (Se incluirían todos los métodos faltantes aquí)
    
    def _interpret_navigation_efficiency(self, efficiency: float) -> str:
        return f"Eficiencia de navegación: {'Alta' if efficiency > 0.7 else 'Media' if efficiency > 0.4 else 'Baja'}"
    
    def _interpret_consistency(self, consistency: float) -> str:
        return f"Consistencia: {'Alta' if consistency > 0.7 else 'Media' if consistency > 0.5 else 'Baja'}"
    
    def _interpret_frustration(self, frustration: float) -> str:
        return f"Nivel de frustración: {'Alto' if frustration > 0.6 else 'Medio' if frustration > 0.3 else 'Bajo'}"
    
    def _interpret_learning_rate(self, rate: float) -> str:
        return f"Tasa de aprendizaje: {'Alta' if rate > 0.2 else 'Media' if rate > 0.1 else 'Baja'}"
    
    def _interpret_skill_retention(self, retention: float) -> str:
        return f"Retención de habilidades: {'Alta' if retention > 0.8 else 'Media' if retention > 0.6 else 'Baja'}"
    
    def _interpret_transferability(self, transferability: float) -> str:
        return f"Transferibilidad: {'Alta' if transferability > 0.7 else 'Media' if transferability > 0.5 else 'Baja'}"
    
    def _interpret_task_complexity(self, complexity: float) -> str:
        return f"Complejidad percibida: {'Alta' if complexity > 0.7 else 'Media' if complexity > 0.4 else 'Baja'}"
    
    def _interpret_engagement(self, engagement: float) -> str:
        return f"Nivel de engagement: {'Alto' if engagement > 0.7 else 'Medio' if engagement > 0.5 else 'Bajo'}"
    
    def _interpret_flow_state(self, flow: float) -> str:
        return f"Estado de flow: {'Alto' if flow > 0.7 else 'Medio' if flow > 0.5 else 'Bajo'}"
    
    def _interpret_exploration(self, exploration: float) -> str:
        return f"Índice de exploración: {'Alto' if exploration > 0.6 else 'Medio' if exploration > 0.3 else 'Bajo'}"
    
    def _interpret_interaction_ease(self, ease: float) -> str:
        return f"Facilidad de interacción: {'Alta' if ease > 0.7 else 'Media' if ease > 0.5 else 'Baja'}"
    
    def _interpret_adaptability(self, adaptability: float) -> str:
        return f"Adaptabilidad: {'Alta' if adaptability > 0.6 else 'Media' if adaptability > 0.3 else 'Baja'}"
    
    # Métodos de recomendaciones restantes
    def _get_time_recommendations(self, avg_time: float, efficiency: float) -> List[str]:
        recommendations = []
        if efficiency < 0.6:
            recommendations.append("Optimizar flujo de tareas para reducir tiempo")
        if avg_time > 10:
            recommendations.append("Considerar simplificar interacciones complejas")
        return recommendations or ["Tiempos de tarea apropiados"]
    
    def _get_error_recommendations(self, error_rate: float) -> List[str]:
        if error_rate > 0.1:
            return ["Mejorar retroalimentación de errores", "Revisar affordances de interfaz"]
        return ["Mantener claridad actual de interfaz"]
    
    def _get_navigation_recommendations(self, efficiency: float) -> List[str]:
        if efficiency < 0.5:
            return ["Mejorar señalización visual", "Optimizar layout espacial"]
        return ["Navegación funcionando bien"]
    
    def _get_consistency_recommendations(self, consistency: float) -> List[str]:
        if consistency < 0.6:
            return ["Estandarizar patrones de interacción", "Mejorar coherencia visual"]
        return ["Buena consistencia de interfaz"]
    
    def _get_frustration_recommendations(self, frustration: float) -> List[str]:
        if frustration > 0.4:
            return ["Implementar sistema de ayuda contextual", "Revisar puntos de fricción"]
        return ["Nivel de frustración bajo, bien"]
    
    def _get_learning_recommendations(self, rate: float) -> List[str]:
        if rate < 0.1:
            return ["Implementar tutoriales progresivos", "Añadir práctica guiada"]
        return ["Curva de aprendizaje apropiada"]
    
    def _get_retention_recommendations(self, retention: float) -> List[str]:
        if retention < 0.7:
            return ["Añadir recordatorios de funcionalidad", "Implementar práctica espaciada"]
        return ["Buena retención de habilidades"]
    
    def _get_transferability_recommendations(self, transferability: float) -> List[str]:
        if transferability < 0.5:
            return ["Mejorar consistencia entre contextos", "Añadir ejemplos de aplicación"]
        return ["Buena transferibilidad de habilidades"]
    
    def _get_complexity_recommendations(self, complexity: float) -> List[str]:
        if complexity > 0.7:
            return ["Simplificar tareas complejas", "Proporcionar más scaffolding"]
        return ["Complejidad apropiada para usuarios"]
    
    def _get_engagement_recommendations(self, engagement: float) -> List[str]:
        if engagement < 0.5:
            return ["Añadir elementos gamificados", "Incrementar interactividad"]
        return ["Buen nivel de engagement"]
    
    def _get_flow_recommendations(self, flow: float) -> List[str]:
        if flow < 0.5:
            return ["Balancear desafío y habilidad", "Reducir interrupciones"]
        return ["Estado de flow apropiado"]
    
    def _get_exploration_recommendations(self, exploration: float) -> List[str]:
        if exploration < 0.3:
            return ["Incentivar exploración", "Añadir elementos de descubrimiento"]
        elif exploration > 0.8:
            return ["Proporcionar más guía direccional"]
        return ["Buen balance exploratorio"]
    
    def _get_interaction_ease_recommendations(self, ease: float) -> List[str]:
        if ease < 0.6:
            return ["Simplificar gestos de interacción", "Mejorar feedback táctil"]
        return ["Interacciones funcionando bien"]
    
    def _get_adaptability_recommendations(self, adaptability: float) -> List[str]:
        if adaptability < 0.4:
            return ["Proporcionar más opciones de personalización", "Mejorar curva de aprendizaje"]
        return ["Buena adaptabilidad del usuario"]


if __name__ == "__main__":
    # Ejemplo de uso
    calculator = UXMetricsCalculator()
    
    # Datos simulados
    interaction_data = [
        {'timestamp': 1.0, 'type': 'select', 'success': True, 'response_time': 1.2},
        {'timestamp': 2.5, 'type': 'select', 'success': False, 'response_time': 2.1},
        {'timestamp': 4.0, 'type': 'drag', 'success': True, 'response_time': 0.8},
    ]
    
    movement_data = [
        {'timestamp': 1.0, 'position': (100, 100), 'velocity': 50, 'body_part': 'right_hand'},
        {'timestamp': 1.1, 'position': (110, 105), 'velocity': 45, 'body_part': 'right_hand'},
    ]
    
    # Calcular métricas
    completion_metrics = calculator.calculate_task_completion_metrics(interaction_data)
    usability_metrics = calculator.calculate_usability_metrics(interaction_data, movement_data)
    
    print("Métricas UX calculadas:")
    for name, metric in completion_metrics.items():
        print(f"{name}: {metric.value:.3f} - {metric.interpretation}")
    
    for name, metric in usability_metrics.items():
        print(f"{name}: {metric.value:.3f} - {metric.interpretation}")