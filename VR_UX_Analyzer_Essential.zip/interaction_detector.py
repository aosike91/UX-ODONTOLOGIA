"""
VR Game UX Analyzer - Detector de Interacciones
Detecta cuando el jugador interactúa o falla en interactuar con objetos
"""

import cv2
import numpy as np
from typing import List, Dict, Tuple, Optional
from scipy.spatial.distance import euclidean
from collections import defaultdict, deque
import logging
from dataclasses import dataclass
from enum import Enum

class InteractionType(Enum):
    """Tipos de interacciones detectadas"""
    SUCCESSFUL_SELECTION = "successful_selection"
    MISSED_SELECTION = "missed_selection"
    HOVER = "hover"
    APPROACH = "approach"
    RETREAT = "retreat"
    LOST_PLAYER = "lost_player"
    CONFUSION = "confusion"

@dataclass
class InteractionEvent:
    """Evento de interacción detectado"""
    type: InteractionType
    timestamp: float
    position: Tuple[int, int]
    target_object: Optional[Dict] = None
    confidence: float = 0.0
    duration: float = 0.0
    additional_data: Dict = None

class InteractionDetector:
    """
    Detecta interacciones del jugador con objetos en el juego VR
    """
    
    def __init__(self, interaction_distance: int = 50, hover_time_threshold: float = 1.0):
        """
        Inicializa el detector de interacciones
        
        Args:
            interaction_distance: Distancia máxima para considerar interacción (pixels)
            hover_time_threshold: Tiempo mínimo para considerar hover (segundos)
        """
        self.interaction_distance = interaction_distance
        self.hover_time_threshold = hover_time_threshold
        
        # Historial de interacciones
        self.interaction_history = []
        self.hover_states = {}  # Seguimiento de estados de hover
        self.approach_states = {}  # Seguimiento de aproximaciones
        
        # Estado del jugador
        self.player_lost_threshold = 2.0  # Segundos sin detección para considerar perdido
        self.last_player_detection = 0.0
        self.confusion_threshold = 5.0  # Movimientos erráticos por X segundos
        self.confusion_movement_history = deque(maxlen=150)  # ~5 segundos a 30fps
        
        # Objetos objetivo (se pueden definir manualmente)
        self.target_objects = []
        self.mandatory_interactions = set()  # IDs de objetos que DEBEN ser seleccionados
        
        # Estadísticas
        self.stats = {
            'total_interactions': 0,
            'successful_selections': 0,
            'missed_selections': 0,
            'confusion_events': 0,
            'player_lost_events': 0,
            'total_hover_time': 0.0,
            'objects_interacted': set(),
            'objects_missed': set()
        }
        
        self.setup_logging()
    
    def setup_logging(self):
        """Configura el sistema de logging"""
        self.logger = logging.getLogger(__name__)
    
    def set_target_objects(self, objects: List[Dict]):
        """
        Define los objetos objetivo que el jugador debe interactuar
        
        Args:
            objects: Lista de objetos con sus propiedades
        """
        self.target_objects = objects
        self.mandatory_interactions = {obj['id'] for obj in objects if obj.get('mandatory', False)}
    
    def detect_interactions(self, hands: List[Dict], objects: List[Dict], 
                          head_position: Optional[Tuple[int, int]], 
                          timestamp: float) -> List[InteractionEvent]:
        """
        Detecta interacciones en el frame actual
        
        Args:
            hands: Lista de manos detectadas
            objects: Lista de objetos detectados
            head_position: Posición de la cabeza del jugador
            timestamp: Timestamp del frame actual
            
        Returns:
            Lista de eventos de interacción detectados
        """
        events = []
        
        # Verificar si el jugador está perdido
        if not hands and not head_position:
            if timestamp - self.last_player_detection > self.player_lost_threshold:
                events.append(InteractionEvent(
                    type=InteractionType.LOST_PLAYER,
                    timestamp=timestamp,
                    position=(0, 0),
                    confidence=1.0,
                    duration=timestamp - self.last_player_detection
                ))
                self.stats['player_lost_events'] += 1
        else:
            self.last_player_detection = timestamp
        
        # Detectar interacciones de manos con objetos
        for hand in hands:
            if hand.get('index_tip'):
                hand_events = self._detect_hand_interactions(
                    hand, objects, timestamp
                )
                events.extend(hand_events)
        
        # Detectar confusión basada en patrones de movimiento
        if hands:
            confusion_event = self._detect_confusion(hands, timestamp)
            if confusion_event:
                events.append(confusion_event)
        
        # Detectar objetos perdidos (no interactuados cuando deberían)
        missed_events = self._detect_missed_objects(objects, hands, timestamp)
        events.extend(missed_events)
        
        # Actualizar estadísticas
        self._update_stats(events)
        
        # Guardar eventos en historial
        self.interaction_history.extend(events)
        
        return events
    
    def _detect_hand_interactions(self, hand: Dict, objects: List[Dict], 
                                timestamp: float) -> List[InteractionEvent]:
        """
        Detecta interacciones específicas de una mano
        
        Args:
            hand: Datos de la mano
            objects: Lista de objetos
            timestamp: Timestamp actual
            
        Returns:
            Lista de eventos de interacción
        """
        events = []
        hand_pos = hand['index_tip']
        hand_id = f"{hand['handedness']}_{hand.get('hand_index', 0)}"
        
        # Registrar movimiento para análisis de confusión
        self.confusion_movement_history.append({
            'position': hand_pos,
            'timestamp': timestamp,
            'hand_id': hand_id
        })
        
        for obj in objects:
            obj_center = obj['center']
            distance = euclidean(hand_pos, obj_center)
            obj_id = f"{obj['class_name']}_{obj_center[0]}_{obj_center[1]}"
            
            # Estados de interacción
            if distance <= self.interaction_distance:
                # Interacción directa (selección)
                selection_event = self._detect_selection(hand, obj, timestamp, distance)
                if selection_event:
                    events.append(selection_event)
                
                # Hover
                hover_event = self._detect_hover(hand_id, obj_id, obj, timestamp)
                if hover_event:
                    events.append(hover_event)
                    
            elif distance <= self.interaction_distance * 2:
                # Aproximación
                approach_event = self._detect_approach(hand_id, obj_id, obj, timestamp, distance)
                if approach_event:
                    events.append(approach_event)
            else:
                # Retiro (si estaba cerca antes)
                retreat_event = self._detect_retreat(hand_id, obj_id, obj, timestamp)
                if retreat_event:
                    events.append(retreat_event)
        
        return events
    
    def _detect_selection(self, hand: Dict, obj: Dict, timestamp: float, 
                         distance: float) -> Optional[InteractionEvent]:
        """
        Detecta eventos de selección
        
        Args:
            hand: Datos de la mano
            obj: Objeto objetivo
            timestamp: Timestamp actual
            distance: Distancia a la que está la mano
            
        Returns:
            Evento de selección si se detecta
        """
        # Criterios para selección:
        # 1. Mano muy cerca del objeto (< 30 pixels)
        # 2. Confianza alta en detección de mano
        # 3. Objeto es interactuable
        
        if (distance < 30 and 
            hand.get('confidence', 0) > 0.7 and 
            obj.get('is_interactable', False)):
            
            obj_id = f"{obj['class_name']}_{obj['center'][0]}_{obj['center'][1]}"
            
            # Verificar si no se ha registrado esta selección recientemente
            recent_selections = [
                event for event in self.interaction_history[-10:]
                if (event.type == InteractionType.SUCCESSFUL_SELECTION and
                    event.timestamp > timestamp - 1.0 and
                    event.target_object and
                    event.target_object.get('id') == obj_id)
            ]
            
            if not recent_selections:
                self.stats['objects_interacted'].add(obj_id)
                return InteractionEvent(
                    type=InteractionType.SUCCESSFUL_SELECTION,
                    timestamp=timestamp,
                    position=hand['index_tip'],
                    target_object=obj.copy(),
                    confidence=min(hand.get('confidence', 0) + obj.get('confidence', 0), 1.0),
                    additional_data={
                        'distance': distance,
                        'hand_type': hand.get('handedness', 'unknown'),
                        'object_priority': obj.get('interaction_priority', 0)
                    }
                )
        
        return None
    
    def _detect_hover(self, hand_id: str, obj_id: str, obj: Dict, 
                     timestamp: float) -> Optional[InteractionEvent]:
        """
        Detecta eventos de hover (mano cerca por tiempo prolongado)
        """
        # Inicializar estado de hover si no existe
        if obj_id not in self.hover_states:
            self.hover_states[obj_id] = {
                'start_time': timestamp,
                'hand_id': hand_id,
                'active': True
            }
            return None
        
        hover_state = self.hover_states[obj_id]
        
        if hover_state['active'] and hover_state['hand_id'] == hand_id:
            hover_duration = timestamp - hover_state['start_time']
            
            if hover_duration >= self.hover_time_threshold:
                # Hover detectado
                hover_state['active'] = False  # Evitar múltiples eventos
                self.stats['total_hover_time'] += hover_duration
                
                return InteractionEvent(
                    type=InteractionType.HOVER,
                    timestamp=timestamp,
                    position=obj['center'],
                    target_object=obj.copy(),
                    confidence=0.8,
                    duration=hover_duration,
                    additional_data={
                        'hand_id': hand_id,
                        'object_priority': obj.get('interaction_priority', 0)
                    }
                )
        
        return None
    
    def _detect_approach(self, hand_id: str, obj_id: str, obj: Dict, 
                        timestamp: float, distance: float) -> Optional[InteractionEvent]:
        """
        Detecta eventos de aproximación a objetos
        """
        if obj_id not in self.approach_states:
            self.approach_states[obj_id] = {
                'start_time': timestamp,
                'start_distance': distance,
                'hand_id': hand_id,
                'reported': False
            }
            return None
        
        approach_state = self.approach_states[obj_id]
        
        # Si la distancia está disminuyendo y no se ha reportado
        if (distance < approach_state['start_distance'] * 0.8 and 
            not approach_state['reported'] and
            approach_state['hand_id'] == hand_id):
            
            approach_state['reported'] = True
            
            return InteractionEvent(
                type=InteractionType.APPROACH,
                timestamp=timestamp,
                position=obj['center'],
                target_object=obj.copy(),
                confidence=0.6,
                duration=timestamp - approach_state['start_time'],
                additional_data={
                    'initial_distance': approach_state['start_distance'],
                    'current_distance': distance,
                    'hand_id': hand_id
                }
            )
        
        return None
    
    def _detect_retreat(self, hand_id: str, obj_id: str, obj: Dict, 
                       timestamp: float) -> Optional[InteractionEvent]:
        """
        Detecta eventos de retiro de objetos
        """
        # Limpiar estados si la mano se alejó
        if obj_id in self.hover_states:
            self.hover_states[obj_id]['active'] = False
        
        if obj_id in self.approach_states:
            approach_state = self.approach_states[obj_id]
            if approach_state['hand_id'] == hand_id and approach_state['reported']:
                # Retiro después de aproximación
                del self.approach_states[obj_id]
                
                return InteractionEvent(
                    type=InteractionType.RETREAT,
                    timestamp=timestamp,
                    position=obj['center'],
                    target_object=obj.copy(),
                    confidence=0.5,
                    additional_data={'hand_id': hand_id}
                )
        
        return None
    
    def _detect_confusion(self, hands: List[Dict], timestamp: float) -> Optional[InteractionEvent]:
        """
        Detecta estados de confusión basándose en patrones de movimiento erráticos
        """
        if len(self.confusion_movement_history) < 60:  # Necesita al menos 2 segundos de datos
            return None
        
        # Analizar patrones de movimiento en los últimos frames
        recent_movements = list(self.confusion_movement_history)[-60:]
        
        # Calcular cambios de dirección frecuentes
        direction_changes = 0
        velocities = []
        
        for i in range(1, len(recent_movements)):
            prev_pos = recent_movements[i-1]['position']
            curr_pos = recent_movements[i]['position']
            
            # Calcular velocidad
            dt = recent_movements[i]['timestamp'] - recent_movements[i-1]['timestamp']
            if dt > 0:
                velocity = euclidean(prev_pos, curr_pos) / dt
                velocities.append(velocity)
                
                # Detectar cambio de dirección
                if i > 1:
                    prev_prev_pos = recent_movements[i-2]['position']
                    
                    # Vectores de dirección
                    vec1 = (prev_pos[0] - prev_prev_pos[0], prev_pos[1] - prev_prev_pos[1])
                    vec2 = (curr_pos[0] - prev_pos[0], curr_pos[1] - prev_pos[1])
                    
                    # Producto punto normalizado para detectar cambio de dirección
                    if (vec1[0] != 0 or vec1[1] != 0) and (vec2[0] != 0 or vec2[1] != 0):
                        dot_product = vec1[0]*vec2[0] + vec1[1]*vec2[1]
                        mag1 = np.sqrt(vec1[0]**2 + vec1[1]**2)
                        mag2 = np.sqrt(vec2[0]**2 + vec2[1]**2)
                        
                        if mag1 * mag2 > 0:
                            cos_angle = dot_product / (mag1 * mag2)
                            if cos_angle < 0:  # Ángulo > 90 grados = cambio de dirección
                                direction_changes += 1
        
        # Criterios para confusión:
        # 1. Muchos cambios de dirección
        # 2. Velocidades muy variables
        # 3. Movimiento sin propósito aparente
        
        if velocities:
            velocity_std = np.std(velocities)
            avg_velocity = np.mean(velocities)
            
            confusion_score = (direction_changes / len(recent_movements)) * 100
            confusion_score += (velocity_std / max(avg_velocity, 1)) * 50
            
            if confusion_score > 30:  # Threshold ajustable
                self.stats['confusion_events'] += 1
                
                return InteractionEvent(
                    type=InteractionType.CONFUSION,
                    timestamp=timestamp,
                    position=hands[0]['index_tip'] if hands else (0, 0),
                    confidence=min(confusion_score / 100, 1.0),
                    duration=2.0,  # Duración de la ventana analizada
                    additional_data={
                        'direction_changes': direction_changes,
                        'velocity_std': velocity_std,
                        'confusion_score': confusion_score
                    }
                )
        
        return None
    
    def _detect_missed_objects(self, objects: List[Dict], hands: List[Dict], 
                              timestamp: float) -> List[InteractionEvent]:
        """
        Detecta objetos que deberían haber sido seleccionados pero no lo fueron
        """
        missed_events = []
        
        if not hands:  # No hay manos detectadas
            return missed_events
        
        # Verificar objetos con alta prioridad que no han sido interactuados
        for obj in objects:
            obj_id = f"{obj['class_name']}_{obj['center'][0]}_{obj['center'][1]}"
            
            # Criterios para objeto perdido:
            # 1. Es interactuable y tiene alta prioridad
            # 2. No ha sido seleccionado
            # 3. Mano está cerca pero no lo suficiente
            
            if (obj.get('is_interactable', False) and 
                obj.get('interaction_priority', 0) > 0.7 and
                obj_id not in self.stats['objects_interacted']):
                
                # Verificar si alguna mano está cerca pero no interactuando
                for hand in hands:
                    if hand.get('index_tip'):
                        distance = euclidean(hand['index_tip'], obj['center'])
                        
                        # Cerca pero no lo suficiente para selección
                        if 30 < distance < 100:
                            # Verificar si no se ha reportado recientemente
                            recent_missed = [
                                event for event in self.interaction_history[-20:]
                                if (event.type == InteractionType.MISSED_SELECTION and
                                    event.timestamp > timestamp - 3.0 and
                                    event.target_object and
                                    event.target_object.get('class_name') == obj['class_name'])
                            ]
                            
                            if not recent_missed:
                                self.stats['objects_missed'].add(obj_id)
                                
                                missed_events.append(InteractionEvent(
                                    type=InteractionType.MISSED_SELECTION,
                                    timestamp=timestamp,
                                    position=obj['center'],
                                    target_object=obj.copy(),
                                    confidence=0.7,
                                    additional_data={
                                        'distance': distance,
                                        'hand_position': hand['index_tip'],
                                        'priority': obj.get('interaction_priority', 0)
                                    }
                                ))
        
        return missed_events
    
    def _update_stats(self, events: List[InteractionEvent]):
        """Actualiza las estadísticas globales"""
        for event in events:
            self.stats['total_interactions'] += 1
            
            if event.type == InteractionType.SUCCESSFUL_SELECTION:
                self.stats['successful_selections'] += 1
            elif event.type == InteractionType.MISSED_SELECTION:
                self.stats['missed_selections'] += 1
    
    def get_interaction_summary(self) -> Dict:
        """
        Obtiene resumen completo de interacciones
        
        Returns:
            Resumen de estadísticas y análisis
        """
        total_events = len(self.interaction_history)
        
        # Análisis temporal
        if self.interaction_history:
            session_duration = (self.interaction_history[-1].timestamp - 
                              self.interaction_history[0].timestamp)
            interaction_rate = total_events / max(session_duration, 1)
        else:
            session_duration = 0
            interaction_rate = 0
        
        # Análisis de efectividad
        total_selections = self.stats['successful_selections'] + self.stats['missed_selections']
        success_rate = (self.stats['successful_selections'] / max(total_selections, 1)) * 100
        
        # Objetos obligatorios no interactuados
        missed_mandatory = self.mandatory_interactions - self.stats['objects_interacted']
        
        return {
            'stats': self.stats.copy(),
            'session_duration': session_duration,
            'total_events': total_events,
            'interaction_rate': interaction_rate,
            'success_rate': success_rate,
            'missed_mandatory_objects': list(missed_mandatory),
            'unique_objects_interacted': len(self.stats['objects_interacted']),
            'unique_objects_missed': len(self.stats['objects_missed'])
        }
    
    def get_interaction_timeline(self) -> List[Dict]:
        """Obtiene línea temporal de todas las interacciones"""
        return [
            {
                'timestamp': event.timestamp,
                'type': event.type.value,
                'position': event.position,
                'target_object': event.target_object['class_name'] if event.target_object else None,
                'confidence': event.confidence,
                'duration': event.duration,
                'additional_data': event.additional_data
            }
            for event in self.interaction_history
        ]
    
    def reset(self):
        """Reinicia el detector de interacciones"""
        self.interaction_history.clear()
        self.hover_states.clear()
        self.approach_states.clear()
        self.confusion_movement_history.clear()
        
        self.stats = {
            'total_interactions': 0,
            'successful_selections': 0,
            'missed_selections': 0,
            'confusion_events': 0,
            'player_lost_events': 0,
            'total_hover_time': 0.0,
            'objects_interacted': set(),
            'objects_missed': set()
        }


if __name__ == "__main__":
    # Ejemplo de uso
    detector = InteractionDetector()
    
    # Definir objetos objetivo
    target_objects = [
        {'id': 'bottle_1', 'class_name': 'bottle', 'mandatory': True, 'center': (100, 100)},
        {'id': 'cup_1', 'class_name': 'cup', 'mandatory': False, 'center': (200, 150)}
    ]
    detector.set_target_objects(target_objects)
    
    # Simular detección
    import time
    
    for i in range(50):
        timestamp = time.time()
        
        # Simular objetos detectados
        objects = [
            {
                'class_name': 'bottle',
                'center': (100, 100),
                'is_interactable': True,
                'interaction_priority': 0.8,
                'confidence': 0.9
            }
        ]
        
        # Simular mano acercándose
        hand_x = 150 - i
        hand_y = 120
        hands = [{
            'index_tip': (hand_x, hand_y),
            'handedness': 'Right',
            'confidence': 0.8
        }]
        
        events = detector.detect_interactions(hands, objects, (200, 200), timestamp)
        
        for event in events:
            print(f"Evento: {event.type.value} en {event.timestamp:.2f}")
        
        time.sleep(0.1)
    
    # Mostrar resumen
    summary = detector.get_interaction_summary()
    print(f"\nResumen: {summary['success_rate']:.1f}% de éxito")