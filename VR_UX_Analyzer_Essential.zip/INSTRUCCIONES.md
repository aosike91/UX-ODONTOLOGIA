# VR UX ANALYZER - VERSIÓN ESENCIAL

## 🚀 INSTALACIÓN RÁPIDA

1. **Instalar dependencias:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Descargar modelos YOLO (si es necesario):**
   - Los modelos se descargan automáticamente al ejecutar por primera vez
   - O descargar manualmente desde: https://github.com/ultralytics/yolov5

## 🎮 USO BÁSICO

### Analizar Video Guía (Referencia):
```bash
python vr_ux_analyzer.py --video mi_sesion_vr.mp4 --session "VideoGuia"
```

### Analizar Video de Prueba (Comparación):
```bash  
python vr_ux_analyzer.py --video video-test-usuario.mp4 --session "UsuarioPrueba"
```

## 📊 RESULTADOS

Los resultados se generan en la carpeta `results/` con:
- 📄 Reportes HTML interactivos
- 📊 PDFs ejecutivos  
- 💾 Datos JSON/CSV
- 🔥 Heatmaps visuales

## ⚙️ CONFIGURACIÓN ACTUAL

### Botones Detectados:
- **Boton1**: Verde, posición (0.125-0.275, 0.275-0.425)
- **Boton2**: Verde, posición (0.355-0.505, 0.275-0.425)  
- **Boton3**: Verde, posición (0.585-0.735, 0.275-0.425)
- **Regresar**: Púrpura, posición (0.02-0.40, 0.05-0.18)

### Personalización:
- Editar `keypoint_detector.py` para cambiar posiciones de botones
- Editar `heatmap_generator.py` para modificar visualizaciones
- Editar `ux_metrics_calculator.py` para métricas personalizadas

## 🆘 SOPORTE

Para soporte técnico o personalizaciones, contacta al desarrollador.

## 📁 ARCHIVOS EXCLUIDOS EN ESTA VERSIÓN

- Videos de ejemplo (*.mp4) - Muy pesados
- Resultados previos (results/) - Se generan automáticamente
- Cache Python (__pycache__/) - Se regenera automáticamente
- Entorno virtual (.venv/) - Se instala localmente
