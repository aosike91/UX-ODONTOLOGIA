"""
VR Game UX Analyzer - Tracker de Movimiento
Rastrea el movimiento de manos, controladores y cabeza del jugador
"""

import cv2
import numpy as np
from typing import List, Dict, Tuple, Optional, Deque
from collections import deque
from scipy.spatial.distance import euclidean
from scipy import interpolate
import logging

class MovementTracker:
    """
    Rastrea el movimiento de manos, controladores y cabeza del jugador
    """
    
    def __init__(self, max_history: int = 300, smoothing_window: int = 5):
        """
        Inicializa el tracker de movimiento
        
        Args:
            max_history: Máximo número de frames a mantener en historial
            smoothing_window: Ventana para suavizado de movimiento
        """
        self.max_history = max_history
        self.smoothing_window = smoothing_window
        
        # Historiales de movimiento
        self.hand_tracks = {'left': deque(maxlen=max_history), 
                           'right': deque(maxlen=max_history)}
        self.head_track = deque(maxlen=max_history)
        self.gaze_track = deque(maxlen=max_history)
        
        # Estado actual
        self.current_frame = 0
        self.fps = 30  # FPS por defecto, se actualizará dinámicamente
        
        # Métricas de movimiento
        self.movement_stats = {
            'total_distance': {'left_hand': 0, 'right_hand': 0, 'head': 0},
            'avg_velocity': {'left_hand': 0, 'right_hand': 0, 'head': 0},
            'max_velocity': {'left_hand': 0, 'right_hand': 0, 'head': 0},
            'acceleration_events': {'left_hand': 0, 'right_hand': 0, 'head': 0},
            'stationary_periods': [],
            'rapid_movements': []
        }
        
        self.setup_logging()
    
    def setup_logging(self):
        """Configura el sistema de logging"""
        self.logger = logging.getLogger(__name__)
    
    def update_fps(self, fps: float):
        """Actualiza el FPS para cálculos de velocidad correctos"""
        self.fps = fps
    
    def add_hand_position(self, hand_type: str, position: Tuple[int, int], 
                         timestamp: float, confidence: float = 1.0):
        """
        Añade una nueva posición de mano al tracking
        
        Args:
            hand_type: 'left' o 'right'
            position: Coordenadas (x, y) de la mano
            timestamp: Timestamp del frame
            confidence: Confianza de la detección
        """
        if hand_type not in self.hand_tracks:
            return
        
        track_data = {
            'position': position,
            'timestamp': timestamp,
            'frame': self.current_frame,
            'confidence': confidence,
            'velocity': None,
            'acceleration': None
        }
        
        # Calcular velocidad si hay historial
        if len(self.hand_tracks[hand_type]) > 0:
            prev_data = self.hand_tracks[hand_type][-1]
            dt = timestamp - prev_data['timestamp']
            if dt > 0:
                distance = euclidean(position, prev_data['position'])
                velocity = distance / dt  # pixels/second
                track_data['velocity'] = velocity
                
                # Calcular aceleración
                if prev_data['velocity'] is not None:
                    acceleration = (velocity - prev_data['velocity']) / dt
                    track_data['acceleration'] = acceleration
                    
                    # Detectar eventos de aceleración significativa
                    if abs(acceleration) > 1000:  # Threshold ajustable
                        self.movement_stats['acceleration_events'][f'{hand_type}_hand'] += 1
        
        self.hand_tracks[hand_type].append(track_data)
        
        # Actualizar estadísticas
        self._update_movement_stats(hand_type, track_data)
    
    def add_head_position(self, position: Tuple[int, int], timestamp: float, 
                         confidence: float = 1.0):
        """
        Añade una nueva posición de cabeza al tracking
        
        Args:
            position: Coordenadas (x, y) de la cabeza
            timestamp: Timestamp del frame
            confidence: Confianza de la detección
        """
        track_data = {
            'position': position,
            'timestamp': timestamp,
            'frame': self.current_frame,
            'confidence': confidence,
            'velocity': None,
            'acceleration': None
        }
        
        # Calcular velocidad si hay historial
        if len(self.head_track) > 0:
            prev_data = self.head_track[-1]
            dt = timestamp - prev_data['timestamp']
            if dt > 0:
                distance = euclidean(position, prev_data['position'])
                velocity = distance / dt
                track_data['velocity'] = velocity
                
                # Calcular aceleración
                if prev_data['velocity'] is not None:
                    acceleration = (velocity - prev_data['velocity']) / dt
                    track_data['acceleration'] = acceleration
                    
                    if abs(acceleration) > 800:  # Threshold para movimientos de cabeza
                        self.movement_stats['acceleration_events']['head'] += 1
        
        self.head_track.append(track_data)
        self._update_movement_stats('head', track_data)
    
    def _update_movement_stats(self, body_part: str, track_data: Dict):
        """
        Actualiza las estadísticas de movimiento
        
        Args:
            body_part: Parte del cuerpo ('left', 'right', 'head')
            track_data: Datos del tracking actual
        """
        part_key = f'{body_part}_hand' if body_part in ['left', 'right'] else body_part
        
        if track_data['velocity'] is not None:
            # Actualizar distancia total
            if len(self.hand_tracks.get(body_part, [])) > 1 or len(self.head_track) > 1:
                if body_part in ['left', 'right']:
                    prev_pos = self.hand_tracks[body_part][-2]['position']
                else:
                    prev_pos = self.head_track[-2]['position']
                
                distance = euclidean(track_data['position'], prev_pos)
                self.movement_stats['total_distance'][part_key] += distance
            
            # Actualizar velocidad máxima
            if track_data['velocity'] > self.movement_stats['max_velocity'][part_key]:
                self.movement_stats['max_velocity'][part_key] = track_data['velocity']
            
            # Detectar períodos estacionarios (velocidad muy baja)
            if track_data['velocity'] < 10:  # pixels/second threshold
                self._check_stationary_period(body_part, track_data)
            
            # Detectar movimientos rápidos
            if track_data['velocity'] > 500:  # pixels/second threshold
                self.movement_stats['rapid_movements'].append({
                    'body_part': part_key,
                    'timestamp': track_data['timestamp'],
                    'velocity': track_data['velocity'],
                    'position': track_data['position']
                })
    
    def _check_stationary_period(self, body_part: str, track_data: Dict):
        """
        Verifica si el jugador está en un período estacionario
        """
        # Revisar los últimos N frames para determinar si está estático
        window_size = min(30, self.smoothing_window * 6)  # ~1 segundo a 30fps
        
        if body_part in ['left', 'right']:
            recent_tracks = list(self.hand_tracks[body_part])[-window_size:]
        else:
            recent_tracks = list(self.head_track)[-window_size:]
        
        if len(recent_tracks) >= window_size:
            velocities = [t.get('velocity', 0) for t in recent_tracks if t.get('velocity') is not None]
            if velocities and np.mean(velocities) < 5:  # Muy lento
                # Período estacionario detectado
                self.movement_stats['stationary_periods'].append({
                    'body_part': f'{body_part}_hand' if body_part in ['left', 'right'] else body_part,
                    'start_timestamp': recent_tracks[0]['timestamp'],
                    'end_timestamp': track_data['timestamp'],
                    'duration': track_data['timestamp'] - recent_tracks[0]['timestamp'],
                    'position': track_data['position']
                })
    
    def get_smoothed_trajectory(self, body_part: str, window_size: Optional[int] = None) -> List[Tuple[int, int]]:
        """
        Obtiene la trayectoria suavizada de una parte del cuerpo
        
        Args:
            body_part: 'left', 'right', o 'head'
            window_size: Tamaño de ventana para suavizado
            
        Returns:
            Lista de posiciones suavizadas
        """
        if window_size is None:
            window_size = self.smoothing_window
        
        if body_part in ['left', 'right']:
            tracks = list(self.hand_tracks[body_part])
        else:
            tracks = list(self.head_track)
        
        if len(tracks) < 2:
            return []
        
        positions = [track['position'] for track in tracks]
        
        # Suavizado con ventana móvil
        smoothed = []
        for i in range(len(positions)):
            start_idx = max(0, i - window_size // 2)
            end_idx = min(len(positions), i + window_size // 2 + 1)
            
            window_positions = positions[start_idx:end_idx]
            avg_x = np.mean([pos[0] for pos in window_positions])
            avg_y = np.mean([pos[1] for pos in window_positions])
            
            smoothed.append((int(avg_x), int(avg_y)))
        
        return smoothed
    
    def detect_gestures(self, body_part: str) -> List[Dict]:
        """
        Detecta gestos basándose en patrones de movimiento
        
        Args:
            body_part: Parte del cuerpo a analizar
            
        Returns:
            Lista de gestos detectados
        """
        gestures = []
        
        if body_part in ['left', 'right']:
            tracks = list(self.hand_tracks[body_part])
        else:
            tracks = list(self.head_track)
        
        if len(tracks) < 10:
            return gestures
        
        # Detectar patrones de velocidad
        velocities = [t.get('velocity', 0) for t in tracks[-30:] if t.get('velocity') is not None]
        
        if len(velocities) > 5:
            # Gesto de selección (movimiento rápido seguido de parada)
            if self._detect_tap_gesture(velocities):
                gestures.append({
                    'type': 'tap',
                    'timestamp': tracks[-1]['timestamp'],
                    'position': tracks[-1]['position'],
                    'confidence': 0.8
                })
            
            # Gesto de arrastre (movimiento sostenido)
            if self._detect_drag_gesture(velocities):
                gestures.append({
                    'type': 'drag',
                    'timestamp': tracks[-1]['timestamp'],
                    'start_position': tracks[-len(velocities)]['position'],
                    'end_position': tracks[-1]['position'],
                    'confidence': 0.7
                })
        
        return gestures
    
    def _detect_tap_gesture(self, velocities: List[float]) -> bool:
        """Detecta gesto de toque/selección"""
        if len(velocities) < 5:
            return False
        
        # Patrón: velocidad baja -> alta -> baja
        recent = velocities[-5:]
        return (recent[0] < 50 and max(recent[1:3]) > 200 and recent[-1] < 50)
    
    def _detect_drag_gesture(self, velocities: List[float]) -> bool:
        """Detecta gesto de arrastre"""
        if len(velocities) < 10:
            return False
        
        # Movimiento sostenido por al menos 10 frames
        sustained_movement = sum(1 for v in velocities[-10:] if v > 100)
        return sustained_movement >= 7
    
    def calculate_tremor_analysis(self, body_part: str) -> Dict:
        """
        Analiza el temblor/estabilidad del movimiento
        
        Args:
            body_part: Parte del cuerpo a analizar
            
        Returns:
            Análisis de estabilidad
        """
        if body_part in ['left', 'right']:
            tracks = list(self.hand_tracks[body_part])
        else:
            tracks = list(self.head_track)
        
        if len(tracks) < 10:
            return {'tremor_score': 0, 'stability': 'insufficient_data'}
        
        # Analizar últimos 60 frames (2 segundos a 30fps)
        recent_tracks = tracks[-60:]
        positions = [track['position'] for track in recent_tracks]
        
        # Calcular desviación estándar de las posiciones
        x_coords = [pos[0] for pos in positions]
        y_coords = [pos[1] for pos in positions]
        
        x_std = np.std(x_coords)
        y_std = np.std(y_coords)
        
        # Puntuación de temblor (0-100, donde 0 es muy estable)
        tremor_score = min(100, (x_std + y_std) / 2)
        
        # Clasificación de estabilidad
        if tremor_score < 10:
            stability = 'very_stable'
        elif tremor_score < 25:
            stability = 'stable'
        elif tremor_score < 50:
            stability = 'moderate'
        else:
            stability = 'unstable'
        
        return {
            'tremor_score': tremor_score,
            'stability': stability,
            'x_deviation': x_std,
            'y_deviation': y_std
        }
    
    def get_movement_heatmap_data(self) -> Dict:
        """
        Obtiene datos para generar heatmap de movimiento
        
        Returns:
            Datos de posiciones para heatmap
        """
        heatmap_data = {
            'left_hand': [],
            'right_hand': [],
            'head': []
        }
        
        # Recopilar posiciones de manos
        for hand_type in ['left', 'right']:
            for track in self.hand_tracks[hand_type]:
                heatmap_data[f'{hand_type}_hand'].append(track['position'])
        
        # Recopilar posiciones de cabeza
        for track in self.head_track:
            heatmap_data['head'].append(track['position'])
        
        return heatmap_data
    
    def get_movement_summary(self) -> Dict:
        """
        Obtiene resumen completo del movimiento
        
        Returns:
            Resumen de estadísticas de movimiento
        """
        # Calcular velocidades promedio
        for body_part in ['left_hand', 'right_hand', 'head']:
            if body_part == 'head':
                tracks = list(self.head_track)
            else:
                hand_type = body_part.split('_')[0]
                tracks = list(self.hand_tracks[hand_type])
            
            velocities = [t.get('velocity', 0) for t in tracks if t.get('velocity') is not None]
            if velocities:
                self.movement_stats['avg_velocity'][body_part] = np.mean(velocities)
        
        # Añadir análisis de estabilidad
        stability_analysis = {
            'left_hand': self.calculate_tremor_analysis('left'),
            'right_hand': self.calculate_tremor_analysis('right'),
            'head': self.calculate_tremor_analysis('head')
        }
        
        summary = {
            'movement_stats': self.movement_stats.copy(),
            'stability_analysis': stability_analysis,
            'total_frames': self.current_frame,
            'tracking_duration': self.current_frame / self.fps if self.fps > 0 else 0
        }
        
        return summary
    
    def update_frame_counter(self):
        """Incrementa el contador de frames"""
        self.current_frame += 1
    
    def reset_tracking(self):
        """Reinicia todos los datos de tracking"""
        for hand_type in self.hand_tracks:
            self.hand_tracks[hand_type].clear()
        
        self.head_track.clear()
        self.gaze_track.clear()
        self.current_frame = 0
        
        # Reiniciar estadísticas
        self.movement_stats = {
            'total_distance': {'left_hand': 0, 'right_hand': 0, 'head': 0},
            'avg_velocity': {'left_hand': 0, 'right_hand': 0, 'head': 0},
            'max_velocity': {'left_hand': 0, 'right_hand': 0, 'head': 0},
            'acceleration_events': {'left_hand': 0, 'right_hand': 0, 'head': 0},
            'stationary_periods': [],
            'rapid_movements': []
        }


if __name__ == "__main__":
    # Ejemplo de uso
    tracker = MovementTracker()
    
    # Simular datos de tracking
    import time
    
    for i in range(100):
        timestamp = time.time()
        
        # Simular movimiento de mano
        x = 100 + 50 * np.sin(i * 0.1)
        y = 100 + 30 * np.cos(i * 0.1)
        tracker.add_hand_position('right', (int(x), int(y)), timestamp)
        
        # Simular movimiento de cabeza
        head_x = 200 + 20 * np.sin(i * 0.05)
        head_y = 150 + 15 * np.cos(i * 0.05)
        tracker.add_head_position((int(head_x), int(head_y)), timestamp)
        
        tracker.update_frame_counter()
        time.sleep(0.033)  # ~30 FPS
    
    # Obtener resumen
    summary = tracker.get_movement_summary()
    print("Resumen de movimiento:")
    print(f"Distancia total mano derecha: {summary['movement_stats']['total_distance']['right_hand']:.2f} pixels")
    print(f"Velocidad promedio cabeza: {summary['movement_stats']['avg_velocity']['head']:.2f} pixels/s")
    print(f"Estabilidad mano derecha: {summary['stability_analysis']['right_hand']['stability']}")