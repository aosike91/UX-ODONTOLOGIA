"""
Ejemplo de uso del VR UX Analyzer
Demuestra cómo usar el sistema para analizar videos de juegos VR
"""

import os
import cv2
import numpy as np
from vr_ux_analyzer import VRUXAnalyzer

def create_demo_video(output_path: str, duration_seconds: int = 30, fps: int = 30):
    """
    Crea un video de demostración simulando un entorno VR
    
    Args:
        output_path: Ruta donde guardar el video
        duration_seconds: Duración en segundos
        fps: Frames por segundo
    """
    
    # Configuración del video
    width, height = 1280, 720
    total_frames = duration_seconds * fps
    
    # Crear writer de video
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    # Colores
    bg_color = (20, 20, 40)  # Azul oscuro
    object_color = (0, 255, 0)  # Verde
    hand_color = (255, 255, 0)  # Amarillo
    
    print(f"Creando video de demostración: {output_path}")
    
    for frame_num in range(total_frames):
        # Crear frame base
        frame = np.full((height, width, 3), bg_color, dtype=np.uint8)
        
        # Simular objetos interactuables
        t = frame_num / fps  # Tiempo actual
        
        # Objeto 1: Botón que se mueve
        obj1_x = int(200 + 100 * np.sin(t * 0.5))
        obj1_y = int(200 + 50 * np.cos(t * 0.3))
        cv2.rectangle(frame, (obj1_x-30, obj1_y-20), (obj1_x+30, obj1_y+20), object_color, -1)
        cv2.putText(frame, "BOTON", (obj1_x-25, obj1_y+5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        
        # Objeto 2: Esfera estática
        obj2_x, obj2_y = 600, 300
        cv2.circle(frame, (obj2_x, obj2_y), 40, object_color, -1)
        cv2.putText(frame, "ESFERA", (obj2_x-30, obj2_y+5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1)
        
        # Objeto 3: Cubo que aparece y desaparece
        if int(t) % 4 < 2:  # Visible 2 segundos de cada 4
            obj3_x, obj3_y = 900, 150
            cv2.rectangle(frame, (obj3_x-25, obj3_y-25), (obj3_x+25, obj3_y+25), object_color, -1)
            cv2.putText(frame, "CUBO", (obj3_x-20, obj3_y+5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1)
        
        # Simular mano derecha siguiendo un patrón
        hand_x = int(400 + 200 * np.sin(t * 1.2) + 100 * np.cos(t * 2.1))
        hand_y = int(300 + 150 * np.cos(t * 0.8) + 80 * np.sin(t * 1.7))
        
        # Asegurar que la mano está en pantalla
        hand_x = max(50, min(width-50, hand_x))
        hand_y = max(50, min(height-50, hand_y))
        
        # Dibujar mano (círculo con líneas simulando dedos)
        cv2.circle(frame, (hand_x, hand_y), 15, hand_color, -1)\n        cv2.circle(frame, (hand_x, hand_y), 15, (0, 0, 0), 2)\n        \n        # Dedo índice (punto de interacción)\n        finger_x = hand_x + int(20 * np.cos(t * 3))\n        finger_y = hand_y + int(20 * np.sin(t * 3))\n        cv2.circle(frame, (finger_x, finger_y), 5, (255, 0, 0), -1)\n        cv2.line(frame, (hand_x, hand_y), (finger_x, finger_y), hand_color, 3)\n        \n        # Simular mano izquierda (más estática)\n        left_hand_x = int(150 + 50 * np.sin(t * 0.3))\n        left_hand_y = int(400 + 30 * np.cos(t * 0.4))\n        cv2.circle(frame, (left_hand_x, left_hand_y), 12, hand_color, -1)\n        cv2.circle(frame, (left_hand_x, left_hand_y), 12, (0, 0, 0), 2)\n        \n        # Simular cabeza/mirada (centro superior)\n        head_x = int(640 + 100 * np.sin(t * 0.2))\n        head_y = int(100 + 20 * np.cos(t * 0.15))\n        cv2.circle(frame, (head_x, head_y), 8, (255, 0, 255), -1)\n        cv2.putText(frame, \"HEAD\", (head_x-15, head_y-15), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)\n        \n        # Añadir información del frame\n        cv2.putText(frame, f\"Frame: {frame_num+1}/{total_frames}\", (10, 30), \n                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)\n        cv2.putText(frame, f\"Tiempo: {t:.1f}s\", (10, 60), \n                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)\n        \n        # Simular interacciones (cuando la mano está cerca de objetos)\n        # Distancia a objeto 1\n        dist1 = np.sqrt((hand_x - obj1_x)**2 + (hand_y - obj1_y)**2)\n        if dist1 < 50:\n            cv2.circle(frame, (hand_x, hand_y), 25, (0, 255, 255), 3)  # Highlight de interacción\n            cv2.putText(frame, \"INTERACCION!\", (hand_x-40, hand_y-40), \n                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 2)\n        \n        # Distancia a objeto 2\n        dist2 = np.sqrt((hand_x - obj2_x)**2 + (hand_y - obj2_y)**2)\n        if dist2 < 60:\n            cv2.circle(frame, (hand_x, hand_y), 30, (255, 255, 0), 2)\n            cv2.putText(frame, \"CERCA\", (hand_x-20, hand_y-50), \n                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 1)\n        \n        # Añadir ruido visual ocasional (simula oclusión o problemas de tracking)\n        if frame_num % 180 == 0:  # Cada 6 segundos\n            cv2.rectangle(frame, (0, 0), (width//4, height//4), (50, 50, 50), -1)\n            cv2.putText(frame, \"TRACKING LOST\", (10, 100), \n                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)\n        \n        # Escribir frame\n        writer.write(frame)\n    \n    writer.release()\n    print(f\"Video de demostración creado: {output_path}\")\n\n\ndef demo_basic_analysis():\n    \"\"\"\n    Demostración básica del análisis UX\n    \"\"\"\n    print(\"\\n\" + \"=\"*60)\n    print(\"DEMO: Análisis Básico de UX en VR\")\n    print(\"=\"*60)\n    \n    # Crear video de demostración si no existe\n    demo_video_path = \"demo_vr_session.mp4\"\n    \n    if not os.path.exists(demo_video_path):\n        print(\"Creando video de demostración...\")\n        create_demo_video(demo_video_path, duration_seconds=45)\n    \n    # Configuración personalizada\n    config = {\n        'detection_confidence': 0.3,  # Más permisivo para demo\n        'skip_frames': 2,  # Procesar cada 2 frames para velocidad\n        'save_annotated_video': True,\n        'save_heatmaps': True,\n        'output_dir': 'demo_results',\n        'log_level': 'INFO'\n    }\n    \n    # Crear analizador\n    analyzer = VRUXAnalyzer(config)\n    \n    # Ejecutar análisis\n    print(\"\\nIniciando análisis...\")\n    results = analyzer.analyze_video(demo_video_path, \"Demo Session\")\n    \n    # Mostrar resultados\n    print(\"\\n\" + \"=\"*40)\n    print(\"RESULTADOS DEL ANÁLISIS\")\n    print(\"=\"*40)\n    \n    # Información básica\n    video_info = results['video_info']\n    print(f\"Video: {video_info['filename']}\")\n    print(f\"Duración: {video_info['duration']:.1f} segundos\")\n    print(f\"Resolución: {video_info['width']}x{video_info['height']}\")\n    print(f\"FPS: {video_info['fps']:.1f}\")\n    \n    # Estadísticas de procesamiento\n    analysis = results['analysis_results']\n    stats = analysis.get('processing_stats', {})\n    \n    print(f\"\\nFrames procesados: {stats.get('total_frames_processed', 0)}\")\n    print(f\"Objetos promedio por frame: {stats.get('average_objects_per_frame', 0):.1f}\")\n    print(f\"Manos promedio por frame: {stats.get('average_hands_per_frame', 0):.1f}\")\n    print(f\"Total de interacciones: {stats.get('total_interactions', 0)}\")\n    \n    # Análisis de interacciones\n    if 'interaction_analysis' in analysis:\n        ia = analysis['interaction_analysis']['summary']\n        print(f\"\\nTasa de éxito en interacciones: {ia['success_rate']:.1%}\")\n        print(f\"Eventos totales: {ia['total_events']}\")\n        print(f\"Eventos de confusión: {ia['stats']['confusion_events']}\")\n        print(f\"Jugador perdido: {ia['stats']['player_lost_events']} veces\")\n    \n    # Métricas UX\n    if 'ux_metrics' in analysis:\n        print(\"\\n\" + \"-\"*30)\n        print(\"MÉTRICAS UX\")\n        print(\"-\"*30)\n        \n        ux_metrics = analysis['ux_metrics']\n        \n        # Mostrar métricas por categoría\n        for category, metrics in ux_metrics.items():\n            if isinstance(metrics, dict) and category != 'composite_score':\n                print(f\"\\n{category.upper()}:\")\n                for name, metric in metrics.items():\n                    if hasattr(metric, 'value'):\n                        print(f\"  - {name}: {metric.value:.1%} ({metric.interpretation})\")\n        \n        # Puntuación compuesta\n        if 'composite_score' in ux_metrics:\n            composite = ux_metrics['composite_score']\n            print(f\"\\nPUNTUACIÓN UX GENERAL: {composite.value:.1%}\")\n            print(f\"Interpretación: {composite.interpretation}\")\n    \n    print(f\"\\nResultados completos guardados en: {config['output_dir']}\")\n    print(\"\\nArchivos generados:\")\n    \n    # Listar archivos generados\n    output_dir = config['output_dir']\n    if os.path.exists(output_dir):\n        for root, dirs, files in os.walk(output_dir):\n            for file in files:\n                rel_path = os.path.relpath(os.path.join(root, file), output_dir)\n                print(f\"  - {rel_path}\")\n\n\ndef demo_realtime_analysis():\n    \"\"\"\n    Demostración de análisis en tiempo real\n    \"\"\"\n    print(\"\\n\" + \"=\"*60)\n    print(\"DEMO: Análisis en Tiempo Real\")\n    print(\"=\"*60)\n    \n    print(\"Esta demostración usa la webcam para análisis en tiempo real.\")\n    print(\"Presiona 'q' para salir.\")\n    \n    response = input(\"\\n¿Continuar con análisis en tiempo real? (y/N): \")\n    \n    if response.lower() != 'y':\n        print(\"Demo cancelada.\")\n        return\n    \n    # Configuración para tiempo real\n    config = {\n        'detection_confidence': 0.4,\n        'skip_frames': 2,  # Saltar frames para mejor rendimiento\n        'save_annotated_video': False,\n        'output_dir': 'realtime_results',\n        'log_level': 'INFO'\n    }\n    \n    # Crear analizador\n    analyzer = VRUXAnalyzer(config)\n    \n    try:\n        # Ejecutar análisis en tiempo real\n        analyzer.analyze_realtime_stream(stream_source=0)\n    except Exception as e:\n        print(f\"Error en análisis en tiempo real: {e}\")\n        print(\"Asegúrate de que tu webcam esté conectada y funcionando.\")\n\n\ndef demo_custom_configuration():\n    \"\"\"\n    Demostración de configuración personalizada\n    \"\"\"\n    print(\"\\n\" + \"=\"*60)\n    print(\"DEMO: Configuración Personalizada\")\n    print(\"=\"*60)\n    \n    # Crear archivo de configuración personalizada\n    custom_config = {\n        \"detection_confidence\": 0.6,\n        \"interaction_distance\": 75,\n        \"tracking_history\": 500,\n        \"skip_frames\": 1,\n        \"save_annotated_video\": True,\n        \"save_heatmaps\": True,\n        \"generate_reports\": True,\n        \"output_dir\": \"custom_analysis_results\",\n        \"log_level\": \"DEBUG\"\n    }\n    \n    # Guardar configuración\n    import json\n    config_file = \"custom_config.json\"\n    with open(config_file, 'w') as f:\n        json.dump(custom_config, f, indent=2)\n    \n    print(f\"Configuración personalizada creada: {config_file}\")\n    print(\"Contenido:\")\n    print(json.dumps(custom_config, indent=2))\n    \n    # Usar configuración personalizada\n    analyzer = VRUXAnalyzer(custom_config)\n    \n    # Crear video pequeño para demo rápida\n    quick_demo_video = \"quick_demo.mp4\"\n    if not os.path.exists(quick_demo_video):\n        create_demo_video(quick_demo_video, duration_seconds=15, fps=20)\n    \n    print(f\"\\nAnalizando {quick_demo_video} con configuración personalizada...\")\n    \n    results = analyzer.analyze_video(quick_demo_video, \"Custom Config Demo\")\n    \n    print(\"\\nAnálisis completado con configuración personalizada.\")\n    print(f\"Resultados en: {custom_config['output_dir']}\")\n\n\ndef main():\n    \"\"\"\n    Función principal de demostración\n    \"\"\"\n    print(\"VR UX ANALYZER - DEMOSTRACIONES\")\n    print(\"=\"*50)\n    \n    demos = {\n        '1': ('Análisis Básico de Video', demo_basic_analysis),\n        '2': ('Análisis en Tiempo Real', demo_realtime_analysis),\n        '3': ('Configuración Personalizada', demo_custom_configuration)\n    }\n    \n    while True:\n        print(\"\\nDemos disponibles:\")\n        for key, (name, _) in demos.items():\n            print(f\"{key}. {name}\")\n        print(\"q. Salir\")\n        \n        choice = input(\"\\nSelecciona una demo (1-3) o 'q' para salir: \").strip()\n        \n        if choice.lower() == 'q':\n            break\n        elif choice in demos:\n            try:\n                demos[choice][1]()\n                input(\"\\nPresiona Enter para continuar...\")\n            except KeyboardInterrupt:\n                print(\"\\nDemo interrumpida.\")\n            except Exception as e:\n                print(f\"\\nError en la demo: {e}\")\n        else:\n            print(\"Opción no válida. Intenta de nuevo.\")\n    \n    print(\"\\n¡Gracias por probar VR UX Analyzer!\")\n\n\nif __name__ == \"__main__\":\n    main()"