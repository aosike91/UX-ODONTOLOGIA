"""
VR Game UX Analyzer - Analizador de Comportamiento y Patrones
Analiza patrones de comportamiento del jugador para métricas UX avanzadas
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional
from scipy import stats, signal
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
import logging
from dataclasses import dataclass
from collections import defaultdict, deque
from enum import Enum

class BehaviorPattern(Enum):
    """Patrones de comportamiento identificables"""
    EFFICIENT_NAVIGATION = "efficient_navigation"
    EXPLORATION_PHASE = "exploration_phase"
    TASK_FOCUSED = "task_focused"
    CONFUSION_STATE = "confusion_state"
    LEARNING_CURVE = "learning_curve"
    FATIGUE_DETECTED = "fatigue_detected"
    EXPERTISE_DEMONSTRATED = "expertise_demonstrated"
    HESITATION_PATTERN = "hesitation_pattern"

@dataclass
class BehaviorSegment:
    """Segmento de comportamiento identificado"""
    pattern: BehaviorPattern
    start_time: float
    end_time: float
    confidence: float
    metrics: Dict
    description: str

class BehaviorAnalyzer:
    """
    Analiza patrones de comportamiento del jugador para generar métricas UX
    """
    
    def __init__(self, analysis_window: int = 300):
        """
        Inicializa el analizador de comportamiento
        
        Args:
            analysis_window: Ventana de análisis en frames (10 segundos a 30fps)
        """
        self.analysis_window = analysis_window
        
        # Datos de entrada acumulados
        self.movement_data = []
        self.interaction_data = []
        self.gaze_data = []
        self.performance_timeline = []
        
        # Resultados de análisis
        self.behavior_segments = []
        self.efficiency_metrics = {}
        self.learning_indicators = {}
        self.cognitive_load_analysis = {}
        
        # Configuración de análisis
        self.setup_analysis_parameters()
        self.setup_logging()
    
    def setup_logging(self):
        """Configura el sistema de logging"""
        self.logger = logging.getLogger(__name__)
    
    def setup_analysis_parameters(self):
        """Configura parámetros para análisis de comportamiento"""
        self.parameters = {
            'efficiency_thresholds': {
                'movement_directness': 0.7,  # Qué tan directo es el movimiento
                'task_completion_speed': 0.8,  # Velocidad de completar tareas
                'interaction_accuracy': 0.9   # Precisión en interacciones
            },
            'confusion_indicators': {
                'excessive_backtracking': 3,  # Veces que regresa al mismo lugar
                'rapid_direction_changes': 10,  # Cambios de dirección por segundo
                'interaction_failures': 5,   # Fallos consecutivos
                'idle_time_threshold': 3.0   # Segundos sin actividad
            },
            'learning_curve_params': {
                'task_repetition_threshold': 3,  # Repeticiones para detectar aprendizaje
                'improvement_threshold': 0.2,    # Mejora mínima para considerar aprendizaje
                'time_decay_factor': 0.9         # Factor de decaimiento temporal
            }
        }
    
    def add_movement_data(self, timestamp: float, position: Tuple[int, int], 
                         velocity: float, body_part: str):
        """
        Añade datos de movimiento para análisis
        
        Args:
            timestamp: Timestamp del movimiento
            position: Posición (x, y)
            velocity: Velocidad del movimiento
            body_part: Parte del cuerpo ('left_hand', 'right_hand', 'head')
        """
        self.movement_data.append({
            'timestamp': timestamp,
            'position': position,
            'velocity': velocity,
            'body_part': body_part
        })
    
    def add_interaction_data(self, timestamp: float, interaction_type: str, 
                           success: bool, target_object: str, response_time: float = 0):
        """
        Añade datos de interacción para análisis
        
        Args:
            timestamp: Timestamp de la interacción
            interaction_type: Tipo de interacción
            success: Si fue exitosa
            target_object: Objeto objetivo
            response_time: Tiempo de respuesta
        """
        self.interaction_data.append({
            'timestamp': timestamp,
            'type': interaction_type,
            'success': success,
            'target': target_object,
            'response_time': response_time
        })
    
    def add_gaze_data(self, timestamp: float, gaze_position: Tuple[int, int], 
                     fixation_duration: float = 0):
        """
        Añade datos de mirada para análisis
        
        Args:
            timestamp: Timestamp del evento de mirada
            gaze_position: Posición de la mirada
            fixation_duration: Duración de la fijación
        """
        self.gaze_data.append({
            'timestamp': timestamp,
            'position': gaze_position,
            'fixation_duration': fixation_duration
        })
    
    def analyze_movement_efficiency(self) -> Dict:
        """
        Analiza la eficiencia del movimiento del jugador
        
        Returns:
            Métricas de eficiencia de movimiento
        """
        if len(self.movement_data) < 10:
            return {'error': 'Datos insuficientes para análisis'}
        
        # Convertir a DataFrame para análisis
        df = pd.DataFrame(self.movement_data)
        
        # Análisis por parte del cuerpo
        efficiency_by_part = {}
        
        for body_part in df['body_part'].unique():
            part_data = df[df['body_part'] == body_part]
            
            if len(part_data) < 5:
                continue
            
            # Calcular métricas de eficiencia
            positions = np.array(part_data['position'].tolist())
            velocities = part_data['velocity'].values
            
            # 1. Directness Ratio (qué tan directo es el camino)
            if len(positions) > 1:
                total_distance = np.sum([
                    np.linalg.norm(positions[i] - positions[i-1]) 
                    for i in range(1, len(positions))
                ])
                
                straight_distance = np.linalg.norm(positions[-1] - positions[0])
                directness = straight_distance / max(total_distance, 1)
            else:
                directness = 1.0
            
            # 2. Smoothness (suavidad del movimiento)
            velocity_changes = np.diff(velocities)
            smoothness = 1.0 / (1.0 + np.std(velocity_changes))
            
            # 3. Economy of movement (economía de movimiento)
            avg_velocity = np.mean(velocities)
            max_velocity = np.max(velocities)
            economy = avg_velocity / max(max_velocity, 1)
            
            # 4. Hesitation detection (detección de vacilación)
            low_velocity_periods = np.sum(velocities < np.percentile(velocities, 25))
            hesitation_ratio = low_velocity_periods / len(velocities)
            
            efficiency_by_part[body_part] = {
                'directness': directness,
                'smoothness': smoothness,
                'economy': economy,
                'hesitation_ratio': hesitation_ratio,
                'avg_velocity': avg_velocity,
                'total_distance': total_distance if 'total_distance' in locals() else 0
            }
        
        return efficiency_by_part
    
    def analyze_task_performance_patterns(self) -> Dict:
        """
        Analiza patrones en el rendimiento de tareas
        
        Returns:
            Análisis de patrones de rendimiento
        """
        if len(self.interaction_data) < 5:
            return {'error': 'Datos insuficientes para análisis'}
        
        df = pd.DataFrame(self.interaction_data)
        
        # Análisis temporal de rendimiento
        df = df.sort_values('timestamp')
        df['success_numeric'] = df['success'].astype(int)
        
        # 1. Tasa de éxito a lo largo del tiempo
        window_size = min(10, len(df) // 3)
        df['success_rate_rolling'] = df['success_numeric'].rolling(
            window=window_size, min_periods=1
        ).mean()
        
        # 2. Tiempo de respuesta por tipo de tarea
        response_times_by_type = df.groupby('type')['response_time'].agg([
            'mean', 'std', 'min', 'max', 'count'
        ]).to_dict()
        
        # 3. Curva de aprendizaje
        learning_curve = self._calculate_learning_curve(df)
        
        # 4. Identificar fases de rendimiento
        performance_phases = self._identify_performance_phases(df)
        
        # 5. Análisis de errores
        error_analysis = self._analyze_error_patterns(df)
        
        return {
            'success_rate_trend': df['success_rate_rolling'].tolist(),
            'response_times_by_type': response_times_by_type,
            'learning_curve': learning_curve,
            'performance_phases': performance_phases,
            'error_analysis': error_analysis,
            'overall_success_rate': df['success_numeric'].mean(),
            'improvement_trend': self._calculate_improvement_trend(df)
        }
    
    def _calculate_learning_curve(self, df: pd.DataFrame) -> Dict:
        """Calcula la curva de aprendizaje del jugador"""
        # Agrupar por tipo de tarea y calcular mejora
        learning_metrics = {}
        
        for task_type in df['type'].unique():
            task_data = df[df['type'] == task_type]
            
            if len(task_data) < 3:
                continue
            
            # Calcular mejora en tiempo de respuesta
            if 'response_time' in task_data.columns and task_data['response_time'].notna().sum() > 2:
                response_times = task_data['response_time'].dropna()
                
                # Regresión linear para detectar tendencia
                x = np.arange(len(response_times))
                slope, intercept, r_value, p_value, std_err = stats.linregress(x, response_times)
                
                learning_metrics[task_type] = {
                    'improvement_rate': -slope,  # Negativo porque queremos tiempos más bajos
                    'correlation': r_value,
                    'significance': p_value,
                    'initial_performance': response_times.iloc[0],
                    'final_performance': response_times.iloc[-1],
                    'total_improvement': response_times.iloc[0] - response_times.iloc[-1]
                }
        
        return learning_metrics
    
    def _identify_performance_phases(self, df: pd.DataFrame) -> List[Dict]:
        """Identifica fases distintas de rendimiento"""
        phases = []
        
        # Usar clustering para identificar fases basadas en rendimiento
        if len(df) < 10:
            return phases
        
        # Preparar datos para clustering
        features = []
        for i in range(len(df)):
            # Ventana móvil de rendimiento
            start_idx = max(0, i - 5)
            end_idx = min(len(df), i + 6)
            window_data = df.iloc[start_idx:end_idx]
            
            success_rate = window_data['success_numeric'].mean()
            avg_response_time = window_data['response_time'].mean() if 'response_time' in window_data else 0
            
            features.append([success_rate, avg_response_time, i])
        
        # Normalizar features
        features_array = np.array(features)
        if features_array.shape[1] > 0:
            scaler = StandardScaler()
            normalized_features = scaler.fit_transform(features_array)
            
            # Clustering DBSCAN
            clustering = DBSCAN(eps=0.5, min_samples=3).fit(normalized_features)
            
            # Identificar fases
            labels = clustering.labels_
            unique_labels = set(labels)
            
            for label in unique_labels:
                if label == -1:  # Ruido
                    continue
                
                phase_indices = np.where(labels == label)[0]
                phase_start = df.iloc[phase_indices[0]]['timestamp']
                phase_end = df.iloc[phase_indices[-1]]['timestamp']
                
                # Características de la fase
                phase_data = df.iloc[phase_indices]
                phase_success_rate = phase_data['success_numeric'].mean()
                phase_avg_response = phase_data['response_time'].mean() if 'response_time' in phase_data else 0
                
                # Clasificar fase
                if phase_success_rate > 0.8 and phase_avg_response < df['response_time'].median():
                    phase_type = "high_performance"
                elif phase_success_rate < 0.4:
                    phase_type = "struggling"
                elif phase_avg_response > df['response_time'].quantile(0.75):
                    phase_type = "careful_deliberation"
                else:
                    phase_type = "moderate_performance"
                
                phases.append({
                    'start_time': phase_start,
                    'end_time': phase_end,
                    'duration': phase_end - phase_start,
                    'type': phase_type,
                    'success_rate': phase_success_rate,
                    'avg_response_time': phase_avg_response,
                    'sample_count': len(phase_indices)
                })
        
        return phases
    
    def _analyze_error_patterns(self, df: pd.DataFrame) -> Dict:
        """Analiza patrones en los errores del jugador"""
        failed_interactions = df[df['success'] == False]
        
        if len(failed_interactions) == 0:
            return {'no_errors': True}
        
        # Análisis de errores por tipo
        errors_by_type = failed_interactions['type'].value_counts().to_dict()
        
        # Análisis temporal de errores
        df['error'] = ~df['success']
        df['error_rate_rolling'] = df['error'].rolling(window=10, min_periods=1).mean()
        
        # Clustering de errores para identificar patrones
        error_clusters = []
        if len(failed_interactions) > 3:
            # Características de errores: tiempo, tipo, contexto anterior
            error_features = []
            for idx, error in failed_interactions.iterrows():
                # Contexto: rendimiento en los 5 intentos anteriores
                prev_attempts = df[df['timestamp'] < error['timestamp']].tail(5)
                prev_success_rate = prev_attempts['success_numeric'].mean() if len(prev_attempts) > 0 else 0
                
                error_features.append([
                    error['timestamp'],
                    prev_success_rate,
                    error['response_time'] if pd.notna(error['response_time']) else 0
                ])
            
            if len(error_features) > 2:
                error_array = np.array(error_features)
                scaler = StandardScaler()
                normalized_errors = scaler.fit_transform(error_array)
                
                clustering = DBSCAN(eps=0.8, min_samples=2).fit(normalized_errors)
                
                for label in set(clustering.labels_):
                    if label != -1:
                        cluster_indices = np.where(clustering.labels_ == label)[0]
                        cluster_errors = failed_interactions.iloc[cluster_indices]
                        
                        error_clusters.append({
                            'cluster_id': label,
                            'error_count': len(cluster_indices),
                            'time_span': cluster_errors['timestamp'].max() - cluster_errors['timestamp'].min(),
                            'common_types': cluster_errors['type'].mode().tolist(),
                            'avg_response_time': cluster_errors['response_time'].mean()
                        })
        
        return {
            'total_errors': len(failed_interactions),
            'error_rate': len(failed_interactions) / len(df),
            'errors_by_type': errors_by_type,
            'error_clusters': error_clusters,
            'error_trend': df['error_rate_rolling'].tolist()
        }
    
    def _calculate_improvement_trend(self, df: pd.DataFrame) -> Dict:
        """Calcula tendencia de mejora general"""
        if len(df) < 10:
            return {'insufficient_data': True}
        
        # Dividir en segmentos para comparar
        first_half = df.iloc[:len(df)//2]
        second_half = df.iloc[len(df)//2:]
        
        first_performance = first_half['success_numeric'].mean()
        second_performance = second_half['success_numeric'].mean()
        
        improvement = second_performance - first_performance
        
        # Análisis de tendencia usando regresión
        x = np.arange(len(df))
        y = df['success_numeric'].values
        
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
        
        return {
            'overall_improvement': improvement,
            'improvement_rate': slope,
            'correlation_strength': abs(r_value),
            'statistical_significance': p_value < 0.05,
            'first_half_performance': first_performance,
            'second_half_performance': second_performance
        }
    
    def detect_cognitive_load_indicators(self) -> Dict:
        """
        Detecta indicadores de carga cognitiva del jugador
        
        Returns:
            Análisis de carga cognitiva
        """
        cognitive_indicators = {
            'movement_based': {},
            'interaction_based': {},
            'temporal_patterns': {},
            'overall_assessment': {}
        }
        
        # Análisis basado en movimiento
        if self.movement_data:
            movement_df = pd.DataFrame(self.movement_data)
            
            # Variabilidad en el movimiento (indicador de estrés/fatiga)
            velocities = movement_df['velocity'].values
            velocity_cv = np.std(velocities) / np.mean(velocities) if np.mean(velocities) > 0 else 0
            
            # Frecuencia de micro-movimientos (temblor, nerviosismo)
            micro_movements = np.sum(velocities < np.percentile(velocities, 10))
            
            cognitive_indicators['movement_based'] = {
                'velocity_variability': velocity_cv,
                'micro_movement_frequency': micro_movements / len(velocities),
                'movement_smoothness': self._calculate_movement_smoothness(velocities)
            }
        
        # Análisis basado en interacciones
        if self.interaction_data:
            interaction_df = pd.DataFrame(self.interaction_data)
            
            # Tiempo de respuesta y su variabilidad
            response_times = interaction_df['response_time'].dropna()
            if len(response_times) > 1:
                rt_mean = response_times.mean()
                rt_std = response_times.std()
                rt_cv = rt_std / rt_mean if rt_mean > 0 else 0
                
                cognitive_indicators['interaction_based'] = {
                    'response_time_variability': rt_cv,
                    'average_response_time': rt_mean,
                    'response_time_trend': self._calculate_response_time_trend(response_times)
                }
        
        # Patrones temporales
        cognitive_indicators['temporal_patterns'] = self._analyze_temporal_patterns()
        
        # Evaluación general de carga cognitiva
        cognitive_indicators['overall_assessment'] = self._assess_overall_cognitive_load(
            cognitive_indicators
        )
        
        return cognitive_indicators
    
    def _calculate_movement_smoothness(self, velocities: np.ndarray) -> float:
        """Calcula la suavidad del movimiento"""
        if len(velocities) < 3:
            return 1.0
        
        # Usar la derivada segunda (aceleración) como medida de suavidad
        acceleration = np.diff(velocities, n=2)
        smoothness = 1.0 / (1.0 + np.std(acceleration))
        
        return smoothness
    
    def _calculate_response_time_trend(self, response_times: pd.Series) -> Dict:
        """Calcula tendencia en tiempos de respuesta"""
        x = np.arange(len(response_times))
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, response_times)
        
        return {
            'trend_slope': slope,
            'correlation': r_value,
            'is_increasing': slope > 0,
            'significance': p_value < 0.05
        }
    
    def _analyze_temporal_patterns(self) -> Dict:
        """Analiza patrones temporales en el comportamiento"""
        # Combinar todos los eventos temporales
        all_events = []
        
        # Agregar eventos de movimiento
        for event in self.movement_data[-100:]:  # Últimos 100 eventos
            all_events.append({
                'timestamp': event['timestamp'],
                'type': 'movement',
                'intensity': event['velocity']
            })
        
        # Agregar eventos de interacción
        for event in self.interaction_data[-50:]:  # Últimos 50 eventos
            all_events.append({
                'timestamp': event['timestamp'],
                'type': 'interaction',
                'intensity': 1 if event['success'] else 0
            })
        
        if len(all_events) < 10:
            return {'insufficient_data': True}
        
        # Ordenar por timestamp
        all_events.sort(key=lambda x: x['timestamp'])
        
        # Analizar intervalos entre eventos
        intervals = [
            all_events[i]['timestamp'] - all_events[i-1]['timestamp']
            for i in range(1, len(all_events))
        ]
        
        # Detectar períodos de alta/baja actividad
        interval_array = np.array(intervals)
        high_activity_threshold = np.percentile(interval_array, 25)  # Intervalos cortos = alta actividad
        
        high_activity_periods = np.sum(interval_array < high_activity_threshold)
        activity_rhythm = np.std(interval_array) / np.mean(interval_array)
        
        return {
            'activity_rhythm_variability': activity_rhythm,
            'high_activity_ratio': high_activity_periods / len(intervals),
            'average_event_interval': np.mean(interval_array),
            'event_clustering': self._detect_event_clustering(all_events)
        }
    
    def _detect_event_clustering(self, events: List[Dict]) -> Dict:
        """Detecta clustering temporal de eventos"""
        if len(events) < 5:
            return {'insufficient_data': True}
        
        timestamps = [event['timestamp'] for event in events]
        
        # Usar DBSCAN en 1D para detectar clusters temporales
        timestamp_array = np.array(timestamps).reshape(-1, 1)
        
        # Normalizar timestamps
        scaler = StandardScaler()
        normalized_timestamps = scaler.fit_transform(timestamp_array)
        
        clustering = DBSCAN(eps=0.5, min_samples=3).fit(normalized_timestamps)
        
        n_clusters = len(set(clustering.labels_)) - (1 if -1 in clustering.labels_ else 0)
        
        return {
            'n_temporal_clusters': n_clusters,
            'clustering_efficiency': n_clusters / len(events) if len(events) > 0 else 0
        }
    
    def _assess_overall_cognitive_load(self, indicators: Dict) -> Dict:
        """Evaluación general de carga cognitiva"""
        load_factors = []
        
        # Factores de movimiento
        if 'movement_based' in indicators and indicators['movement_based']:
            mv = indicators['movement_based']
            if 'velocity_variability' in mv:
                load_factors.append(min(mv['velocity_variability'] * 2, 1.0))
            if 'micro_movement_frequency' in mv:
                load_factors.append(mv['micro_movement_frequency'])
        
        # Factores de interacción
        if 'interaction_based' in indicators and indicators['interaction_based']:
            ib = indicators['interaction_based']
            if 'response_time_variability' in ib:
                load_factors.append(min(ib['response_time_variability'], 1.0))
        
        # Factores temporales
        if 'temporal_patterns' in indicators and indicators['temporal_patterns']:
            tp = indicators['temporal_patterns']
            if 'activity_rhythm_variability' in tp:
                load_factors.append(min(tp['activity_rhythm_variability'], 1.0))
        
        if load_factors:
            overall_load = np.mean(load_factors)
            
            # Clasificar nivel de carga
            if overall_load < 0.3:
                load_level = 'low'
            elif overall_load < 0.6:
                load_level = 'moderate'
            else:
                load_level = 'high'
        else:
            overall_load = 0
            load_level = 'unknown'
        
        return {
            'cognitive_load_score': overall_load,
            'load_level': load_level,
            'contributing_factors': len(load_factors),
            'recommendations': self._generate_cognitive_load_recommendations(overall_load, load_level)
        }
    
    def _generate_cognitive_load_recommendations(self, load_score: float, load_level: str) -> List[str]:
        """Genera recomendaciones basadas en la carga cognitiva"""
        recommendations = []
        
        if load_level == 'high':
            recommendations.extend([
                "Considerar simplificar la interfaz o reducir elementos simultáneos",
                "Implementar pausas o momentos de descanso en el juego",
                "Revisar la curva de dificultad para evitar sobrecarga"
            ])
        elif load_level == 'low':
            recommendations.extend([
                "El juego podría beneficiarse de más desafíos o complejidad",
                "Considerar añadir elementos adicionales de interacción"
            ])
        else:
            recommendations.append("La carga cognitiva parece estar en un nivel apropiado")
        
        return recommendations
    
    def generate_comprehensive_analysis(self) -> Dict:
        """
        Genera análisis completo del comportamiento del jugador
        
        Returns:
            Análisis completo con todas las métricas UX
        """
        return {
            'movement_efficiency': self.analyze_movement_efficiency(),
            'task_performance': self.analyze_task_performance_patterns(),
            'cognitive_load': self.detect_cognitive_load_indicators(),
            'behavior_segments': [
                {
                    'pattern': segment.pattern.value,
                    'start_time': segment.start_time,
                    'end_time': segment.end_time,
                    'confidence': segment.confidence,
                    'metrics': segment.metrics,
                    'description': segment.description
                }
                for segment in self.behavior_segments
            ],
            'summary_recommendations': self._generate_summary_recommendations()
        }
    
    def _generate_summary_recommendations(self) -> List[str]:
        """Genera recomendaciones generales basadas en todo el análisis"""
        recommendations = []
        
        # Analizar eficiencia de movimiento
        movement_analysis = self.analyze_movement_efficiency()
        if movement_analysis and not movement_analysis.get('error'):
            avg_directness = np.mean([
                metrics.get('directness', 0) 
                for metrics in movement_analysis.values()
            ])
            
            if avg_directness < 0.5:
                recommendations.append("Mejorar señalización visual para navegación más directa")
        
        # Analizar rendimiento de tareas
        task_analysis = self.analyze_task_performance_patterns()
        if task_analysis and not task_analysis.get('error'):
            if task_analysis.get('overall_success_rate', 0) < 0.7:
                recommendations.append("Revisar dificultad de tareas o proporcionar más retroalimentación")
        
        # Análisis de carga cognitiva
        cognitive_analysis = self.detect_cognitive_load_indicators()
        if cognitive_analysis.get('overall_assessment', {}).get('load_level') == 'high':
            recommendations.append("Considerar reducir la complejidad visual o cognitiva")
        
        return recommendations


if __name__ == "__main__":
    # Ejemplo de uso
    analyzer = BehaviorAnalyzer()
    
    # Simular datos
    import time
    import random
    
    base_time = time.time()
    
    # Simular sesión de juego
    for i in range(100):
        timestamp = base_time + i * 0.1
        
        # Movimiento simulado
        analyzer.add_movement_data(
            timestamp, 
            (100 + i * 2, 100 + random.randint(-10, 10)), 
            random.uniform(10, 100), 
            'right_hand'
        )
        
        # Interacciones simuladas
        if i % 10 == 0:
            analyzer.add_interaction_data(
                timestamp,
                'select_object',
                random.choice([True, True, True, False]),  # 75% éxito
                f'object_{i//10}',
                random.uniform(0.5, 3.0)
            )
    
    # Generar análisis
    analysis = analyzer.generate_comprehensive_analysis()
    
    print("Análisis de comportamiento UX:")
    print(f"Carga cognitiva: {analysis['cognitive_load']['overall_assessment']['load_level']}")
    if 'overall_success_rate' in analysis['task_performance']:
        print(f"Tasa de éxito: {analysis['task_performance']['overall_success_rate']:.2%}")
    
    print("\nRecomendaciones:")
    for rec in analysis['summary_recommendations']:
        print(f"- {rec}")