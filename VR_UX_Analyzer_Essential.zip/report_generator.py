"""
VR Game UX Analyzer - Generador de Reportes
Genera reportes completos de análisis UX con visualizaciones y recomendaciones
"""

import os
import json
from datetime import datetime
from typing import Dict, List, Any, Optional
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
from jinja2 import Template
import base64
import io
import logging

class ReportGenerator:
    """
    Genera reportes completos de análisis UX en múltiples formatos
    """
    
    def __init__(self, output_dir: str = "reports"):
        """
        Inicializa el generador de reportes
        
        Args:
            output_dir: Directorio para guardar reportes
        """
        self.output_dir = output_dir
        self.setup_output_directory()
        self.setup_logging()
        self.setup_plot_styling()
    
    def setup_output_directory(self):
        """Crea directorio de salida si no existe"""
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Crear subdirectorios
        subdirs = ['html', 'pdf', 'json', 'images', 'interactive']
        for subdir in subdirs:
            os.makedirs(os.path.join(self.output_dir, subdir), exist_ok=True)
    
    def setup_logging(self):
        """Configura el sistema de logging"""
        self.logger = logging.getLogger(__name__)
    
    def setup_plot_styling(self):
        """Configura estilos para gráficos"""
        plt.style.use('seaborn-v0_8')
        sns.set_palette("husl")
        
        # Configuración para plotly
        self.plotly_template = "plotly_white"
    
    def generate_comprehensive_report(self, 
                                   analysis_results: Dict,
                                   video_info: Dict,
                                   session_metadata: Dict) -> Dict[str, str]:
        """
        Genera reporte completo en múltiples formatos
        
        Args:
            analysis_results: Resultados completos del análisis
            video_info: Información del video analizado
            session_metadata: Metadatos de la sesión
            
        Returns:
            Diccionario con rutas de archivos generados
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        session_name = session_metadata.get('session_name', 'vr_session')
        
        # Preparar datos para el reporte
        report_data = self._prepare_report_data(
            analysis_results, video_info, session_metadata
        )
        
        # Generar diferentes formatos
        output_files = {}
        
        # 1. Reporte HTML interactivo
        html_path = self._generate_html_report(report_data, session_name, timestamp)
        output_files['html'] = html_path
        
        # 2. Reporte PDF ejecutivo
        pdf_path = self._generate_pdf_report(report_data, session_name, timestamp)
        output_files['pdf'] = pdf_path
        
        # 3. Datos JSON para procesamiento posterior
        json_path = self._generate_json_report(report_data, session_name, timestamp)
        output_files['json'] = json_path
        
        # 4. Dashboard interactivo con Plotly
        dashboard_path = self._generate_interactive_dashboard(report_data, session_name, timestamp)
        output_files['dashboard'] = dashboard_path
        
        # 5. Imágenes individuales de visualizaciones
        images_dir = self._generate_visualization_images(report_data, session_name, timestamp)
        output_files['images_dir'] = images_dir
        
        self.logger.info(f"Reportes generados exitosamente en: {self.output_dir}")
        
        return output_files
    
    def _prepare_report_data(self, analysis_results: Dict, 
                           video_info: Dict, session_metadata: Dict) -> Dict:
        """
        Prepara y estructura los datos para el reporte
        
        Args:
            analysis_results: Resultados del análisis
            video_info: Información del video
            session_metadata: Metadatos de la sesión
            
        Returns:
            Datos estructurados para el reporte
        """
        # Crear estructura base del reporte
        report_data = {
            'metadata': {
                'generation_time': datetime.now().isoformat(),
                'session_info': session_metadata,
                'video_info': video_info,
                'analysis_version': '1.0'
            },
            'executive_summary': {},
            'detailed_metrics': {},
            'visualizations': {},
            'recommendations': {},
            'raw_data': analysis_results
        }
        
        # Generar resumen ejecutivo
        report_data['executive_summary'] = self._create_executive_summary(analysis_results)
        
        # Estructurar métricas detalladas
        report_data['detailed_metrics'] = self._structure_detailed_metrics(analysis_results)
        
        # Preparar datos de visualización
        report_data['visualizations'] = self._prepare_visualization_data(analysis_results)
        
        # Compilar recomendaciones
        report_data['recommendations'] = self._compile_recommendations(analysis_results)
        
        return report_data
    
    def _create_executive_summary(self, analysis_results: Dict) -> Dict:
        """Crea resumen ejecutivo del análisis"""
        summary = {
            'overall_score': 0.0,
            'key_findings': [],
            'critical_issues': [],
            'strengths': [],
            'improvement_areas': []
        }
        
        # Extraer puntuación general
        if 'ux_metrics' in analysis_results:
            metrics = analysis_results['ux_metrics']
            
            # Calcular puntuación promedio
            all_scores = []
            for category, category_metrics in metrics.items():
                if isinstance(category_metrics, dict):
                    for metric_name, metric in category_metrics.items():
                        if hasattr(metric, 'value'):
                            all_scores.append(metric.value)
            
            if all_scores:
                summary['overall_score'] = np.mean(all_scores)
        
        # Identificar hallazgos clave
        summary['key_findings'] = self._extract_key_findings(analysis_results)
        
        # Identificar problemas críticos
        summary['critical_issues'] = self._identify_critical_issues(analysis_results)
        
        # Identificar fortalezas
        summary['strengths'] = self._identify_strengths(analysis_results)
        
        # Áreas de mejora
        summary['improvement_areas'] = self._identify_improvement_areas(analysis_results)
        
        return summary
    
    def _extract_key_findings(self, analysis_results: Dict) -> List[str]:
        """Extrae hallazgos clave del análisis"""
        findings = []
        
        # Revisar métricas de interacción
        if 'interaction_analysis' in analysis_results:
            interaction_summary = analysis_results['interaction_analysis'].get('summary', {})
            
            success_rate = interaction_summary.get('success_rate', 0)
            if success_rate > 0.9:
                findings.append(f"Excelente tasa de éxito en interacciones: {success_rate:.1%}")
            elif success_rate < 0.6:
                findings.append(f"Tasa de éxito baja requiere atención: {success_rate:.1%}")
        
        # Revisar análisis de comportamiento
        if 'behavior_analysis' in analysis_results:
            behavior_data = analysis_results['behavior_analysis']
            
            if 'cognitive_load' in behavior_data:
                cognitive_load = behavior_data['cognitive_load'].get('overall_assessment', {})
                load_level = cognitive_load.get('load_level', 'unknown')
                
                if load_level == 'high':
                    findings.append("Alta carga cognitiva detectada - considerar simplificar interfaz")
                elif load_level == 'low':
                    findings.append("Baja carga cognitiva - oportunidad para añadir complejidad")
        
        # Revisar eficiencia de movimiento
        if 'movement_analysis' in analysis_results:
            movement_summary = analysis_results['movement_analysis'].get('summary', {})
            
            total_distance = movement_summary.get('movement_stats', {}).get('total_distance', {})
            if total_distance:
                avg_distance = np.mean(list(total_distance.values()))
                if avg_distance > 10000:  # Threshold ejemplo
                    findings.append("Movimiento excesivo detectado - optimizar layout espacial")
        
        return findings
    
    def _identify_critical_issues(self, analysis_results: Dict) -> List[Dict]:
        """Identifica problemas críticos que requieren atención inmediata"""
        issues = []
        
        # Revisar confusión del jugador
        if 'interaction_analysis' in analysis_results:
            summary = analysis_results['interaction_analysis'].get('summary', {})
            confusion_events = summary.get('stats', {}).get('confusion_events', 0)
            
            if confusion_events > 5:
                issues.append({
                    'severity': 'high',
                    'category': 'Usabilidad',
                    'issue': 'Múltiples eventos de confusión detectados',
                    'impact': 'Experiencia de usuario degradada',
                    'recommendation': 'Revisar señalización y affordances'
                })
        
        # Revisar jugador perdido
        if 'interaction_analysis' in analysis_results:
            stats = analysis_results['interaction_analysis'].get('summary', {}).get('stats', {})
            lost_events = stats.get('player_lost_events', 0)
            
            if lost_events > 2:
                issues.append({
                    'severity': 'high',
                    'category': 'Tracking',
                    'issue': 'Pérdida frecuente de tracking del jugador',
                    'impact': 'Interrupción de la experiencia',
                    'recommendation': 'Mejorar sistema de tracking o iluminación'
                })
        
        # Revisar tasa de error alta
        if 'ux_metrics' in analysis_results:
            for category, metrics in analysis_results['ux_metrics'].items():
                if isinstance(metrics, dict):
                    for name, metric in metrics.items():
                        if hasattr(metric, 'value') and 'error' in name.lower():
                            if metric.value > 0.15:  # 15% error rate
                                issues.append({
                                    'severity': 'medium',
                                    'category': 'Efectividad',
                                    'issue': f'Alta tasa de error: {metric.value:.1%}',
                                    'impact': 'Frustración del usuario',
                                    'recommendation': 'Revisar diseño de interacciones'
                                })
        
        return issues
    
    def _identify_strengths(self, analysis_results: Dict) -> List[Dict]:
        """Identifica fortalezas del diseño"""
        strengths = []
        
        # Revisar métricas positivas
        if 'ux_metrics' in analysis_results:
            for category, metrics in analysis_results['ux_metrics'].items():
                if isinstance(metrics, dict):
                    for name, metric in metrics.items():
                        if hasattr(metric, 'value'):
                            # Identificar métricas altas (asumiendo que alto es bueno)
                            if metric.value > 0.8 and 'completion' in name.lower():
                                strengths.append({
                                    'area': 'Efectividad',
                                    'metric': name,
                                    'value': f'{metric.value:.1%}',
                                    'description': 'Excelente tasa de completación de tareas'
                                })
                            elif metric.value > 0.7 and 'efficiency' in name.lower():
                                strengths.append({
                                    'area': 'Eficiencia',
                                    'metric': name,
                                    'value': f'{metric.value:.1%}',
                                    'description': 'Buen nivel de eficiencia en interacciones'
                                })
        
        return strengths
    
    def _identify_improvement_areas(self, analysis_results: Dict) -> List[Dict]:
        """Identifica áreas específicas de mejora"""
        improvements = []
        
        # Analizar métricas por debajo del benchmark
        if 'ux_metrics' in analysis_results:
            for category, metrics in analysis_results['ux_metrics'].items():
                if isinstance(metrics, dict):
                    for name, metric in metrics.items():
                        if hasattr(metric, 'value') and hasattr(metric, 'benchmark'):
                            if metric.benchmark and metric.value < metric.benchmark:
                                gap = metric.benchmark - metric.value
                                improvements.append({
                                    'area': metric.category.value,
                                    'metric': name,
                                    'current_value': f'{metric.value:.1%}',
                                    'benchmark': f'{metric.benchmark:.1%}',
                                    'gap': f'{gap:.1%}',
                                    'priority': 'high' if gap > 0.2 else 'medium',
                                    'recommendations': getattr(metric, 'recommendations', [])
                                })
        
        return improvements
    
    def _structure_detailed_metrics(self, analysis_results: Dict) -> Dict:
        """Estructura las métricas detalladas por categoría"""
        structured_metrics = {
            'usability': {},
            'efficiency': {},
            'effectiveness': {},
            'satisfaction': {},
            'learnability': {},
            'accessibility': {},
            'engagement': {}
        }
        
        # Organizar métricas UX por categoría
        if 'ux_metrics' in analysis_results:
            for category, metrics in analysis_results['ux_metrics'].items():
                if isinstance(metrics, dict):
                    for name, metric in metrics.items():
                        if hasattr(metric, 'category'):
                            category_name = metric.category.value
                            if category_name in structured_metrics:
                                structured_metrics[category_name][name] = {
                                    'value': metric.value,
                                    'description': metric.description,
                                    'interpretation': metric.interpretation,
                                    'recommendations': getattr(metric, 'recommendations', []),
                                    'benchmark': getattr(metric, 'benchmark', None)
                                }
        
        return structured_metrics
    
    def _prepare_visualization_data(self, analysis_results: Dict) -> Dict:
        """Prepara datos para visualizaciones"""
        viz_data = {
            'metrics_radar': {},
            'timeline_charts': {},
            'heatmap_data': {},
            'interaction_flow': {},
            'performance_trends': {}
        }
        
        # Datos para gráfico radar de métricas
        if 'ux_metrics' in analysis_results:
            radar_data = {}
            for category, metrics in analysis_results['ux_metrics'].items():
                if isinstance(metrics, dict):
                    category_values = []
                    for metric in metrics.values():
                        if hasattr(metric, 'value'):
                            category_values.append(metric.value)
                    
                    if category_values:
                        radar_data[category] = np.mean(category_values)
            
            viz_data['metrics_radar'] = radar_data
        
        # Datos de línea temporal
        if 'interaction_analysis' in analysis_results:
            timeline = analysis_results['interaction_analysis'].get('timeline', [])
            viz_data['timeline_charts'] = self._process_timeline_data(timeline)
        
        # Datos de heatmap
        if 'heatmap_data' in analysis_results:
            viz_data['heatmap_data'] = analysis_results['heatmap_data']
        
        return viz_data
    
    def _process_timeline_data(self, timeline_data: List[Dict]) -> Dict:
        """Procesa datos de línea temporal para visualización"""
        if not timeline_data:
            return {}
        
        df = pd.DataFrame(timeline_data)
        
        # Crear series temporales por tipo de evento
        timeline_series = {}
        
        if 'type' in df.columns and 'timestamp' in df.columns:
            for event_type in df['type'].unique():
                type_data = df[df['type'] == event_type]
                timeline_series[event_type] = {
                    'timestamps': type_data['timestamp'].tolist(),
                    'values': list(range(len(type_data))),  # Contador acumulativo
                    'success_rate': type_data['success'].mean() if 'success' in type_data.columns else 1.0
                }
        
        return timeline_series
    
    def _compile_recommendations(self, analysis_results: Dict) -> Dict:
        """Compila todas las recomendaciones por prioridad"""
        recommendations = {
            'high_priority': [],
            'medium_priority': [],
            'low_priority': [],
            'general_suggestions': []
        }
        
        # Recopilar recomendaciones de métricas UX
        if 'ux_metrics' in analysis_results:
            for category, metrics in analysis_results['ux_metrics'].items():
                if isinstance(metrics, dict):
                    for name, metric in metrics.items():
                        if hasattr(metric, 'recommendations'):
                            # Determinar prioridad basada en qué tan lejos está del benchmark
                            priority = 'medium_priority'
                            if hasattr(metric, 'benchmark') and metric.benchmark:
                                gap = abs(metric.benchmark - metric.value)
                                if gap > 0.3:
                                    priority = 'high_priority'
                                elif gap < 0.1:
                                    priority = 'low_priority'
                            
                            for rec in metric.recommendations:
                                recommendations[priority].append({
                                    'source': name,
                                    'category': metric.category.value if hasattr(metric, 'category') else 'general',
                                    'recommendation': rec,
                                    'current_value': metric.value,
                                    'benchmark': getattr(metric, 'benchmark', None)
                                })
        
        # Agregar recomendaciones de análisis de comportamiento
        if 'behavior_analysis' in analysis_results:
            behavior_recs = analysis_results['behavior_analysis'].get('summary_recommendations', [])
            for rec in behavior_recs:
                recommendations['general_suggestions'].append({
                    'source': 'behavior_analysis',
                    'category': 'behavior',
                    'recommendation': rec
                })
        
        return recommendations
    
    def _generate_html_report(self, report_data: Dict, session_name: str, timestamp: str) -> str:
        """Genera reporte HTML interactivo"""
        
        # Template HTML básico
        html_template = """
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Reporte UX VR - {{ session_name }}</title>
            <style>
                body { 
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                    margin: 0; 
                    padding: 20px; 
                    background-color: #f5f5f5; 
                }
                .container { 
                    max-width: 1200px; 
                    margin: 0 auto; 
                    background: white; 
                    padding: 30px; 
                    border-radius: 10px; 
                    box-shadow: 0 0 20px rgba(0,0,0,0.1); 
                }
                .header { 
                    text-align: center; 
                    border-bottom: 3px solid #007acc; 
                    padding-bottom: 20px; 
                    margin-bottom: 30px; 
                }
                .section { 
                    margin: 30px 0; 
                }
                .metric-card { 
                    background: #f8f9fa; 
                    padding: 15px; 
                    margin: 10px 0; 
                    border-radius: 5px; 
                    border-left: 4px solid #007acc; 
                }
                .score { 
                    font-size: 2em; 
                    font-weight: bold; 
                    color: #007acc; 
                }
                .recommendation { 
                    background: #e9f4ff; 
                    padding: 10px; 
                    margin: 5px 0; 
                    border-radius: 3px; 
                }
                .high-priority { 
                    border-left: 4px solid #dc3545; 
                }
                .medium-priority { 
                    border-left: 4px solid #ffc107; 
                }
                .low-priority { 
                    border-left: 4px solid #28a745; 
                }
                .summary-grid { 
                    display: grid; 
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
                    gap: 20px; 
                    margin: 20px 0; 
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Análisis UX - Juego VR</h1>
                    <h2>{{ session_name }}</h2>
                    <p>Generado el: {{ generation_time }}</p>
                </div>

                <div class="section">
                    <h2>Resumen Ejecutivo</h2>
                    <div class="metric-card">
                        <h3>Puntuación General UX</h3>
                        <div class="score">{{ "%.1f"|format(overall_score * 100) }}%</div>
                    </div>
                    
                    <div class="summary-grid">
                        <div>
                            <h4>Hallazgos Clave</h4>
                            <ul>
                            {% for finding in key_findings %}
                                <li>{{ finding }}</li>
                            {% endfor %}
                            </ul>
                        </div>
                        
                        <div>
                            <h4>Fortalezas Identificadas</h4>
                            <ul>
                            {% for strength in strengths %}
                                <li><strong>{{ strength.area }}:</strong> {{ strength.description }}</li>
                            {% endfor %}
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <h2>Problemas Críticos</h2>
                    {% for issue in critical_issues %}
                    <div class="metric-card {{ issue.severity }}-priority">
                        <h4>{{ issue.category }}: {{ issue.issue }}</h4>
                        <p><strong>Impacto:</strong> {{ issue.impact }}</p>
                        <p><strong>Recomendación:</strong> {{ issue.recommendation }}</p>
                    </div>
                    {% endfor %}
                </div>

                <div class="section">
                    <h2>Métricas Detalladas</h2>
                    {% for category, metrics in detailed_metrics.items() %}
                    {% if metrics %}
                    <div class="metric-card">
                        <h3>{{ category.title() }}</h3>
                        {% for name, metric in metrics.items() %}
                        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 3px;">
                            <strong>{{ name }}:</strong> {{ "%.1f"|format(metric.value * 100) }}%
                            {% if metric.benchmark %}
                            (Benchmark: {{ "%.1f"|format(metric.benchmark * 100) }}%)
                            {% endif %}
                            <br>
                            <small>{{ metric.description }}</small>
                            <br>
                            <em>{{ metric.interpretation }}</em>
                        </div>
                        {% endfor %}
                    </div>
                    {% endif %}
                    {% endfor %}
                </div>

                <div class="section">
                    <h2>Recomendaciones</h2>
                    
                    <h3>Alta Prioridad</h3>
                    {% for rec in recommendations.high_priority %}
                    <div class="recommendation high-priority">
                        <strong>{{ rec.category.title() }}:</strong> {{ rec.recommendation }}
                    </div>
                    {% endfor %}
                    
                    <h3>Prioridad Media</h3>
                    {% for rec in recommendations.medium_priority %}
                    <div class="recommendation medium-priority">
                        <strong>{{ rec.category.title() }}:</strong> {{ rec.recommendation }}
                    </div>
                    {% endfor %}
                    
                    <h3>Sugerencias Generales</h3>
                    {% for rec in recommendations.general_suggestions %}
                    <div class="recommendation low-priority">
                        {{ rec.recommendation }}
                    </div>
                    {% endfor %}
                </div>

                <div class="section">
                    <h2>Información de la Sesión</h2>
                    <div class="metric-card">
                        <p><strong>Duración del análisis:</strong> {{ session_duration }} segundos</p>
                        <p><strong>Video analizado:</strong> {{ video_filename }}</p>
                        <p><strong>Resolución:</strong> {{ video_resolution }}</p>
                        <p><strong>FPS:</strong> {{ video_fps }}</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        
        # Renderizar template
        template = Template(html_template)
        
        # Preparar datos para el template
        template_data = {
            'session_name': session_name,
            'generation_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'overall_score': report_data['executive_summary'].get('overall_score', 0),
            'key_findings': report_data['executive_summary'].get('key_findings', []),
            'strengths': report_data['executive_summary'].get('strengths', []),
            'critical_issues': report_data['executive_summary'].get('critical_issues', []),
            'detailed_metrics': report_data['detailed_metrics'],
            'recommendations': report_data['recommendations'],
            'session_duration': report_data['metadata']['session_info'].get('duration', 'N/A'),
            'video_filename': report_data['metadata']['video_info'].get('filename', 'N/A'),
            'video_resolution': f"{report_data['metadata']['video_info'].get('width', 0)}x{report_data['metadata']['video_info'].get('height', 0)}",
            'video_fps': report_data['metadata']['video_info'].get('fps', 'N/A')
        }
        
        html_content = template.render(**template_data)
        
        # Guardar archivo HTML
        html_filename = f"{session_name}_report_{timestamp}.html"
        html_path = os.path.join(self.output_dir, 'html', html_filename)
        
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        self.logger.info(f"Reporte HTML generado: {html_path}")
        return html_path
    
    def _generate_pdf_report(self, report_data: Dict, session_name: str, timestamp: str) -> str:
        """Genera reporte PDF ejecutivo"""
        
        pdf_filename = f"{session_name}_executive_report_{timestamp}.pdf"
        pdf_path = os.path.join(self.output_dir, 'pdf', pdf_filename)
        
        with PdfPages(pdf_path) as pdf:
            # Página 1: Resumen Ejecutivo
            fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
            
            # Puntuación general
            overall_score = report_data['executive_summary'].get('overall_score', 0)
            ax1.pie([overall_score, 1-overall_score], labels=['Puntuación UX', 'Margen de mejora'], 
                   autopct='%1.1f%%', startangle=90, colors=['#007acc', '#e0e0e0'])
            ax1.set_title('Puntuación General UX', fontsize=14, fontweight='bold')
            
            # Métricas por categoría
            if report_data['visualizations'].get('metrics_radar'):
                radar_data = report_data['visualizations']['metrics_radar']
                categories = list(radar_data.keys())
                values = list(radar_data.values())
                
                ax2.bar(categories, values, color='skyblue')
                ax2.set_title('Métricas por Categoría', fontsize=14, fontweight='bold')
                ax2.set_ylabel('Puntuación')
                plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45, ha='right')
            
            # Problemas críticos
            critical_issues = report_data['executive_summary'].get('critical_issues', [])
            if critical_issues:
                severities = [issue['severity'] for issue in critical_issues]
                severity_counts = pd.Series(severities).value_counts()
                
                colors = {'high': '#dc3545', 'medium': '#ffc107', 'low': '#28a745'}
                ax3.pie(severity_counts.values, labels=severity_counts.index, 
                       autopct='%1.0f', colors=[colors.get(sev, '#gray') for sev in severity_counts.index])
                ax3.set_title('Distribución de Problemas por Severidad', fontsize=14, fontweight='bold')
            
            # Áreas de mejora
            improvement_areas = report_data['executive_summary'].get('improvement_areas', [])
            if improvement_areas:
                areas = [area['area'] for area in improvement_areas[:5]]  # Top 5
                gaps = [float(area['gap'].strip('%')) / 100 for area in improvement_areas[:5]]
                
                ax4.barh(areas, gaps, color='coral')
                ax4.set_title('Top 5 Áreas de Mejora', fontsize=14, fontweight='bold')
                ax4.set_xlabel('Brecha con Benchmark')
            
            plt.tight_layout()
            pdf.savefig(fig, bbox_inches='tight')
            plt.close()
            
            # Página 2: Análisis Temporal
            if report_data['visualizations'].get('timeline_charts'):
                fig, ax = plt.subplots(figsize=(16, 10))
                
                timeline_data = report_data['visualizations']['timeline_charts']
                
                for event_type, data in timeline_data.items():
                    if data['timestamps']:
                        ax.plot(data['timestamps'], data['values'], 
                               label=f"{event_type} (éxito: {data['success_rate']:.1%})", 
                               marker='o', markersize=4)
                
                ax.set_title('Línea Temporal de Eventos', fontsize=16, fontweight='bold')
                ax.set_xlabel('Tiempo (segundos)')
                ax.set_ylabel('Eventos Acumulados')
                ax.legend()
                ax.grid(True, alpha=0.3)
                
                pdf.savefig(fig, bbox_inches='tight')
                plt.close()
        
        self.logger.info(f"Reporte PDF generado: {pdf_path}")
        return pdf_path
    
    def _generate_json_report(self, report_data: Dict, session_name: str, timestamp: str) -> str:
        """Genera reporte en formato JSON"""
        
        # Convertir objetos no serializables
        json_data = self._make_json_serializable(report_data)
        
        json_filename = f"{session_name}_data_{timestamp}.json"
        json_path = os.path.join(self.output_dir, 'json', json_filename)
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, indent=2, ensure_ascii=False, default=str)
        
        self.logger.info(f"Reporte JSON generado: {json_path}")
        return json_path
    
    def _generate_interactive_dashboard(self, report_data: Dict, session_name: str, timestamp: str) -> str:
        """Genera dashboard interactivo con Plotly"""
        
        # Crear dashboard con subgráficos
        fig = make_subplots(
            rows=3, cols=2,
            subplot_titles=('Métricas por Categoría', 'Línea Temporal de Eventos',
                           'Distribución de Problemas', 'Tendencias de Rendimiento',
                           'Heatmap de Interacciones', 'Recomendaciones por Prioridad'),
            specs=[[{"type": "bar"}, {"type": "scatter"}],
                   [{"type": "pie"}, {"type": "scatter"}],
                   [{"type": "heatmap"}, {"type": "bar"}]]
        )
        
        # Gráfico 1: Métricas por categoría
        if report_data['visualizations'].get('metrics_radar'):
            radar_data = report_data['visualizations']['metrics_radar']
            fig.add_trace(
                go.Bar(x=list(radar_data.keys()), y=list(radar_data.values()),
                      name="Métricas UX", marker_color='skyblue'),
                row=1, col=1
            )
        
        # Gráfico 2: Línea temporal
        if report_data['visualizations'].get('timeline_charts'):
            timeline_data = report_data['visualizations']['timeline_charts']
            for event_type, data in timeline_data.items():
                if data['timestamps']:
                    fig.add_trace(
                        go.Scatter(x=data['timestamps'], y=data['values'],
                                 mode='lines+markers', name=event_type),
                        row=1, col=2
                    )
        
        # Gráfico 3: Distribución de problemas
        critical_issues = report_data['executive_summary'].get('critical_issues', [])
        if critical_issues:
            severities = [issue['severity'] for issue in critical_issues]
            severity_counts = pd.Series(severities).value_counts()
            
            fig.add_trace(
                go.Pie(labels=severity_counts.index, values=severity_counts.values,
                      name="Problemas"),
                row=2, col=1
            )
        
        # Actualizar layout
        fig.update_layout(
            height=1200,
            title_text=f"Dashboard UX Interactivo - {session_name}",
            showlegend=True
        )
        
        # Guardar dashboard
        dashboard_filename = f"{session_name}_dashboard_{timestamp}.html"
        dashboard_path = os.path.join(self.output_dir, 'interactive', dashboard_filename)
        
        fig.write_html(dashboard_path)
        
        self.logger.info(f"Dashboard interactivo generado: {dashboard_path}")
        return dashboard_path
    
    def _generate_visualization_images(self, report_data: Dict, session_name: str, timestamp: str) -> str:
        """Genera imágenes individuales de visualizaciones"""
        
        images_dir = os.path.join(self.output_dir, 'images', f"{session_name}_{timestamp}")
        os.makedirs(images_dir, exist_ok=True)
        
        # Gráfico de métricas radar
        if report_data['visualizations'].get('metrics_radar'):
            radar_data = report_data['visualizations']['metrics_radar']
            
            fig, ax = plt.subplots(figsize=(10, 8))
            categories = list(radar_data.keys())
            values = list(radar_data.values())
            
            ax.bar(categories, values, color='skyblue')
            ax.set_title('Métricas UX por Categoría', fontsize=16, fontweight='bold')
            ax.set_ylabel('Puntuación')
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            
            radar_path = os.path.join(images_dir, 'metrics_radar.png')
            plt.savefig(radar_path, dpi=300, bbox_inches='tight')
            plt.close()
        
        # Gráfico de línea temporal
        if report_data['visualizations'].get('timeline_charts'):
            timeline_data = report_data['visualizations']['timeline_charts']
            
            fig, ax = plt.subplots(figsize=(12, 6))
            
            for event_type, data in timeline_data.items():
                if data['timestamps']:
                    ax.plot(data['timestamps'], data['values'], 
                           label=f"{event_type}", marker='o', markersize=4)
            
            ax.set_title('Línea Temporal de Eventos', fontsize=16, fontweight='bold')
            ax.set_xlabel('Tiempo (segundos)')
            ax.set_ylabel('Eventos Acumulados')
            ax.legend()
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            
            timeline_path = os.path.join(images_dir, 'timeline.png')
            plt.savefig(timeline_path, dpi=300, bbox_inches='tight')
            plt.close()
        
        self.logger.info(f"Imágenes de visualización generadas en: {images_dir}")
        return images_dir
    
    def _make_json_serializable(self, obj):
        """Convierte objetos a formato serializable JSON"""
        if isinstance(obj, dict):
            return {key: self._make_json_serializable(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._make_json_serializable(item) for item in obj]
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, (np.integer, np.floating)):
            return obj.item()
        elif hasattr(obj, '__dict__'):
            return self._make_json_serializable(obj.__dict__)
        else:
            return obj


if __name__ == "__main__":
    # Ejemplo de uso
    generator = ReportGenerator()
    
    # Datos simulados para el ejemplo
    analysis_results = {
        'ux_metrics': {
            'usability': {
                'task_completion_rate': type('MockMetric', (), {
                    'value': 0.85,
                    'category': type('Category', (), {'value': 'usability'}),
                    'description': 'Tasa de completación de tareas',
                    'interpretation': 'Buena tasa de completación',
                    'recommendations': ['Mantener nivel actual'],
                    'benchmark': 0.90
                })()
            }
        },
        'interaction_analysis': {
            'summary': {
                'success_rate': 0.78,
                'stats': {
                    'confusion_events': 2,
                    'player_lost_events': 1
                }
            },
            'timeline': [
                {'timestamp': 1.0, 'type': 'select', 'success': True},
                {'timestamp': 2.0, 'type': 'drag', 'success': False}
            ]
        },
        'behavior_analysis': {
            'summary_recommendations': ['Mejorar retroalimentación visual']
        }
    }
    
    video_info = {
        'filename': 'test_session.mp4',
        'width': 1920,
        'height': 1080,
        'fps': 30
    }
    
    session_metadata = {
        'session_name': 'test_session',
        'duration': 120
    }
    
    # Generar reportes
    output_files = generator.generate_comprehensive_report(
        analysis_results, video_info, session_metadata
    )
    
    print("Reportes generados:")
    for format_type, path in output_files.items():
        print(f"- {format_type}: {path}")