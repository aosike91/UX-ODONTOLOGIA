"""
VR Game UX Analyzer - Generador de Heatmaps
Genera mapas de calor para visualizar patrones de movimiento, interacción y atención
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap
import cv2
from typing import List, Dict, Tuple, Optional, Union
from scipy import ndimage
from scipy.stats import gaussian_kde
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import logging

class HeatmapGenerator:
    """
    Genera diferentes tipos de heatmaps para análisis UX en juegos VR
    """
    
    def __init__(self, frame_width: int = 1920, frame_height: int = 1080):
        """
        Inicializa el generador de heatmaps
        
        Args:
            frame_width: Ancho del frame de referencia
            frame_height: Alto del frame de referencia
        """
        self.frame_width = frame_width
        self.frame_height = frame_height
        
        # Configuración de heatmaps
        self.heatmap_resolution = (200, 150)  # Resolución del heatmap
        self.gaussian_sigma = 2.0  # Sigma para suavizado gaussiano
        
        # Colormaps personalizados
        self.setup_colormaps()
        
        # Configuración de zonas de botones dentales (basado en la imagen proporcionada)
        self.dental_button_zones = {
            'brazos': {'x_range': (0.02, 0.28), 'y_range': (0.20, 0.50), 'name': 'Brazos', 'color': 'green'},
            'cepillos': {'x_range': (0.30, 0.56), 'y_range': (0.20, 0.50), 'name': 'Cepillos', 'color': 'green'},
            'copas': {'x_range': (0.58, 0.84), 'y_range': (0.20, 0.50), 'name': 'Copas', 'color': 'green'},
            'back_button': {'x_range': (0.02, 0.40), 'y_range': (0.05, 0.18), 'name': 'Regresar', 'color': 'purple'}
        }
        
        # Datos acumulados
        self.position_data = {
            'movement': [],
            'gaze': [],
            'interactions': [],
            'dwell_times': [],
            'button_interactions': {}  # Nuevo: interacciones por botón específico
        }
        
        # Inicializar datos de botones
        for button_key in self.dental_button_zones.keys():
            self.position_data['button_interactions'][button_key] = []
        
        self.setup_logging()
    
    def setup_logging(self):
        """Configura el sistema de logging"""
        self.logger = logging.getLogger(__name__)
    
    def setup_colormaps(self):
        """Configura colormaps personalizados para diferentes tipos de heatmaps"""
        # Heatmap de movimiento (azul a rojo)
        self.movement_cmap = LinearSegmentedColormap.from_list(
            'movement', ['#000080', '#0040FF', '#00FFFF', '#FFFF00', '#FF4000', '#800000']
        )
        
        # Heatmap de atención/gaze (verde a amarillo a rojo)
        self.attention_cmap = LinearSegmentedColormap.from_list(
            'attention', ['#004000', '#008000', '#00FF00', '#FFFF00', '#FF8000', '#FF0000']
        )
        
        # Heatmap de interacciones (púrpura a blanco)
        self.interaction_cmap = LinearSegmentedColormap.from_list(
            'interaction', ['#000000', '#400040', '#800080', '#C040C0', '#FF80FF', '#FFFFFF']
        )
        
        # Heatmap de tiempo de permanencia (azul frío a rojo caliente)
        self.dwell_cmap = plt.cm.coolwarm
    
    def add_position_data(self, positions: List[Tuple[int, int]], data_type: str = 'movement'):
        """
        Añade datos de posición para generar heatmaps
        
        Args:
            positions: Lista de posiciones (x, y)
            data_type: Tipo de datos ('movement', 'gaze', 'interactions', 'dwell_times')
        """
        if data_type in self.position_data:
            self.position_data[data_type].extend(positions)
    
    def add_interaction_data(self, interactions: List[Dict]):
        """
        Añade datos de interacciones con información adicional
        
        Args:
            interactions: Lista de diccionarios con datos de interacción
                         Cada dict debe contener al menos: {'position': (x, y), 'success': bool}
        """
        for interaction in interactions:
            if 'position' in interaction:
                self.position_data['interactions'].append(interaction)
    
    def add_dwell_data(self, dwell_points: List[Dict]):
        """
        Añade datos de tiempo de permanencia
        
        Args:
            dwell_points: Lista con {'position': (x, y), 'duration': float}
        """
        self.position_data['dwell_times'].extend(dwell_points)
    
    def generate_movement_heatmap(self, positions: Optional[List[Tuple[int, int]]] = None,
                                 overlay_frame: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Genera heatmap de movimiento
        
        Args:
            positions: Lista de posiciones. Si None, usa datos acumulados
            overlay_frame: Frame opcional para superponer el heatmap
            
        Returns:
            Imagen del heatmap como array numpy
        """
        if positions is None:
            positions = self.position_data['movement']
        
        if not positions:
            self.logger.warning("No hay datos de movimiento para generar heatmap")
            return np.zeros((self.frame_height, self.frame_width, 3), dtype=np.uint8)
        
        # Crear grid de densidad
        heatmap_grid = self._create_density_grid(positions)
        
        # Aplicar suavizado gaussiano
        smoothed_grid = ndimage.gaussian_filter(heatmap_grid, sigma=self.gaussian_sigma)
        
        # Normalizar
        if smoothed_grid.max() > 0:
            smoothed_grid = smoothed_grid / smoothed_grid.max()
        
        # Convertir a imagen usando colormap
        heatmap_img = self.movement_cmap(smoothed_grid)
        heatmap_img = (heatmap_img[:, :, :3] * 255).astype(np.uint8)
        
        # Redimensionar al tamaño del frame
        heatmap_resized = cv2.resize(heatmap_img, (self.frame_width, self.frame_height))
        
        # Superponer con frame si se proporciona
        if overlay_frame is not None:
            alpha = 0.6
            heatmap_resized = cv2.addWeighted(overlay_frame, 1-alpha, heatmap_resized, alpha, 0)
        
        return heatmap_resized
    
    def generate_attention_heatmap(self, gaze_positions: Optional[List[Tuple[int, int]]] = None,
                                  fixation_durations: Optional[List[float]] = None) -> np.ndarray:
        """
        Genera heatmap de atención/mirada
        
        Args:
            gaze_positions: Posiciones de mirada
            fixation_durations: Duraciones de fijación (opcional)
            
        Returns:
            Imagen del heatmap de atención
        """
        if gaze_positions is None:
            gaze_positions = self.position_data['gaze']
        
        if not gaze_positions:
            return np.zeros((self.frame_height, self.frame_width, 3), dtype=np.uint8)
        
        # Si hay duraciones de fijación, usar como pesos
        weights = fixation_durations if fixation_durations else [1.0] * len(gaze_positions)
        
        # Crear grid ponderado
        heatmap_grid = self._create_weighted_density_grid(gaze_positions, weights)
        
        # Suavizado más intenso para heatmap de atención
        smoothed_grid = ndimage.gaussian_filter(heatmap_grid, sigma=self.gaussian_sigma * 1.5)
        
        # Normalizar
        if smoothed_grid.max() > 0:
            smoothed_grid = smoothed_grid / smoothed_grid.max()
        
        # Aplicar colormap de atención
        heatmap_img = self.attention_cmap(smoothed_grid)
        heatmap_img = (heatmap_img[:, :, :3] * 255).astype(np.uint8)
        
        return cv2.resize(heatmap_img, (self.frame_width, self.frame_height))
    
    def generate_interaction_heatmap(self, interactions: Optional[List[Dict]] = None,
                                   show_success_failure: bool = True) -> np.ndarray:
        """
        Genera heatmap de interacciones
        
        Args:
            interactions: Lista de interacciones
            show_success_failure: Si mostrar éxito/fallo con colores diferentes
            
        Returns:
            Imagen del heatmap de interacciones
        """
        if interactions is None:
            interactions = self.position_data['interactions']
        
        if not interactions:
            return np.zeros((self.frame_height, self.frame_width, 3), dtype=np.uint8)
        
        if show_success_failure:
            return self._generate_success_failure_heatmap(interactions)
        else:
            positions = [interaction['position'] for interaction in interactions if 'position' in interaction]
            heatmap_grid = self._create_density_grid(positions)
            
            smoothed_grid = ndimage.gaussian_filter(heatmap_grid, sigma=self.gaussian_sigma)
            
            if smoothed_grid.max() > 0:
                smoothed_grid = smoothed_grid / smoothed_grid.max()
            
            heatmap_img = self.interaction_cmap(smoothed_grid)
            heatmap_img = (heatmap_img[:, :, :3] * 255).astype(np.uint8)
            
            return cv2.resize(heatmap_img, (self.frame_width, self.frame_height))
    
    def generate_dwell_time_heatmap(self, dwell_points: Optional[List[Dict]] = None) -> np.ndarray:
        """
        Genera heatmap de tiempo de permanencia
        
        Args:
            dwell_points: Puntos con tiempo de permanencia
            
        Returns:
            Imagen del heatmap de tiempo de permanencia
        """
        if dwell_points is None:
            dwell_points = self.position_data['dwell_times']
        
        if not dwell_points:
            return np.zeros((self.frame_height, self.frame_width, 3), dtype=np.uint8)
        
        positions = [point['position'] for point in dwell_points if 'position' in point]
        durations = [point['duration'] for point in dwell_points if 'duration' in point]
        
        # Crear grid ponderado por duración
        heatmap_grid = self._create_weighted_density_grid(positions, durations)
        
        smoothed_grid = ndimage.gaussian_filter(heatmap_grid, sigma=self.gaussian_sigma)
        
        if smoothed_grid.max() > 0:
            smoothed_grid = smoothed_grid / smoothed_grid.max()
        
        heatmap_img = self.dwell_cmap(smoothed_grid)
        heatmap_img = (heatmap_img[:, :, :3] * 255).astype(np.uint8)
        
        return cv2.resize(heatmap_img, (self.frame_width, self.frame_height))
    
    def _create_density_grid(self, positions: List[Tuple[int, int]]) -> np.ndarray:
        """
        Crea grid de densidad a partir de posiciones
        
        Args:
            positions: Lista de posiciones (x, y)
            
        Returns:
            Grid de densidad 2D
        """
        grid = np.zeros(self.heatmap_resolution)
        
        # Escalar posiciones al tamaño del grid
        scale_x = self.heatmap_resolution[1] / self.frame_width
        scale_y = self.heatmap_resolution[0] / self.frame_height
        
        for x, y in positions:
            grid_x = int(x * scale_x)
            grid_y = int(y * scale_y)
            
            # Asegurar que está dentro de los límites
            grid_x = max(0, min(grid_x, self.heatmap_resolution[1] - 1))
            grid_y = max(0, min(grid_y, self.heatmap_resolution[0] - 1))
            
            grid[grid_y, grid_x] += 1
        
        return grid
    
    def _create_weighted_density_grid(self, positions: List[Tuple[int, int]], 
                                    weights: List[float]) -> np.ndarray:
        """
        Crea grid de densidad ponderado
        
        Args:
            positions: Lista de posiciones
            weights: Pesos para cada posición
            
        Returns:
            Grid de densidad ponderado
        """
        grid = np.zeros(self.heatmap_resolution)
        
        scale_x = self.heatmap_resolution[1] / self.frame_width
        scale_y = self.heatmap_resolution[0] / self.frame_height
        
        for (x, y), weight in zip(positions, weights):
            grid_x = int(x * scale_x)
            grid_y = int(y * scale_y)
            
            grid_x = max(0, min(grid_x, self.heatmap_resolution[1] - 1))
            grid_y = max(0, min(grid_y, self.heatmap_resolution[0] - 1))
            
            grid[grid_y, grid_x] += weight
        
        return grid
    
    def _generate_success_failure_heatmap(self, interactions: List[Dict]) -> np.ndarray:
        """
        Genera heatmap que diferencia entre interacciones exitosas y fallidas
        
        Args:
            interactions: Lista de interacciones con información de éxito
            
        Returns:
            Heatmap combinado de éxito/fallo
        """
        # Separar interacciones exitosas y fallidas
        successful = []
        failed = []
        
        for interaction in interactions:
            if 'position' in interaction and 'success' in interaction:
                if interaction['success']:
                    successful.append(interaction['position'])
                else:
                    failed.append(interaction['position'])
        
        # Crear grids separados
        success_grid = self._create_density_grid(successful) if successful else np.zeros(self.heatmap_resolution)
        failure_grid = self._create_density_grid(failed) if failed else np.zeros(self.heatmap_resolution)
        
        # Suavizar
        success_grid = ndimage.gaussian_filter(success_grid, sigma=self.gaussian_sigma)
        failure_grid = ndimage.gaussian_filter(failure_grid, sigma=self.gaussian_sigma)
        
        # Normalizar
        max_success = success_grid.max() if success_grid.max() > 0 else 1
        max_failure = failure_grid.max() if failure_grid.max() > 0 else 1
        
        success_grid = success_grid / max_success
        failure_grid = failure_grid / max_failure
        
        # Crear imagen RGB combinada
        height, width = self.heatmap_resolution
        combined_img = np.zeros((height, width, 3))
        
        # Verde para éxitos, rojo para fallos
        combined_img[:, :, 1] = success_grid  # Canal verde
        combined_img[:, :, 0] = failure_grid  # Canal rojo
        
        # Convertir a uint8 y redimensionar
        combined_img = (combined_img * 255).astype(np.uint8)
        return cv2.resize(combined_img, (self.frame_width, self.frame_height))
    
    def generate_dental_buttons_heatmap(self, output_file: str) -> None:
        """Genera heatmap específico para las zonas de botones dentales"""
        try:
            fig, ax = plt.subplots(1, 1, figsize=(12, 8))
            
            # Configuración de zonas de botones dentales (basado en la imagen proporcionada)
            dental_button_zones = {
                'boton1': {'x_range': (0.125, 0.275), 'y_range': (0.275, 0.425), 'name': 'Boton1', 'color': 'green'},
                'boton2': {'x_range': (0.355, 0.505), 'y_range': (0.275, 0.425), 'name': 'Boton2', 'color': 'green'},
                'boton3': {'x_range': (0.585, 0.735), 'y_range': (0.275, 0.425), 'name': 'Boton3', 'color': 'green'},
                'back_button': {'x_range': (0.02, 0.40), 'y_range': (0.05, 0.18), 'name': 'Regresar', 'color': 'purple'}
            }
            
            # Crear una imagen base
            base_image = np.zeros((self.heatmap_resolution[1], self.heatmap_resolution[0]))
            
            # Colores para cada zona
            zone_colors = {
                'boton1': 0.8,
                'boton2': 0.6, 
                'boton3': 0.4,
                'back_button': 1.0
            }
            
            # Dibujar las zonas de los botones
            for button_key, zone_info in dental_button_zones.items():
                x_start = int(zone_info['x_range'][0] * self.heatmap_resolution[0])
                x_end = int(zone_info['x_range'][1] * self.heatmap_resolution[0])
                y_start = int(zone_info['y_range'][0] * self.heatmap_resolution[1])
                y_end = int(zone_info['y_range'][1] * self.heatmap_resolution[1])
                
                # Agregar intensidad basada en interacciones en esa zona
                intensity = zone_colors[button_key]
                
                # Contar interacciones en esta zona
                interaction_count = 0
                for interaction in self.position_data['interactions']:
                    x, y = interaction['x'], interaction['y']
                    if (zone_info['x_range'][0] <= x <= zone_info['x_range'][1] and 
                        zone_info['y_range'][0] <= y <= zone_info['y_range'][1]):
                        interaction_count += 1
                
                # Aumentar intensidad con más interacciones
                intensity *= (1.0 + interaction_count * 0.3)
                base_image[y_start:y_end, x_start:x_end] = intensity
            
            # Aplicar suavizado gaussiano
            base_image = ndimage.gaussian_filter(base_image, sigma=self.gaussian_sigma)
            
            # Crear el heatmap
            im = ax.imshow(base_image, cmap='hot', interpolation='bilinear', aspect='auto')
            
            # Agregar etiquetas de botones
            for button_key, zone_info in dental_button_zones.items():
                x_center = (zone_info['x_range'][0] + zone_info['x_range'][1]) / 2 * self.heatmap_resolution[0]
                y_center = (zone_info['y_range'][0] + zone_info['y_range'][1]) / 2 * self.heatmap_resolution[1]
                
                # Contar interacciones en esta zona
                interaction_count = 0
                for interaction in self.position_data['interactions']:
                    x, y = interaction['x'], interaction['y']
                    if (zone_info['x_range'][0] <= x <= zone_info['x_range'][1] and 
                        zone_info['y_range'][0] <= y <= zone_info['y_range'][1]):
                        interaction_count += 1
                
                ax.text(x_center, y_center, f"{zone_info['name']}\n({interaction_count})", 
                       ha='center', va='center', fontsize=10, fontweight='bold',
                       bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))
            
            # Configurar el plot
            ax.set_title('Mapa de Calor - Botones Dentales VR\n(Números indican interacciones detectadas)', 
                        fontsize=14, fontweight='bold')
            ax.set_xlabel('Posición X (Normalizada)')
            ax.set_ylabel('Posición Y (Normalizada)')
            
            # Agregar barra de colores
            plt.colorbar(im, ax=ax, label='Intensidad de Interacción')
            
            # Configurar límites y etiquetas de ejes
            ax.set_xlim(0, self.heatmap_resolution[0])
            ax.set_ylim(self.heatmap_resolution[1], 0)  # Invertir Y para coincidir con coordenadas de imagen
            
            plt.tight_layout()
            plt.savefig(output_file, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            self.logger.error(f"Error generando heatmap de botones dentales: {e}")
            # Crear imagen de error como fallback
            fig, ax = plt.subplots(1, 1, figsize=(8, 6))
            ax.text(0.5, 0.5, f'Error generando heatmap\n{str(e)}', 
                   ha='center', va='center', transform=ax.transAxes)
            ax.set_title('Mapa de Calor - Botones Dentales (Error)')
            plt.savefig(output_file, dpi=150, bbox_inches='tight')
            plt.close()
    
    def generate_interactive_plotly_heatmap(self, data_type: str = 'movement', 
                                          title: str = "Interactive Heatmap") -> go.Figure:
        """
        Genera heatmap interactivo usando Plotly
        
        Args:
            data_type: Tipo de datos ('movement', 'gaze', 'interactions', 'dwell_times')
            title: Título del heatmap
            
        Returns:
            Figura de Plotly
        """
        if data_type not in self.position_data:
            raise ValueError(f"Tipo de datos no válido: {data_type}")
        
        data = self.position_data[data_type]
        
        if not data:
            # Crear figura vacía
            fig = go.Figure()
            fig.add_annotation(text="No hay datos disponibles", 
                             xref="paper", yref="paper", x=0.5, y=0.5)
            return fig
        
        if data_type == 'dwell_times':
            # Para datos de permanencia, usar posiciones y duraciones
            x_coords = [point['position'][0] for point in data if 'position' in point]
            y_coords = [point['position'][1] for point in data if 'position' in point]
            weights = [point['duration'] for point in data if 'duration' in point]
        elif data_type == 'interactions':
            # Para interacciones, extraer posiciones
            x_coords = [item['position'][0] for item in data if 'position' in item]
            y_coords = [item['position'][1] for item in data if 'position' in item]
            weights = None
        else:
            # Para movimiento y mirada
            x_coords = [pos[0] for pos in data]
            y_coords = [pos[1] for pos in data]
            weights = None
        
        if not x_coords:
            fig = go.Figure()
            fig.add_annotation(text="Datos insuficientes para visualización", 
                             xref="paper", yref="paper", x=0.5, y=0.5)
            return fig
        
        # Crear heatmap usando histograma 2D
        if weights is not None:
            # Heatmap ponderado
            hist, x_edges, y_edges = np.histogram2d(
                x_coords, y_coords, bins=[50, 40], 
                range=[[0, self.frame_width], [0, self.frame_height]],
                weights=weights
            )
        else:
            # Heatmap de densidad simple
            hist, x_edges, y_edges = np.histogram2d(
                x_coords, y_coords, bins=[50, 40],
                range=[[0, self.frame_width], [0, self.frame_height]]
            )
        
        # Crear figura
        fig = go.Figure(data=go.Heatmap(
            z=hist.T,  # Transponer para orientación correcta
            x=x_edges[:-1],
            y=y_edges[:-1],
            colorscale='Viridis',
            showscale=True
        ))
        
        fig.update_layout(
            title=title,
            xaxis_title="Posición X (pixels)",
            yaxis_title="Posición Y (pixels)",
            width=800,
            height=600
        )
        
        # Invertir eje Y para que coincida con coordenadas de imagen
        fig.update_yaxis(autorange="reversed")
        
        return fig
    
    def generate_comparative_heatmaps(self, background_frame: Optional[np.ndarray] = None) -> Dict[str, np.ndarray]:
        """
        Genera conjunto completo de heatmaps para comparación
        
        Args:
            background_frame: Frame de fondo opcional
            
        Returns:
            Diccionario con todos los heatmaps generados
        """
        heatmaps = {}
        
        # Heatmap de movimiento
        heatmaps['movement'] = self.generate_movement_heatmap(overlay_frame=background_frame)
        
        # Heatmap de atención
        heatmaps['attention'] = self.generate_attention_heatmap()
        
        # Heatmap de interacciones
        heatmaps['interactions'] = self.generate_interaction_heatmap(show_success_failure=True)
        
        # Heatmap de tiempo de permanencia
        heatmaps['dwell_time'] = self.generate_dwell_time_heatmap()
        
        return heatmaps
    
    def save_heatmaps(self, heatmaps: Dict[str, np.ndarray], output_dir: str = "heatmaps"):
        """
        Guarda heatmaps en archivos incluyendo el heatmap de botones dentales
        
        Args:
            heatmaps: Diccionario con heatmaps
            output_dir: Directorio de salida
        """
        import os
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Guardar heatmaps existentes
        for name, heatmap in heatmaps.items():
            filename = os.path.join(output_dir, f"{name}_heatmap.png")
            cv2.imwrite(filename, cv2.cvtColor(heatmap, cv2.COLOR_RGB2BGR))
            self.logger.info(f"Heatmap guardado: {filename}")
        
        # Generar y guardar heatmap específico de botones dentales
        dental_heatmap_file = os.path.join(output_dir, "dental_buttons_heatmap.png")
        self.generate_dental_buttons_heatmap(dental_heatmap_file)
    
    def create_heatmap_summary_figure(self) -> plt.Figure:
        """
        Crea figura resumen con todos los heatmaps
        
        Returns:
            Figura de matplotlib con todos los heatmaps
        """
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # Generar heatmaps
        heatmaps = self.generate_comparative_heatmaps()
        
        titles = {
            'movement': 'Mapa de Movimiento',
            'attention': 'Mapa de Atención',
            'interactions': 'Mapa de Interacciones\n(Verde=Éxito, Rojo=Fallo)',
            'dwell_time': 'Tiempo de Permanencia'
        }
        
        positions = [(0,0), (0,1), (1,0), (1,1)]
        heatmap_names = ['movement', 'attention', 'interactions', 'dwell_time']
        
        for i, (name, (row, col)) in enumerate(zip(heatmap_names, positions)):
            if name in heatmaps:
                axes[row, col].imshow(heatmaps[name])
                axes[row, col].set_title(titles.get(name, name), fontsize=12)
                axes[row, col].axis('off')
            else:
                axes[row, col].text(0.5, 0.5, f'No hay datos\npara {name}', 
                                   ha='center', va='center', transform=axes[row, col].transAxes)
                axes[row, col].set_title(titles.get(name, name), fontsize=12)
                axes[row, col].axis('off')
        
        plt.tight_layout()
        return fig
    
    def reset_data(self):
        """Limpia todos los datos acumulados"""
        for key in self.position_data:
            self.position_data[key].clear()


if __name__ == "__main__":
    # Ejemplo de uso
    generator = HeatmapGenerator()
    
    # Simular datos de movimiento
    import random
    
    movement_positions = [(random.randint(100, 800), random.randint(100, 600)) for _ in range(1000)]
    generator.add_position_data(movement_positions, 'movement')
    
    # Simular datos de mirada
    gaze_positions = [(random.randint(200, 700), random.randint(150, 550)) for _ in range(500)]
    generator.add_position_data(gaze_positions, 'gaze')
    
    # Simular interacciones
    interactions = [
        {'position': (random.randint(300, 600), random.randint(200, 500)), 
         'success': random.choice([True, False])}
        for _ in range(50)
    ]
    generator.add_interaction_data(interactions)
    
    # Generar heatmaps
    heatmaps = generator.generate_comparative_heatmaps()
    
    # Crear y mostrar figura resumen
    summary_fig = generator.create_heatmap_summary_figure()
    
    # Generar heatmap interactivo
    interactive_fig = generator.generate_interactive_plotly_heatmap('movement', 'Mapa de Movimiento Interactivo')
    
    print("Heatmaps generados exitosamente")
    print("Usar plt.show() para mostrar la figura resumen")
    print("Usar interactive_fig.show() para mostrar el heatmap interactivo")